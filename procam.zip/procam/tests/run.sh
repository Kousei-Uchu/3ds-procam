#!/bin/sh
# Host-side tests of the pure-C engine (image looks, MPO/GIF/AVI writers). Outputs land in tests/out/.
set -e; cd "$(dirname "$0")"; mkdir -p out
gcc -std=gnu11 -O2 -Wall -Wno-misleading-indentation -o test_host test_host.c ../source/img.c ../source/enc.c -lm
cd out && ../test_host
