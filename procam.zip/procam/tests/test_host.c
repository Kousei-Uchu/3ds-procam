// Host-side tests for the pure-C engine (img.c / enc.c). Build: see tests/run.sh
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "../source/img.h"
#include "../source/enc.h"
static void scene(uint8_t* p,int w,int h,int off){
    for(int y=0;y<h;y++) for(int x=0;x<w;x++){ uint8_t* q=p+((size_t)y*w+x)*3; int xx=x+off;
        q[0]=(uint8_t)(xx*255/w); q[1]=(uint8_t)(y*255/h); q[2]=(uint8_t)(((xx/16)+(y/16))&1?220:40);
        int dx=x-(w/2-off/2), dy=y-h/2; if(dx*dx+dy*dy<(h/4)*(h/4)){ q[0]=230; q[1]=190; q[2]=160; } }
}
int main(void){
    int w=320,h=240; size_t n=(size_t)w*h*3;
    uint8_t *L=malloc(n),*R=malloc(n),*o=malloc(n),*d=malloc(w*h);
    scene(L,w,h,0); scene(R,w,h,8);
    enc_jpg("t_L.jpg",L,w,h,90); enc_png("t_L.png",L,w,h); enc_bmp("t_L.bmp",L,w,h);
    puts(enc_mpo("t.mpo",L,R,w,h,90)?"mpo ok":"mpo FAIL");
    FILE* f=fopen("t.mpo","rb"); fseek(f,0,SEEK_END); long len=ftell(f); fseek(f,0,SEEK_SET); uint8_t* b=malloc(len); fread(b,1,len,f); fclose(f);
    size_t o2=mpo_second_offset(b,len); printf("mpo second offset %zu: %02X%02X\n",o2,b[o2],b[o2+1]);
    int dx,dy; align_pair(L,R,w,h,&dx,&dy); printf("align dx=%d dy=%d\n",dx,dy);
    anaglyph(L,R,o,w,h,3,0); enc_png("t_ana.png",o,w,h);
    depth_map(L,R,w,h,d); depth_to_rgb(d,o,w,h); enc_png("t_depth.png",o,w,h);
    memcpy(o,L,n); depth_fx(o,d,w,h,80,50); enc_png("t_bokeh.png",o,w,h);
    const uint8_t* fr[2]={L,R}; puts(enc_gif("t.gif",fr,2,w,h,12,1)?"gif ok":"gif FAIL");
    const uint8_t* three[3]={L,R,L}; uint8_t* hd=malloc(n); hdr_fuse(three,3,hd,w,h); enc_png("t_hdr.png",hd,w,h);
    for(int s=0;s<16;s++){ Look lk={0}; lk.style=s; lk.amt=100; lk.pix=1; lk.seed=7; memcpy(o,L,n); look_apply(o,w,h,&lk);
        char nm[32]; sprintf(nm,"t_style%02d.png",s); enc_png(nm,o,w,h); }
    for(int fx=1;fx<=10;fx++){ Look lk={0}; lk.funky=fx; lk.famt=60; lk.pix=1; lk.seed=3; memcpy(o,L,n); look_apply(o,w,h,&lk);
        look_apply(o,w,h,&lk); char nm[32]; sprintf(nm,"t_funky%02d.png",fx); enc_png(nm,o,w,h); }
    { Look lk={0}; lk.style=12; lk.amt=100; lk.vign=60; lk.grain=50; lk.scan=40; lk.crush=60; lk.dither=1; lk.soft=40; lk.sat=30; lk.con=15; lk.pix=1; memcpy(o,L,n); look_apply(o,w,h,&lk); enc_png("t_lofi.png",o,w,h); }
    memcpy(o,L,n); ov_zebra(o,w,h,200,0); ov_peaking(o,w,h,2); enc_png("t_ov.png",o,w,h);
    uint8_t* wf=malloc(64*48*3); waveform(L,w,h,2,wf,64,48);
    Hist hi; hist_calc(L,w,h,&hi); printf("hist n=%u hi=%u lo=%u\n",hi.n,hi.hi,hi.lo);
    printf("sharp L=%.1f\n",sharpness(L,w,h));
    Box bx[4]; memcpy(o,L,n); printf("persons=%d\n",person_detect(o,w,h,bx,4));
    Stab st; memset(&st,0,sizeof st); int ox,oy; for(int i=0;i<6;i++){ scene(o,w,h,i*2); stab_update(&st,o,w,h,2,&ox,&oy); } printf("stab off=%d,%d\n",ox,oy);
    /* yuv roundtrip: grey ramp */
    uint8_t yuv[16*2*2]; for(int i=0;i<16*2;i+=2){ yuv[i*2]=(uint8_t)(i*8); yuv[i*2+1]=128; yuv[i*2+2]=(uint8_t)(i*8+4); yuv[i*2+3]=128; }
    uint8_t rgb[32*3]; yuv_to_rgb(yuv,rgb,32,1,0,0); printf("yuv px0=%d,%d,%d px31=%d,%d,%d\n",rgb[0],rgb[1],rgb[2],rgb[93],rgb[94],rgb[95]);
    /* avi: 20 mjpeg frames + audio */
    Avi* a=avi_open("t.avi",w,h,1,16360); for(int i=0;i<20;i++){ scene(o,w,h,i); uint8_t* j; size_t jn=enc_jpg_mem(o,w,h,60,&j); avi_video(a,j,jn); free(j);
        int16_t pcm[1090]; for(int k=0;k<1090;k++) pcm[k]=(int16_t)(8000*sin((i*1090+k)*0.05)); avi_audio(a,pcm,1090); }
    avi_close(a,15.0); puts("avi written");
    return 0;
}
