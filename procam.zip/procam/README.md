# PROCAM — lo-fi ↔ pro camera for New 2DS XL / 3DS

One slider (SYS → *Lo-Fi <> Pro*) blends ~40 settings between a crunchy old-camera look and a clean pro-controls setup. Both ends are editable (*Save as Lo-Fi / Pro*), plus 4 profile slots.

## Get it onto the console
1. Create a GitHub repo, upload this folder, push to `main`.
2. Actions builds `procam.cia` + `procam.3dsx` (devkitARM container) and publishes a release.
3. Open the release, tap `procam_cia_qr.png` (made automatically), then FBI → Remote Install → Scan QR Code. Repo must be public.

Local build: `export DEVKITPRO=/opt/devkitpro DEVKITARM=$DEVKITPRO/devkitARM`, install `makerom` + `bannertool`, run `make`.

## Controls
A / ZL / ZR shutter · B record video · X gallery · Y share to phone · Select cycle camera (outer / 3D pair / inner) · L/R menu page · D-pad edit · touch tabs, rows, `< >`, footer buttons · Start quit.
Gallery: A view mode (L/anaglyph/wiggle/R) · X zoom · Y delete shot + extras · Start slideshow.

## Where files go
`/DCIM/100NIN03/HNI_####.*` — `.JPG` `.PNG` `.BMP` `.MPO` (3D) `_A.JPG` anaglyph `.GIF` wigglegram `.AVI` video `.YUV` raw sensor dump + `.TXT` sidecar.
Settings: `/3ds/procam/*.cfg`.

## Implemented
Grid (6 types) · zebras · histogram · waveform · focus peaking · false colour · clip warning · gyro level · crop guides · 16 picture styles · 10 funky modes · grain/vignette/scanlines/colour-crush/dither/softness · manual EV/WB/sharpness/contrast/noise/lens/metering/scene · emulated shutter priority (frame-rate cap) · stacking (1–16) · bracketing + HDR merge · burst + best-of-burst · dual exposure with onion-skin · timer · timelapse · voice shutter · stereo MPO / anaglyph (4 types) / wigglegram GIF / depth-based bokeh + subject pop · stereo + mono MJPEG AVI video with mic audio · image-based stabilisation · gallery · Wi-Fi share (HTTP server + QR) · experimental skin-blob person detector (OFF by default).
Raw = full 640×480 YUV422 straight off the sensor pipe (no RGB565 crush), saved untouched as `.YUV`.

## Not hardware-tested yet — expect to tune
- SYS → *YUV byte order / range*: if colours look wrong in RAW mode, flip these.
- OVR → *Level invert* if the horizon tilt is mirrored. "SHAKY" threshold is a constant in `main.c` (`read_motion`).
- AE-lock, shutter-priority and metering windows rely on camera-service behaviour I couldn't verify off-device.
- Whether the stock Camera app opens our `.MPO` is untested.
- True Bayer raw / real ISO+shutter would need direct sensor-register access (`CAMU_WriteRegisterI2c` etc. exist in libctru) — not attempted.

## Sensor register explorer (experimental)
SYS → *Sensor registers*: live preview plus hex editor for camera I2C registers / MCU variables (target OUT1, OUT2, IN1 with Select; X toggles register vs MCU var).
Pad up/down edits the digit, left/right moves, A reads, Y writes, ZL (or DUMP) saves 256 registers to `/3ds/procam/regdump_*.txt`, Start (or SCRIPT) appends the current write to `/3ds/procam/regs.txt`.
Turn on SYS → *Run reg script* to replay `regs.txt` every time the camera starts (`W aaaa dddd` = register, `M aaaa dddd` = MCU variable, hex, `#` comments).
I don't know the sensor's register map: dump, change one thing at a time, watch the preview. Bad writes can freeze the camera until you leave the tool or restart the app. Unverified on hardware, including whether the service allows these calls to a homebrew process.

## Dev
`tests/run.sh` runs host tests of the pure-C engine (looks, MPO/GIF/AVI writers).
