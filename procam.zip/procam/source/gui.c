// Shared touch-GUI toolkit (see gui.h).
#include <string.h>
#include <stdio.h>
#include "gui.h"
void gui_icon_extra(int id,int cx,int cy,uint16_t col);

/* ---------- palette (runtime, because rgb16 is an inline function) ---------- */
uint16_t col_card(void){ return rgb16(22,25,32); }
uint16_t col_edge(void){ return rgb16(52,57,70); }
uint16_t col_dim(void) { return rgb16(130,138,155); }
uint16_t col_txt(void) { return rgb16(236,238,244); }
uint16_t col_ok(void)  { return rgb16(60,205,110); }
uint16_t col_bad(void) { return rgb16(240,72,62); }
uint16_t col_amb(void) { return rgb16(255,184,44); }


void gui_wrap(Canvas* c,int x,int y,const char* s,int cols,int maxlines,uint16_t col){
    char line[48]; int n=(int)strlen(s), pos=0;
    for(int ln=0;ln<maxlines&&pos<n;ln++){
        int len=(n-pos<cols)?n-pos:cols;
        if(pos+len<n){ int k=len; while(k>0&&s[pos+k]!=' ') k--; if(k>0) len=k; }
        memcpy(line,s+pos,len); line[len]=0; cv_text(c,x,y,line,col); y+=10; pos+=len; while(s[pos]==' ') pos++;
    }
}
/* Copy at most max chars so long names never run off a card. */
void gui_clip(char* dst,int n,const char* src,int max){ snprintf(dst,n,"%.*s",max,src); }


/* ---------- GUI widgets (bottom screen) ---------- */
void gui_card(Canvas* c,int x,int y,int w,int h,uint16_t fill){
    cv_rrect(c,x,y,w,h,5,col_edge()); cv_rrect(c,x+1,y+1,w-2,h-2,4,fill);
}
void gui_pill(Canvas* c,int x,int y,const char* s,uint16_t bg,uint16_t fg){
    int w=cv_text_w(s)+10; cv_rrect(c,x,y,w,13,6,bg); cv_text(c,x+5,y+3,s,fg);
}
int gui_pill_w(const char* s){ return cv_text_w(s)+10; }

/* Thick line icons, drawn on the bottom screen. */
static void gui_thick(int x0,int y0,int x1,int y1,uint16_t col){
    for(int d=-1;d<=1;d++){ cv_line(&g_bot,x0+d,y0,x1+d,y1,col); cv_line(&g_bot,x0,y0+d,x1,y1+d,col); }
}
void gui_icon(int id,int cx,int cy,uint16_t col){
    switch(id){
    case IC_BACK:  gui_thick(cx+7,cy,cx-7,cy,col); gui_thick(cx-7,cy,cx-1,cy-6,col); gui_thick(cx-7,cy,cx-1,cy+6,col); break;
    case IC_X:     gui_thick(cx-6,cy-6,cx+6,cy+6,col); gui_thick(cx-6,cy+6,cx+6,cy-6,col); break;
    case IC_CHECK: gui_thick(cx-8,cy,cx-3,cy+6,col); gui_thick(cx-3,cy+6,cx+8,cy-6,col); break;
    case IC_END:   cv_rect(&g_bot,cx-6,cy-6,12,12,col); break;
    case IC_UP:    gui_thick(cx-7,cy+4,cx,cy-4,col); gui_thick(cx,cy-4,cx+7,cy+4,col); break;
    case IC_DOWN:  gui_thick(cx-7,cy-4,cx,cy+4,col); gui_thick(cx,cy+4,cx+7,cy-4,col); break;
    default: gui_icon_extra(id,cx,cy,col); break;   /* menu icons live below */
    }
}
/* Rounded button with optional icon above a centred label. Brightens while pressed. */
void gui_button(int x,int y,int w,int h,int kind,int ic,const char* label,int pressed){
    int r,g,b,er,eg,eb;
    switch(kind){
    case BK_GREEN: r=26;g=116;b=68;  er=60;eg=205;eb=110; break;
    case BK_RED:   r=136;g=34;b=30;  er=240;eg=72;eb=62;  break;
    case BK_ACCENT:r=24;g=86;b=124;  er=70;eg=190;eb=255; break;
    default:       r=34;g=38;b=48;   er=70;eg=76;eb=92;   break;
    }
    if(pressed){ r+=45; g+=45; b+=45; er=er>200?255:er+55; eg=eg>200?255:eg+55; eb=eb>200?255:eb+55; }
    cv_rrect(&g_bot,x,y,w,h,8,rgb16(er,eg,eb)); cv_rrect(&g_bot,x+2,y+2,w-4,h-4,7,rgb16(r,g,b));
    uint16_t fg=col_txt();
    if(ic&&label[0]){ gui_icon(ic,x+w/2,y+h/2-8,fg); cv_text(&g_bot,x+(w-cv_text_w(label))/2,y+h-16,label,fg); }
    else if(ic){ gui_icon(ic,x+w/2,y+h/2,fg); }
    else cv_text(&g_bot,x+(w-cv_text_w(label))/2,y+(h-8)/2,label,fg);
}

/* ---------- touch handling: a button fires when you lift your finger while still over it ---------- */
int gui_touch(GuiTouch* t,GuiHit hit,u32 down,u32 up,u32 held,const touchPosition* tp){
    int out=-1;
    if(down&KEY_TOUCH){ t->lx=tp->px; t->ly=tp->py; t->pressed=hit(t->lx,t->ly); }
    if(held&KEY_TOUCH){ t->lx=tp->px; t->ly=tp->py; }
    t->cur=(held&KEY_TOUCH)?hit(t->lx,t->ly):-1;
    if(up&KEY_TOUCH){ if(t->pressed>=0&&hit(t->lx,t->ly)==t->pressed) out=t->pressed; t->pressed=-1; t->cur=-1; }
    return out;
}
int gui_down(const GuiTouch* t,int id){ return t->pressed==id&&t->cur==id; }



/* icons added for the main menu (kept separate so the original set above is untouched) */
void gui_icon_extra(int id,int cx,int cy,uint16_t col){
    Canvas* c=&g_bot;
    switch(id){
    case IC_PLUS:    gui_thick(cx-6,cy,cx+6,cy,col); gui_thick(cx,cy-6,cx,cy+6,col); break;
    case IC_MINUS:   gui_thick(cx-6,cy,cx+6,cy,col); break;
    case IC_SHUTTER: cv_rrect(c,cx-11,cy-11,22,22,11,col); cv_rrect(c,cx-8,cy-8,16,16,8,rgb16(20,24,32)); cv_rrect(c,cx-5,cy-5,10,10,5,col); break;
    case IC_REC:     cv_rrect(c,cx-8,cy-8,16,16,8,col); break;
    case IC_STOP:    cv_rect(c,cx-7,cy-7,14,14,col); break;
    case IC_GALLERY: cv_rrect(c,cx-10,cy-10,9,9,2,col); cv_rrect(c,cx+1,cy-10,9,9,2,col); cv_rrect(c,cx-10,cy+1,9,9,2,col); cv_rrect(c,cx+1,cy+1,9,9,2,col); break;
    case IC_SHARE:   gui_thick(cx,cy-9,cx,cy+3,col); gui_thick(cx,cy-9,cx-5,cy-4,col); gui_thick(cx,cy-9,cx+5,cy-4,col);
                     gui_thick(cx-9,cy+3,cx-9,cy+9,col); gui_thick(cx+9,cy+3,cx+9,cy+9,col); gui_thick(cx-9,cy+9,cx+9,cy+9,col); break;
    case IC_SEND:    gui_thick(cx-9,cy+6,cx+7,cy-4,col); gui_thick(cx+7,cy-4,cx-1,cy+9,col); gui_thick(cx-1,cy+9,cx-3,cy+2,col); break;
    default: break;
    }
}
void gui_switch(Canvas* c,int x,int y,int on){
    cv_rrect(c,x,y,36,16,8,on?col_ok():col_edge());
    cv_rrect(c,x+(on?20:2),y+2,14,12,6,col_txt());
}
