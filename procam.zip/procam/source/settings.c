#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "settings.h"

static const char* const L_SRC[]   = {"Outer left","Stereo pair","Inner"};
static const char* const L_EXPM[]  = {"Auto","EV bias","AE lock","Shutter prio"};
static const char* const L_SHUT[]  = {"1/5","1/10","1/15","1/20","1/30"};
static const char* const L_WB[]    = {"Auto","3200K","4150K","5200K","6000K","7000K"};
static const char* const L_PHOTO[] = {"Normal","Portrait","Landscape","Night","Letter"};
static const char* const L_LENS[]  = {"Off","70","90"};
static const char* const L_FLIP[]  = {"None","Horiz","Vert","Both"};
static const char* const L_FPS[]   = {"Max 30","20","15","10","5","30 fixed"};
static const char* const L_SFX[]   = {"None","Mono","Sepia","Negative","Neg film","Sepia 2"};
static const char* const L_METER[] = {"Full","Centre","Spot"};
static const char* const L_RES[]   = {"640x480 MAX","320x240","160x120"};
static const char* const L_PIPE[]  = {"RGB565 15bit","YUV422 raw"};
static const char* const L_FMT[]   = {"JPG","PNG","BMP","JPG+RAW","RAW only"};
static const char* const L_STACK[] = {"1","2","4","8","16"};
static const char* const L_LOOK[]  = {"Baked","Original","Both"};
static const char* const L_CROP[]  = {"None","16:9","3:2","1:1"};
static const char* const L_TIMER[] = {"Off","2s","5s","10s"};
static const char* const L_BRKT[]  = {"Off","+-1 EV","+-2 EV","+-3 EV"};
static const char* const L_DUAL[]  = {"Off","Average","Screen","Multiply","Lighten","Darken","Add","Difference"};
static const char* const L_STYLE[] = {"None","Vivid","Mono","Sepia","Noir","Cross-proc","Faded","Warm","Cool","Game Boy","VHS","CRT","Lomo","Poster","Cyanotype","Thermal"};
static const char* const L_FUNKY[] = {"None","Mirror","Quad mirror","Kaleido","Sketch","Emboss","Glitch","Ghost","Tilt-shift","ASCII","Invert"};
static const char* const L_GRID[]  = {"Off","Thirds","Golden","Diagonal","Cross","4x4","Centre dot"};
static const char* const L_ZEB[]   = {"Off","95%","90%","80%"};
static const char* const L_HIST[]  = {"Off","Luma","RGB"};
static const char* const L_WAVE[]  = {"Off","Luma","RGB"};
static const char* const L_PEAK[]  = {"Off","Red","Green","White"};
static const char* const L_HUD[]   = {"Minimal","Standard","Full"};
static const char* const L_PVM[]   = {"Left eye","Anaglyph","Wiggle","Side-by-side","Right eye"};
static const char* const L_ANA[]   = {"Colour","Half colour","Grey","Optimised"};
static const char* const L_STSAVE[]= {"MPO","L+R JPG","Anaglyph","Wiggle GIF","All"};
static const char* const L_VRES[]  = {"160x120","320x240","640x480"};
static const char* const L_VFPS[]  = {"30","20","15","10","5"};
static const char* const L_STAB[]  = {"Off","Low","Medium","High"};
static const char* const L_YORD[]  = {"YUYV","UYVY"};
static const char* const L_YRNG[]  = {"Full","Limited"};
static const char* const L_PORT[]  = {"8080","8000","8888","3000"};
static const char* const L_THEME[] = {"Cyan","Amber","Green","Mono"};

const SDef g_defs[S_COUNT] = {
#define X(id,key,name,page,type,mn,mx,st,lab,lo,pr,ip) {key,name,page,type,mn,mx,st,lab,lo,pr,ip},
SETTINGS(X)
#undef X
};
const char* const g_page_names[P_COUNT] = {"CAM","CAP","STY","OVR","3D","VID","SYS"};

int S[S_COUNT];
static int lofi_v[S_COUNT], pro_v[S_COUNT];
#define DIR "/3ds/procam"

static int clampi(int v,int a,int b){ return v<a?a:(v>b?b:v); }
static int storable(int i){ return g_defs[i].type != T_ACT; }

static void defaults(void){
    for(int i=0;i<S_COUNT;i++){ lofi_v[i]=g_defs[i].lofi; pro_v[i]=g_defs[i].pro; S[i]=g_defs[i].pro; }
}
static void write_arr(const char* path,const int* a){
    FILE* f=fopen(path,"w"); if(!f) return;
    for(int i=0;i<S_COUNT;i++) if(storable(i)) fprintf(f,"%s=%d\n",g_defs[i].key,a[i]);
    fclose(f);
}
static int read_arr(const char* path,int* a){
    FILE* f=fopen(path,"r"); if(!f) return 0;
    char line[96];
    while(fgets(line,sizeof line,f)){
        char* eq=strchr(line,'='); if(!eq) continue; *eq=0;
        for(int i=0;i<S_COUNT;i++) if(storable(i) && !strcmp(line,g_defs[i].key)){
            a[i]=clampi(atoi(eq+1),g_defs[i].min,g_defs[i].max); break; }
    }
    fclose(f); return 1;
}
void settings_init(void){
    mkdir("/3ds",0777); mkdir(DIR,0777);
    defaults();
    read_arr(DIR"/lofi.cfg",lofi_v); read_arr(DIR"/pro.cfg",pro_v); read_arr(DIR"/settings.cfg",S);
}
void settings_save(void){ write_arr(DIR"/settings.cfg",S); }
void settings_balance(void){
    int t=S[S_BAL];
    for(int i=0;i<S_COUNT;i++){
        const SDef* d=&g_defs[i]; if(!storable(i)||d->interp<0) continue;
        int a=lofi_v[i], b=pro_v[i], v;
        if(d->interp==1){ v=a+((b-a)*t+(b>a?50:-50))/100; if(d->step>1) v=(v/d->step)*d->step; }
        else v=(t>=50)?b:a;
        S[i]=clampi(v,d->min,d->max);
    }
}
void settings_set_ends(int pro){
    int* a=pro?pro_v:lofi_v;
    for(int i=0;i<S_COUNT;i++) if(storable(i)&&g_defs[i].interp>=0) a[i]=S[i];
    write_arr(pro?DIR"/pro.cfg":DIR"/lofi.cfg",a);
}
void settings_reset(void){ defaults(); remove(DIR"/lofi.cfg"); remove(DIR"/pro.cfg"); settings_save(); }
int settings_profile(int slot,int save){
    char p[64]; snprintf(p,sizeof p,DIR"/profile%d.cfg",slot);
    if(save){ write_arr(p,S); return 1; }
    int keep=S[S_PROF]; int ok=read_arr(p,S); S[S_PROF]=keep; return ok;
}
void setting_adjust(int id,int dir){
    const SDef* d=&g_defs[id]; if(d->type==T_ACT) return;
    int v=S[id]+dir*d->step;
    if(d->type==T_BOOL||d->type==T_ENUM){ if(v>d->max) v=d->min; if(v<d->min) v=d->max; }
    S[id]=clampi(v,d->min,d->max);
    if(id==S_BAL) settings_balance();
}
const char* setting_text(int id,char* buf,int n){
    const SDef* d=&g_defs[id];
    switch(d->type){
        case T_BOOL: snprintf(buf,n,"%s",S[id]?"ON":"off"); break;
        case T_ENUM: snprintf(buf,n,"%s",d->labels[S[id]-d->min]); break;
        case T_INT:  snprintf(buf,n,"%d",S[id]); break;
        default: buf[0]=0;
    }
    return buf;
}
