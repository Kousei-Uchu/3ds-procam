#pragma once
// Wi-Fi share mode: tiny HTTP server + QR code so a phone can browse/download photos.
void share_run(void);      // blocks until B is pressed; draws its own screens
