#pragma once
// Log exporter: lists the saved diagnostic runs (newest first) and sends the chosen one to a phone,
// either as a QR code that opens a "COPY ALL" page served by the 3DS over Wi-Fi, or, with no Wi-Fi,
// as a series of text QR codes.
void logs_run(void);      // blocks until the user leaves; draws its own screens
