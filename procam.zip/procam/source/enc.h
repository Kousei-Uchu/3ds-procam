#pragma once
#include <stdint.h>
#include <stddef.h>
int    enc_jpg(const char* path, const uint8_t* rgb, int w, int h, int q);
int    enc_png(const char* path, const uint8_t* rgb, int w, int h);
int    enc_bmp(const char* path, const uint8_t* rgb, int w, int h);
int    enc_file(const char* path, const void* data, size_t n);
size_t enc_jpg_mem(const uint8_t* rgb, int w, int h, int q, uint8_t** out);   // caller free()s
int    enc_mpo(const char* path, const uint8_t* L, const uint8_t* R, int w, int h, int q);
int    enc_gif(const char* path, const uint8_t* const* frames, int n, int w, int h, int delay_cs, int dither);
size_t mpo_second_offset(const uint8_t* buf, size_t len);                    // 0 if not an MPO

typedef struct Avi Avi;
Avi* avi_open(const char* path, int w, int h, int audio, int rate);
int  avi_video(Avi* a, const uint8_t* jpg, size_t n);
int  avi_audio(Avi* a, const int16_t* pcm, int samples);
int  avi_close(Avi* a, double fps);
