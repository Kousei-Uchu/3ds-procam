#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "img.h"
#include "third/font8x8_basic.h"

#define CL(v) ((v)<0?0:((v)>255?255:(v)))
static inline uint8_t c8(int v){ return (uint8_t)CL(v); }
static inline int lum(const uint8_t* p){ return (77*p[0]+150*p[1]+29*p[2])>>8; }
static inline uint32_t xs(uint32_t* s){ uint32_t x=*s; x^=x<<13; x^=x>>17; x^=x<<5; return *s=x; }

static uint8_t* g_tmp; static size_t g_tmpcap;
static uint8_t* tmpbuf(size_t n){ if(n>g_tmpcap){ free(g_tmp); g_tmp=(uint8_t*)malloc(n); g_tmpcap=g_tmp?n:0; } return g_tmp; }
static uint8_t* g_tmp2; static size_t g_tmp2cap;
static uint8_t* tmpbuf2(size_t n){ if(n>g_tmp2cap){ free(g_tmp2); g_tmp2=(uint8_t*)malloc(n); g_tmp2cap=g_tmp2?n:0; } return g_tmp2; }
static uint8_t* g_ghost; static int g_gw,g_gh;
static uint8_t* g_vig; static int g_vw,g_vh;
static int32_t* g_kmap; static int g_kw,g_kh;
void img_free_caches(void){ free(g_tmp);free(g_tmp2);free(g_ghost);free(g_vig);free(g_kmap); g_tmp=g_tmp2=g_ghost=g_vig=0; g_kmap=0; g_tmpcap=g_tmp2cap=0; g_gw=g_gh=g_vw=g_vh=g_kw=g_kh=0; }

/* ---------------- conversions ---------------- */
void yuv_to_rgb(const uint8_t* s, uint8_t* o, int w, int h, int uyvy, int lim){
    int n=w*h/2;
    for(int i=0;i<n;i++,s+=4,o+=6){
        int y0,y1,u,v;
        if(uyvy){ u=s[0]; y0=s[1]; v=s[2]; y1=s[3]; } else { y0=s[0]; u=s[1]; y1=s[2]; v=s[3]; }
        u-=128; v-=128;
        int rr,gg,bb;
        if(!lim){ rr=(359*v)>>8; gg=-((88*u+183*v)>>8); bb=(454*u)>>8; }
        else { rr=(409*v)>>8; gg=-((100*u+208*v)>>8); bb=(516*u)>>8; y0=((y0-16)*298)>>8; y1=((y1-16)*298)>>8; }
        o[0]=c8(y0+rr); o[1]=c8(y0+gg); o[2]=c8(y0+bb);
        o[3]=c8(y1+rr); o[4]=c8(y1+gg); o[5]=c8(y1+bb);
    }
}
void rgb565_to_rgb(const uint16_t* in, uint8_t* o, int n){
    for(int i=0;i<n;i++){ uint16_t p=in[i]; int r=(p>>11)&31,g=(p>>5)&63,b=p&31;
        o[0]=(uint8_t)((r<<3)|(r>>2)); o[1]=(uint8_t)((g<<2)|(g>>4)); o[2]=(uint8_t)((b<<3)|(b>>2)); o+=3; }
}

/* RGB565 -> RGB888 keeping every second pixel of every second row (a quarter of the work). */
void rgb565_to_rgb_half(const uint16_t* in, int sw, int sh, uint8_t* o){
    for(int y=0;y<sh;y+=2){ const uint16_t* r=in+(size_t)y*sw;
        for(int x=0;x<sw;x+=2){ uint16_t p=r[x]; int pr=(p>>11)&31,pg=(p>>5)&63,pb=p&31;
            o[0]=(uint8_t)((pr<<3)|(pr>>2)); o[1]=(uint8_t)((pg<<2)|(pg>>4)); o[2]=(uint8_t)((pb<<3)|(pb>>2)); o+=3; } }
}

/* ---------------- looks ---------------- */
static inline float sm(float x){ x=x<0?0:(x>1?1:x); return x*x*(3-2*x); }
static inline float cl1(float x){ return x<0?0:(x>1?1:x); }

static void style_px(int s,int x,float* R,float* G,float* B){
    float r=*R,g=*G,b=*B, y=0.299f*r+0.587f*g+0.114f*b;
    switch(s){
    case 1: r=y+(r-y)*1.4f; g=y+(g-y)*1.4f; b=y+(b-y)*1.4f; r=(r-.5f)*1.1f+.5f; g=(g-.5f)*1.1f+.5f; b=(b-.5f)*1.1f+.5f; break;
    case 2: r=g=b=y; break;
    case 3: { float nr=.393f*r+.769f*g+.189f*b, ng=.349f*r+.686f*g+.168f*b, nb=.272f*r+.534f*g+.131f*b; r=nr;g=ng;b=nb; } break;
    case 4: y=sm((y-.5f)*1.5f+.5f); r=g=b=y; break;
    case 5: r=sm(r)*1.05f+.03f; g=powf(cl1(g),.9f); b=.2f+b*.65f; break;
    case 6: y=y; r=y+(r-y)*.7f; g=y+(g-y)*.7f; b=y+(b-y)*.7f; r=.12f+r*.8f; g=.12f+g*.8f; b=.14f+b*.8f; break;
    case 7: r*=1.12f; g*=1.02f; b*=.86f; break;
    case 8: r*=.9f; b*=1.12f; break;
    case 9: { static const uint8_t pal[4][3]={{15,56,15},{48,98,48},{139,172,15},{155,188,15}};
        int i=(int)(cl1(y)*3.999f); r=pal[i][0]/255.f; g=pal[i][1]/255.f; b=pal[i][2]/255.f; } break;
    case 10: r=y+(r-y)*1.25f; g=y+(g-y)*1.1f; b=y+(b-y)*1.25f+.03f; r=.06f+r*.92f; g=.05f+g*.92f; b=.08f+b*.92f; break;
    case 11: { int m=x%3; r=(r-.5f)*1.15f+.5f; g=(g-.5f)*1.15f+.5f; b=(b-.5f)*1.15f+.5f;
        if(m!=0) r*=.72f; if(m!=1) g*=.72f; if(m!=2) b*=.72f; r*=1.2f; g*=1.2f; b*=1.2f; } break;
    case 12: r=sm(r*1.05f); g=sm(g)*.98f; b=.1f+sm(b)*.85f; { float yy=0.299f*r+0.587f*g+0.114f*b; r=yy+(r-yy)*1.3f; g=yy+(g-yy)*1.3f; b=yy+(b-yy)*1.3f; } break;
    case 13: r=y*.75f; g=.08f+y*.84f; b=.2f+y*.8f; break;
    case 14: r=floorf(cl1(r)*3.999f)/3.f; g=floorf(cl1(g)*3.999f)/3.f; b=floorf(cl1(b)*3.999f)/3.f; break;
    case 15: { float t=cl1(y)*5.f; int k=(int)t; float f=t-k;
        static const float hp[6][3]={{0,0,.3f},{0,.2f,1},{0,1,.6f},{1,1,0},{1,.2f,0},{1,1,1}};
        if(k>=5){ k=4; f=1; } r=hp[k][0]+(hp[k+1][0]-hp[k][0])*f; g=hp[k][1]+(hp[k+1][1]-hp[k][1])*f; b=hp[k][2]+(hp[k+1][2]-hp[k][2])*f; } break;
    default: break;
    }
    *R=cl1(r); *G=cl1(g); *B=cl1(b);
}

int look_is_neutral(const Look* l){
    return (l->style==0||l->amt==0) && !l->bright && !l->con && !l->sat && !l->temp && !l->tint && !l->vign && !l->grain &&
           !l->scan && !l->crush && !l->soft && l->pix<=1 && !l->funky;
}

static void blur_pass(const uint8_t* in,uint8_t* out,int w,int h,int r,int vertical){
    int n=2*r+1, len=vertical?h:w, cnt=vertical?w:h, st=vertical?w*3:3, lst=vertical?3:w*3;
    /* The 3DS CPU has no hardware divider, so sum/n per sample was very slow. sum*recip>>16 gives the same
       result for every sum up to 255*n (recip is rounded up from 65536/n). */
    uint32_t recip=65536u/(uint32_t)n+1;
    for(int l=0;l<cnt;l++) for(int c=0;c<3;c++){
        const uint8_t* ip=in+l*lst+c; uint8_t* op=out+l*lst+c; int sum=0;
        for(int i=-r;i<=r;i++){ int k=i<0?0:(i>=len?len-1:i); sum+=ip[k*st]; }
        for(int i=0;i<len;i++){ op[i*st]=(uint8_t)(((uint32_t)sum*recip)>>16);
            int a=i+r+1; if(a>=len) a=len-1; int b=i-r; if(b<0) b=0; sum+=ip[a*st]-ip[b*st]; }
    }
}
static void box_blur(const uint8_t* in,uint8_t* out,int w,int h,int r){
    uint8_t* t=tmpbuf2((size_t)w*h*3); if(!t){ memcpy(out,in,(size_t)w*h*3); return; }
    blur_pass(in,t,w,h,r,0); blur_pass(t,out,w,h,r,1);
}

static void funky_apply(uint8_t* p,int w,int h,int mode,int amt,uint32_t seed){
    size_t sz=(size_t)w*h*3;
    switch(mode){
    case 1: for(int y=0;y<h;y++) for(int x=0;x<w/2;x++) memcpy(p+(y*w+w-1-x)*3,p+(y*w+x)*3,3); break;
    case 2: for(int y=0;y<h/2;y++) for(int x=0;x<w/2;x++){ const uint8_t* s=p+(y*w+x)*3;
        memcpy(p+(y*w+w-1-x)*3,s,3); memcpy(p+((h-1-y)*w+x)*3,s,3); memcpy(p+((h-1-y)*w+w-1-x)*3,s,3); } break;
    case 3: { uint8_t* t=tmpbuf(sz); if(!t) break;
        if(g_kw!=w||g_kh!=h||!g_kmap){ free(g_kmap); g_kmap=(int32_t*)malloc((size_t)w*h*4); g_kw=w; g_kh=h; if(!g_kmap) break;
            float cx=w/2.f, cy=h/2.f, seg=3.14159265f/3.f;
            for(int y=0;y<h;y++) for(int x=0;x<w;x++){ float dx=x-cx, dy=y-cy, r=sqrtf(dx*dx+dy*dy), a=atan2f(dy,dx)+3.14159265f;
                a=fmodf(a,2*seg); if(a>seg) a=2*seg-a; a+=0.3f;
                int sx=(int)(cx+r*cosf(a)), sy=(int)(cy+r*sinf(a)); sx=sx<0?0:(sx>=w?w-1:sx); sy=sy<0?0:(sy>=h?h-1:sy);
                g_kmap[y*w+x]=sy*w+sx; } }
        memcpy(t,p,sz); for(int i=0;i<w*h;i++) memcpy(p+i*3,t+g_kmap[i]*3,3); } break;
    case 4: case 5: { uint8_t* t=tmpbuf(sz); if(!t) break; memcpy(t,p,sz); int k=1+amt/20;
        for(int y=1;y<h-1;y++) for(int x=1;x<w-1;x++){
            int o=y*w+x; int v;
            if(mode==4){ int gx=lum(t+(o-w+1)*3)+2*lum(t+(o+1)*3)+lum(t+(o+w+1)*3)-lum(t+(o-w-1)*3)-2*lum(t+(o-1)*3)-lum(t+(o+w-1)*3);
                int gy=lum(t+(o+w-1)*3)+2*lum(t+(o+w)*3)+lum(t+(o+w+1)*3)-lum(t+(o-w-1)*3)-2*lum(t+(o-w)*3)-lum(t+(o-w+1)*3);
                v=255-((abs(gx)+abs(gy))*k)/2; }
            else v=128+((lum(t+(o+w+1)*3)-lum(t+(o-w-1)*3))*k);
            uint8_t b=c8(v); p[o*3]=p[o*3+1]=p[o*3+2]=b; } } break;
    case 6: { uint32_t s=seed*2654435761u+1; int bands=1+amt/10, maxs=4+amt/2;
        for(int i=0;i<bands;i++){ int y0=xs(&s)%h, bh=2+xs(&s)%(h/8+1), sh=(int)(xs(&s)%(2*maxs+1))-maxs;
            for(int y=y0;y<y0+bh&&y<h;y++){ uint8_t* row=p+y*w*3; uint8_t* t=tmpbuf((size_t)w*3); if(!t) break; memcpy(t,row,w*3);
                for(int x=0;x<w;x++){ int sx=x+sh; sx=sx<0?0:(sx>=w?w-1:sx); int sr=x+sh*2; sr=sr<0?0:(sr>=w?w-1:sr);
                    row[x*3]=t[sr*3]; row[x*3+1]=t[sx*3+1]; row[x*3+2]=t[sx*3+2]; } } } } break;
    case 7: { if(!g_ghost||g_gw!=w||g_gh!=h){ free(g_ghost); g_ghost=(uint8_t*)malloc(sz); g_gw=w; g_gh=h; if(!g_ghost) break; memcpy(g_ghost,p,sz); }
        int a=amt>90?90:amt; for(size_t i=0;i<sz;i++){ p[i]=(uint8_t)((p[i]*(100-a)+g_ghost[i]*a)/100); } memcpy(g_ghost,p,sz); } break;
    case 8: { uint8_t* bl=(uint8_t*)malloc(sz); if(!bl) break; box_blur(p,bl,w,h,2); box_blur(bl,bl,w,h,2);
        float band=h*0.15f, fall=h*0.25f, cy=h/2.f;
        for(int y=0;y<h;y++){ float d=fabsf(y-cy)-band; int wt=d<=0?0:(int)(cl1(d/fall)*256);
            for(int x=0;x<w*3;x++){ int o=y*w*3+x; p[o]=(uint8_t)(p[o]+((bl[o]-p[o])*wt>>8)); } } free(bl); } break;
    case 9: { static const char ramp[]=" .:-=+*#%@"; uint8_t* t=tmpbuf(sz); if(!t) break; memcpy(t,p,sz);
        for(int cy=0;cy+8<=h;cy+=8) for(int cx=0;cx+8<=w;cx+=8){ int r=0,g=0,b=0;
            for(int j=0;j<8;j+=2) for(int i=0;i<8;i+=2){ const uint8_t* s=t+((cy+j)*w+cx+i)*3; r+=s[0]; g+=s[1]; b+=s[2]; }
            r/=16; g/=16; b/=16; int l=(77*r+150*g+29*b)>>8; char ch=ramp[l*9/255]; const char* gl=font8x8_basic[(unsigned char)ch];
            for(int j=0;j<8;j++) for(int i=0;i<8;i++){ uint8_t* d=p+((cy+j)*w+cx+i)*3; if((gl[j]>>i)&1){ d[0]=c8(r*5/4+30); d[1]=c8(g*5/4+30); d[2]=c8(b*5/4+30);} else d[0]=d[1]=d[2]=0; } } } break;
    case 10: for(size_t i=0;i<sz;i++) p[i]=(uint8_t)(255-p[i]); break;
    default: break;
    }
}

void look_apply(uint8_t* p,int w,int h,const Look* lk){
    if(look_is_neutral(lk)) return;
    size_t npx=(size_t)w*h;
    /* 1) tone LUTs: brightness / contrast / temperature / tint */
    uint8_t lut[3][256]; int adj = lk->bright||lk->con||lk->temp||lk->tint;
    if(adj){ float cf=1.f+lk->con/50.f, bo=lk->bright/200.f;
        float gain[3]={1.f+lk->temp*.006f, 1.f-lk->tint*.004f, 1.f-lk->temp*.006f};
        for(int c=0;c<3;c++) for(int v=0;v<256;v++){ float x=v/255.f+bo; x=(x-.5f)*cf+.5f; x*=gain[c]; lut[c][v]=(uint8_t)(cl1(x)*255.f+.5f); } }
    int sat=256+lk->sat*256/100; if(sat<0) sat=0;
    int sty=(lk->style&&lk->amt)?lk->style:0, amt=lk->amt;
    if(adj||lk->sat||sty){
        for(int y=0;y<h;y++){ uint8_t* q=p+(size_t)y*w*3;
            for(int x=0;x<w;x++,q+=3){
                int r=q[0],g=q[1],b=q[2];
                if(adj){ r=lut[0][r]; g=lut[1][g]; b=lut[2][b]; }
                if(lk->sat){ int yy=(77*r+150*g+29*b)>>8; r=yy+(((r-yy)*sat)>>8); g=yy+(((g-yy)*sat)>>8); b=yy+(((b-yy)*sat)>>8); r=CL(r); g=CL(g); b=CL(b); }
                if(sty){ float fr=r/255.f,fg=g/255.f,fb=b/255.f; style_px(sty,x,&fr,&fg,&fb);
                    int sr=(int)(fr*255+.5f), sg=(int)(fg*255+.5f), sb=(int)(fb*255+.5f);
                    r+=((sr-r)*amt)/100; g+=((sg-g)*amt)/100; b+=((sb-b)*amt)/100; }
                q[0]=(uint8_t)r; q[1]=(uint8_t)g; q[2]=(uint8_t)b;
            } }
        if(sty==10 && amt){ /* VHS chroma bleed: shift red right, blue left */
            for(int y=0;y<h;y++){ uint8_t* row=p+(size_t)y*w*3; for(int x=w-1;x>=2;x--) row[x*3]=(uint8_t)((row[x*3]*(100-amt)+row[(x-2)*3]*amt)/100);
                for(int x=0;x<w-2;x++) row[x*3+2]=(uint8_t)((row[x*3+2]*(100-amt)+row[(x+2)*3+2]*amt)/100); } }
    }
    /* 2) pixelate */
    if(lk->pix>1){ int k=lk->pix; for(int by=0;by<h;by+=k) for(int bx=0;bx<w;bx+=k){ int r=0,g=0,b=0,n=0;
        for(int j=by;j<by+k&&j<h;j++) for(int i=bx;i<bx+k&&i<w;i++){ const uint8_t* s=p+((size_t)j*w+i)*3; r+=s[0]; g+=s[1]; b+=s[2]; n++; }
        r/=n; g/=n; b/=n;
        for(int j=by;j<by+k&&j<h;j++) for(int i=bx;i<bx+k&&i<w;i++){ uint8_t* d=p+((size_t)j*w+i)*3; d[0]=(uint8_t)r; d[1]=(uint8_t)g; d[2]=(uint8_t)b; } } }
    /* 3) softness */
    if(lk->soft>0){ uint8_t* bl=tmpbuf(npx*3); if(bl){ box_blur(p,bl,w,h,1); int a=lk->soft*256/100;
        for(size_t i=0;i<npx*3;i++) p[i]=(uint8_t)(p[i]+(((bl[i]-p[i])*a)>>8)); } }
    /* 4) funky */
    if(lk->funky) funky_apply(p,w,h,lk->funky,lk->famt,lk->seed);
    /* 5) vignette / scanlines / grain / colour crush */
    if(lk->vign>0){
        if(!g_vig||g_vw!=w||g_vh!=h){ free(g_vig); g_vig=(uint8_t*)malloc(npx); g_vw=w; g_vh=h;
            if(g_vig) for(int y=0;y<h;y++) for(int x=0;x<w;x++){ float dx=(x-w/2.f)/(w/2.f), dy=(y-h/2.f)/(h/2.f); float d=(dx*dx+dy*dy)*.5f; g_vig[y*w+x]=(uint8_t)(cl1(d)*255); } }
        if(g_vig){ int k=lk->vign*205/100; for(size_t i=0;i<npx;i++){ int f=256-((k*g_vig[i])>>8); uint8_t* q=p+i*3; q[0]=(uint8_t)((q[0]*f)>>8); q[1]=(uint8_t)((q[1]*f)>>8); q[2]=(uint8_t)((q[2]*f)>>8); } } }
    if(lk->scan>0){ int f=256-lk->scan*150/100; for(int y=1;y<h;y+=2){ uint8_t* q=p+(size_t)y*w*3; for(int i=0;i<w*3;i++) q[i]=(uint8_t)((q[i]*f)>>8); } }
    if(lk->grain>0){ uint32_t s=lk->seed*747796405u+2891336453u; int k=lk->grain;
        for(size_t i=0;i<npx;i++){ int n=((int)(xs(&s)&255)-128)*k/400; uint8_t* q=p+i*3; q[0]=c8(q[0]+n); q[1]=c8(q[1]+n); q[2]=c8(q[2]+n); } }
    if(lk->crush>0){ int bits=8-lk->crush/20; if(bits<3) bits=3; int sh=8-bits, step=1<<sh;
        static const uint8_t bay[16]={0,8,2,10,12,4,14,6,3,11,1,9,15,7,13,5};
        if(sh>0){                                       /* sh==0 is 8 bit: nothing to quantise, skip the whole pass */
            for(int y=0;y<h;y++){ uint8_t* q=p+(size_t)y*w*3;
                for(int x=0;x<w;x++,q+=3){ int o=lk->dither?((bay[(y&3)*4+(x&3)]*step>>4)-step/2):0;
                    for(int c=0;c<3;c++){ int v=q[c]+o+step/2; if(v<0) v=0; q[c]=c8((v>>sh)<<sh); } } } } }
}

/* ---------------- analysis & overlays ---------------- */
void hist_calc(const uint8_t* p,int w,int h,Hist* o){
    memset(o,0,sizeof *o);
    for(int y=0;y<h;y+=2){ const uint8_t* q=p+(size_t)y*w*3;
        for(int x=0;x<w;x+=2,q+=6){ int l=lum(q); o->l[l>>2]++; o->r[q[0]>>2]++; o->g[q[1]>>2]++; o->b[q[2]>>2]++;
            if(l>=250) o->hi++; if(l<=4) o->lo++; o->n++; } }
}
void ov_zebra(uint8_t* p,int w,int h,int thr,int ph){
    for(int y=0;y<h;y++){ uint8_t* q=p+(size_t)y*w*3;
        for(int x=0;x<w;x++,q+=3) if(lum(q)>=thr){ uint8_t v=(((x+y+ph)>>2)&1)?0:255; q[0]=q[1]=q[2]=v; } }
}
void ov_peaking(uint8_t* p,int w,int h,int color){
    uint8_t* t=tmpbuf((size_t)w*h); if(!t) return;
    for(int i=0;i<w*h;i++) t[i]=(uint8_t)lum(p+i*3);
    static const uint8_t col[3][3]={{255,40,40},{40,255,40},{255,255,255}}; const uint8_t* c=col[color>0?color-1:0];
    for(int y=1;y<h-1;y++) for(int x=1;x<w-1;x++){ int o=y*w+x;
        int g=abs(t[o+1]-t[o-1])+abs(t[o+w]-t[o-w]); if(g>44){ uint8_t* q=p+o*3; q[0]=c[0]; q[1]=c[1]; q[2]=c[2]; } }
}
void ov_falsecolor(uint8_t* p,int w,int h){
    static const struct { int hi; uint8_t c[3]; } z[]={{10,{120,0,180}},{40,{0,60,200}},{90,{0,170,170}},{115,{40,170,40}},{140,{110,190,70}},
        {175,{210,150,160}},{215,{235,235,100}},{245,{255,150,0}},{256,{255,0,0}}};
    for(int i=0;i<w*h;i++){ uint8_t* q=p+i*3; int l=lum(q); int k=0; while(l>=z[k].hi) k++; q[0]=z[k].c[0]; q[1]=z[k].c[1]; q[2]=z[k].c[2]; }
}
void ov_clip(uint8_t* p,int w,int h,int ph){
    for(int i=0;i<w*h;i++){ uint8_t* q=p+i*3;
        if(q[0]>=250&&q[1]>=250&&q[2]>=250){ if(ph&1){ q[0]=255; q[1]=0; q[2]=0; } }
        else if(q[0]<=3&&q[1]<=3&&q[2]<=3){ if(ph&1){ q[0]=0; q[1]=60; q[2]=255; } } }
}
void waveform(const uint8_t* p,int w,int h,int mode,uint8_t* o,int ww,int wh){
    memset(o,0,(size_t)ww*wh*3);
    int pw=mode==2?ww/3:ww;
    for(int y=0;y<h;y+=2){ const uint8_t* q=p+(size_t)y*w*3;
        for(int x=0;x<w;x+=2){ const uint8_t* s=q+x*3; int cx=x*pw/w;
            if(mode==1){ int l=lum(s); uint8_t* d=o+((wh-1-l*(wh-1)/255)*ww+cx)*3; d[1]=(uint8_t)(d[1]>215?255:d[1]+40); d[0]=d[2]=(uint8_t)(d[1]/3); }
            else for(int c=0;c<3;c++){ uint8_t* d=o+((wh-1-s[c]*(wh-1)/255)*ww+c*pw+cx)*3; d[c]=(uint8_t)(d[c]>215?255:d[c]+40); } } }
}

/* ---------------- compositing ---------------- */
void blend_dual(const uint8_t* a,const uint8_t* b,uint8_t* o,int n,int m){
    for(int i=0;i<n;i++){ int x=a[i], y=b[i], v;
        switch(m){ case 1: v=(x+y)>>1; break; case 2: v=255-((255-x)*(255-y)>>8); break; case 3: v=(x*y)>>8; break;
            case 4: v=x>y?x:y; break; case 5: v=x<y?x:y; break; case 6: v=x+y; break; case 7: v=abs(x-y); break; default: v=x; }
        o[i]=c8(v); }
}
void hdr_fuse(const uint8_t* const* im,int k,uint8_t* o,int w,int h){
    static float wl[256]; static int init;
    if(!init){ for(int i=0;i<256;i++){ float d=(i-128)/255.f; wl[i]=expf(-d*d/(2*.2f*.2f))+0.01f; } init=1; }
    for(int i=0;i<w*h;i++){ float sw=0,a[3]={0,0,0};
        for(int j=0;j<k;j++){ const uint8_t* q=im[j]+i*3; float wt=wl[lum(q)]; sw+=wt; a[0]+=q[0]*wt; a[1]+=q[1]*wt; a[2]+=q[2]*wt; }
        o[i*3]=c8((int)(a[0]/sw+.5f)); o[i*3+1]=c8((int)(a[1]/sw+.5f)); o[i*3+2]=c8((int)(a[2]/sw+.5f)); }
}
float sharpness(const uint8_t* p,int w,int h){
    double acc=0; long n=0;
    for(int y=1;y<h-1;y+=2) for(int x=1;x<w-1;x+=2){ int o=y*w+x; int c=lum(p+o*3);
        int l=4*c-lum(p+(o-1)*3)-lum(p+(o+1)*3)-lum(p+(o-w)*3)-lum(p+(o+w)*3); acc+=(double)l*l; n++; }
    return n?(float)(acc/n):0;
}
void crop_rect(int w,int h,int mode,int* x,int* y,int* cw,int* ch){
    int a=w, b=h;
    if(mode==1){ b=w*9/16; if(b>h){ b=h; a=h*16/9; } }
    else if(mode==2){ b=w*2/3; if(b>h){ b=h; a=h*3/2; } }
    else if(mode==3){ a=b=(w<h?w:h); }
    a&=~1; b&=~1; *cw=a; *ch=b; *x=((w-a)/2)&~1; *y=((h-b)/2)&~1;
}
uint8_t* crop_copy(const uint8_t* p,int w,int h,int x,int y,int cw,int ch){
    (void)h; uint8_t* o=(uint8_t*)malloc((size_t)cw*ch*3); if(!o) return 0;
    for(int j=0;j<ch;j++) memcpy(o+(size_t)j*cw*3,p+((size_t)(y+j)*w+x)*3,(size_t)cw*3);
    return o;
}

/* ---------------- stereo ---------------- */
void anaglyph(const uint8_t* L,const uint8_t* R,uint8_t* o,int w,int h,int mode,int shift){
    for(int y=0;y<h;y++) for(int x=0;x<w;x++){
        int xr=x+shift; xr=xr<0?0:(xr>=w?w-1:xr);
        const uint8_t* l=L+((size_t)y*w+x)*3; const uint8_t* r=R+((size_t)y*w+xr)*3; uint8_t* d=o+((size_t)y*w+x)*3;
        switch(mode){
        case 0: d[0]=l[0]; d[1]=r[1]; d[2]=r[2]; break;
        case 1: d[0]=(uint8_t)lum(l); d[1]=r[1]; d[2]=r[2]; break;
        case 2: d[0]=(uint8_t)lum(l); d[1]=d[2]=(uint8_t)lum(r); break;
        default: { float lr=l[0],lg=l[1],lb=l[2],rr=r[0],rg=r[1],rb=r[2];
            d[0]=c8((int)(.456f*lr+.5f*lg+.176f*lb-.043f*rr-.088f*rg-.002f*rb));
            d[1]=c8((int)(-.04f*lr-.038f*lg-.016f*lb+.378f*rr+.734f*rg-.018f*rb));
            d[2]=c8((int)(-.015f*lr-.021f*lg-.005f*lb-.072f*rr-.113f*rg+1.226f*rb)); } }
    }
}
static void gray_ds(const uint8_t* p,int w,int h,int f,uint8_t* o){
    int dw=w/f, dh=h/f;
    for(int y=0;y<dh;y++) for(int x=0;x<dw;x++){ int s=0; for(int j=0;j<f;j++) for(int i=0;i<f;i++) s+=lum(p+((size_t)(y*f+j)*w+x*f+i)*3); o[y*dw+x]=(uint8_t)(s/(f*f)); }
}
/* finds (dx,dy) so that R(x+dx,y+dy) ~ L(x,y) over the centre of the frame */
void align_pair(const uint8_t* L,const uint8_t* R,int w,int h,int* odx,int* ody){
    int f=w>=500?4:2, dw=w/f, dh=h/f; *odx=0; *ody=0;
    uint8_t* a=(uint8_t*)malloc((size_t)dw*dh*2); if(!a) return; uint8_t* b=a+dw*dh;
    gray_ds(L,w,h,f,a); gray_ds(R,w,h,f,b);
    int mx=24/f, my=8/f, x0=dw/4, x1=dw*3/4, y0=dh/4, y1=dh*3/4, bd=0, bdy=0; long best=-1;
    for(int dy=-my;dy<=my;dy++) for(int dx=-mx;dx<=mx;dx++){ long s=0;
        for(int y=y0;y<y1;y++){ const uint8_t* pa=a+y*dw; const uint8_t* pb=b+(y+dy)*dw+dx; for(int x=x0;x<x1;x++) s+=abs(pa[x]-pb[x]); }
        if(best<0||s<best){ best=s; bd=dx; bdy=dy; } }
    free(a);
    int cx=bd*f, cy=bdy*f, rx=cx, ry=cy; best=-1;
    for(int dy=cy-f;dy<=cy+f;dy++) for(int dx=cx-f;dx<=cx+f;dx++){ long s=0;
        for(int y=h/4;y<h*3/4;y+=3){ int yy=y+dy; if(yy<0||yy>=h) continue;
            for(int x=w/4;x<w*3/4;x+=3){ int xx=x+dx; if(xx<0||xx>=w) continue; s+=abs(lum(L+((size_t)y*w+x)*3)-lum(R+((size_t)yy*w+xx)*3)); } }
        if(best<0||s<best){ best=s; rx=dx; ry=dy; } }
    *odx=rx; *ody=ry;
}
void depth_map(const uint8_t* L,const uint8_t* R,int w,int h,uint8_t* d){
    int f=w>=500?4:(w>=300?2:1), dw=w/f, dh=h/f, D=8;
    uint8_t* g=(uint8_t*)malloc((size_t)dw*dh*3); if(!g){ memset(d,128,(size_t)w*h); return; }
    uint8_t* a=g; uint8_t* b=g+dw*dh; uint8_t* dm=g+2*dw*dh;
    if(f==1){ for(int i=0;i<w*h;i++){ a[i]=(uint8_t)lum(L+i*3); b[i]=(uint8_t)lum(R+i*3); } } else { gray_ds(L,w,h,f,a); gray_ds(R,w,h,f,b); }
    for(int y=0;y<dh;y++) for(int x=0;x<dw;x++){ int bestd=0; long best=1L<<30;
        for(int dd=-D;dd<=D;dd++){ long s=0;
            for(int j=-2;j<=2;j++){ int yy=y+j; yy=yy<0?0:(yy>=dh?dh-1:yy);
                for(int i=-2;i<=2;i++){ int xl=x+i, xr=x+i-dd; xl=xl<0?0:(xl>=dw?dw-1:xl); xr=xr<0?0:(xr>=dw?dw-1:xr); s+=abs(a[yy*dw+xl]-b[yy*dw+xr]); } }
            if(s<best){ best=s; bestd=dd; } }
        dm[y*dw+x]=(uint8_t)((bestd+D)*15); }
    /* 3x3 smooth + bilinear-ish upsample */
    for(int y=0;y<h;y++){ int sy=y/f; sy=sy<1?1:(sy>dh-2?dh-2:sy);
        for(int x=0;x<w;x++){ int sx=x/f; sx=sx<1?1:(sx>dw-2?dw-2:sx); int s=0;
            for(int j=-1;j<=1;j++) for(int i=-1;i<=1;i++) s+=dm[(sy+j)*dw+sx+i]; d[y*w+x]=(uint8_t)(s/9); } }
    free(g);
}
void depth_fx(uint8_t* p,const uint8_t* d,int w,int h,int bokeh,int pop){
    if(!bokeh&&!pop) return;
    long s=0,n=0; for(int y=h*2/5;y<h*3/5;y++) for(int x=w*2/5;x<w*3/5;x++){ s+=d[y*w+x]; n++; }
    int df=n?(int)(s/n):128; size_t sz=(size_t)w*h*3;
    uint8_t* bl=0; if(bokeh){ bl=(uint8_t*)malloc(sz); if(bl){ box_blur(p,bl,w,h,w>=500?5:3); box_blur(bl,bl,w,h,w>=500?5:3); } }
    for(int i=0;i<w*h;i++){ int dl=abs(d[i]-df); uint8_t* q=p+i*3;
        if(bl){ int wt=(dl-14)*6; wt=wt<0?0:(wt>255?255:wt); wt=wt*bokeh/100; for(int c=0;c<3;c++) q[c]=(uint8_t)(q[c]+(((bl[i*3+c]-q[c])*wt)>>8)); }
        if(pop){ int bg=dl*5; bg=bg>255?255:bg; bg=bg*pop/100; int y=lum(q);
            for(int c=0;c<3;c++){ int v=q[c]+(((y-q[c])*bg)>>8); v-=(v*bg)>>10; q[c]=c8(v); } } }
    free(bl);
}
void depth_to_rgb(const uint8_t* d,uint8_t* o,int w,int h){
    for(int i=0;i<w*h;i++){ int v=d[i]; o[i*3]=(uint8_t)v; o[i*3+1]=(uint8_t)(255-abs(v-128)*2); o[i*3+2]=(uint8_t)(255-v); }
}

/* ---------------- people (experimental) & stabilisation ---------------- */
int person_detect(const uint8_t* p,int w,int h,Box* out,int max){
    int cs=w>=500?8:4, gw=w/cs, gh=h/cs; if(gw*gh>8000||gw<4) return 0;
    uint8_t* m=(uint8_t*)calloc(gw*gh,1); int* st=(int*)malloc(gw*gh*sizeof(int)); if(!m||!st){ free(m); free(st); return 0; }
    for(int y=0;y<gh;y++) for(int x=0;x<gw;x++){ int r=0,g=0,b=0;
        for(int j=0;j<cs;j+=2) for(int i=0;i<cs;i+=2){ const uint8_t* q=p+((size_t)(y*cs+j)*w+x*cs+i)*3; r+=q[0]; g+=q[1]; b+=q[2]; }
        int n=(cs/2)*(cs/2); r/=n; g/=n; b/=n;
        int Y=(77*r+150*g+29*b)>>8, Cb=128+((-43*r-85*g+128*b)>>8), Cr=128+((128*r-107*g-21*b)>>8);
        if(Cb>=77&&Cb<=127&&Cr>=133&&Cr<=173&&Y>50&&Y<240&&r>g&&r>b) m[y*gw+x]=1; }
    int cnt=0; Box cand[16]; int area[16];
    for(int s0=0;s0<gw*gh&&cnt<16;s0++){ if(m[s0]!=1) continue;
        int sp=0,minx=gw,miny=gh,maxx=0,maxy=0,a=0; st[sp++]=s0; m[s0]=2;
        while(sp){ int c=st[--sp]; int cx=c%gw, cy=c/gw; a++; if(cx<minx)minx=cx; if(cx>maxx)maxx=cx; if(cy<miny)miny=cy; if(cy>maxy)maxy=cy;
            const int nx[4]={cx-1,cx+1,cx,cx}, ny[4]={cy,cy,cy-1,cy+1};
            for(int k=0;k<4;k++){ if(nx[k]<0||nx[k]>=gw||ny[k]<0||ny[k]>=gh) continue; int ni=ny[k]*gw+nx[k]; if(m[ni]==1){ m[ni]=2; st[sp++]=ni; } } }
        int bw=maxx-minx+1, bh=maxy-miny+1; float ar=(float)bw/bh;
        if(a>=10 && ar>.45f && ar<1.7f && a*10>bw*bh*4){ cand[cnt]=(Box){minx*cs,miny*cs,bw*cs,bh*cs}; area[cnt]=a; cnt++; } }
    int outn=0; for(int k=0;k<max&&k<cnt;k++){ int bi=-1; for(int i=0;i<cnt;i++) if(area[i]>0&&(bi<0||area[i]>area[bi])) bi=i; if(bi<0) break; out[outn++]=cand[bi]; area[bi]=0; }
    free(m); free(st); return outn;
}
void stab_update(Stab* s,const uint8_t* p,int w,int h,int strength,int* ox,int* oy){
    *ox=*oy=0; if(strength<=0){ s->have=0; return; }
    int f=w/80; if(f<1) f=1; int gw=w/f, gh=h/f; if(gw>80) gw=80; if(gh>60) gh=60;
    uint8_t cur[80*60]; for(int y=0;y<gh;y++) for(int x=0;x<gw;x++){ int t=0; for(int j=0;j<f;j+=2) for(int i=0;i<f;i+=2) t+=lum(p+((size_t)(y*f+j)*w+x*f+i)*3); int n=((f+1)/2)*((f+1)/2); cur[y*80+x]=(uint8_t)(t/n); }
    if(!s->have){ memcpy(s->prev,cur,sizeof cur); s->have=1; s->px=s->py=s->cx=s->cy=0; return; }
    int bx=0,by=0; long best=1L<<30; const int R=6;
    for(int dy=-R;dy<=R;dy++) for(int dx=-R;dx<=R;dx++){ long sum=0;
        for(int y=R;y<gh-R;y++){ const uint8_t* a=cur+(y+dy)*80+dx; const uint8_t* b=s->prev+y*80; for(int x=R;x<gw-R;x++) sum+=abs(a[x]-b[x]); }
        sum+=(abs(dx)+abs(dy))*gw/2; if(sum<best){ best=sum; bx=dx; by=dy; } }
    memcpy(s->prev,cur,sizeof cur);
    s->px+=bx; s->py+=by;
    static const float alpha[4]={0,.80f,.90f,.95f}; static const float margin[4]={0,3,5,8};
    float a=alpha[strength], mg=margin[strength];
    s->cx=s->cx*a+s->px*(1-a); s->cy=s->cy*a+s->py*(1-a);
    float cx=s->cx-s->px, cy=s->cy-s->py;
    if(cx>mg){ cx=mg; s->cx=s->px+cx; } if(cx<-mg){ cx=-mg; s->cx=s->px+cx; }
    if(cy>mg){ cy=mg; s->cy=s->py+cy; } if(cy<-mg){ cy=-mg; s->cy=s->py+cy; }
    *ox=(int)lrintf(cx*f); *oy=(int)lrintf(cy*f);
}
void translate_clamp(uint8_t* p,int w,int h,int dx,int dy){
    if(!dx&&!dy) return; uint8_t* t=tmpbuf((size_t)w*h*3); if(!t) return; memcpy(t,p,(size_t)w*h*3);
    for(int y=0;y<h;y++){ int sy=y-dy; sy=sy<0?0:(sy>=h?h-1:sy);
        for(int x=0;x<w;x++){ int sx=x-dx; sx=sx<0?0:(sx>=w?w-1:sx); memcpy(p+((size_t)y*w+x)*3,t+((size_t)sy*w+sx)*3,3); } }
}
