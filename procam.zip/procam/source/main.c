// PROCAM - configurable lo-fi <-> pro camera for New 2DS XL / 3DS
#include <3ds.h>
#include <dirent.h>
#include <malloc.h>
#include <math.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "settings.h"
#include "gfx.h"
#include "img.h"
#include "enc.h"
#include "cam.h"
#include "mic.h"
#include "net.h"
#include "ui.h"
#include "gallery.h"
#include "regtool.h"
#include "diag.h"

#define PHOTO_DIR "/DCIM/100NIN03"
#define MAXPX (640*480)
static uint8_t *pvL,*pvR,*disp,*clean,*recbuf,*tmp3,*wavebuf,*dmap;
static uint16_t* acc[2];
static int g_shot_no;

static struct {
    int rec, dirty, sig, phase, persons_n, tl_run, tl_n, dual_have, dual_w, dual_h, blur, frames_in_sec, fps;
    Avi* avi; u64 rec_t0, last_enc, last_fps, timer_end, tl_next, voice_cool, save_due; uint32_t frame, rec_frames;
    float tilt; int tilt_ok; Box persons[4]; Hist hist; Stab stab;
    uint8_t *dual_rgb, *dual_prev;
    char toast[64]; u64 toast_until;
} A;

static u64 now_ms(void){ return osGetTime(); }
static void say(const char* fmt,...){ va_list ap; va_start(ap,fmt); vsnprintf(A.toast,sizeof A.toast,fmt,ap); va_end(ap); A.toast_until=now_ms()+2500; }
static void progress(const char* m){ cv_clear(&g_top,C_BG); cv_text(&g_top,(400-cv_text_w(m))/2,116,m,C_ACC); gfx_present(); }
static void look_cfg(Look* l,uint32_t seed){
    l->style=S[S_STYLE]; l->amt=S[S_SAMT]; l->bright=S[S_BRIGHT]; l->con=S[S_CON]; l->sat=S[S_SAT]; l->temp=S[S_TEMP]; l->tint=S[S_TINT];
    l->vign=S[S_VIGN]; l->grain=S[S_GRAIN]; l->scan=S[S_SCAN]; l->crush=S[S_CRUSH]; l->dither=S[S_DITH]; l->soft=S[S_SOFT];
    l->pix=S[S_PIX]; l->funky=S[S_FUNKY]; l->famt=S[S_FAMT]; l->seed=seed;
}
static void scan_numbers(void){
    DIR* d=opendir(PHOTO_DIR); if(!d) return; struct dirent* e;
    while((e=readdir(d))){ if(!strncmp(e->d_name,"HNI_",4)){ int n=atoi(e->d_name+4); if(n>g_shot_no) g_shot_no=n; } } closedir(d);
}

/* ================= camera session sync ================= */
static void vf_sync_camera(int force){
    int src=S[S_SRC], size=A.rec?S[S_VRES]:1, fps=A.rec?S[S_VFPS]:S[S_FPS], sig=(S[S_EXPM]==3)?100+S[S_SHUT]:0;
    if(force||!g_cam.active||g_cam.src!=src||g_cam.size!=size||g_cam.fmt!=0||g_cam.fps!=fps||A.sig!=sig){
        A.sig=sig; progress("Starting camera..."); if(!cam_start(src,size,0,fps)) say("Camera start failed"); A.stab.have=0; A.dirty=1; }
    if(A.dirty){ cam_apply_params(); A.dirty=0; }
}

/* ================= still capture ================= */
typedef struct { uint8_t* rgb[2]; uint8_t* nat[2]; int w,h,fmt,stereo; } Shot;
static void shot_free(Shot* s){ for(int e=0;e<2;e++){ free(s->rgb[e]); free(s->nat[e]); } memset(s,0,sizeof *s); }
static int shot_grab(Shot* s,int nstack){
    memset(s,0,sizeof *s); int w=g_cam.w,h=g_cam.h,fmt=g_cam.fmt,eyes=g_cam.stereo?2:1; size_t px=(size_t)w*h;
    s->w=w; s->h=h; s->fmt=fmt; s->stereo=g_cam.stereo;
    for(int e=0;e<eyes;e++){ s->rgb[e]=(uint8_t*)malloc(px*3); s->nat[e]=(uint8_t*)malloc(px*2); if(!s->rgb[e]||!s->nat[e]){ shot_free(s); return 0; }
        memset(acc[e],0,px*(fmt?2:3)*2); }
    int got=0, fails=0;
    while(got<nstack){
        if(!cam_grab(600)){ if(++fails>8) break; continue; }
        for(int e=0;e<eyes;e++){
            if(fmt){ const uint8_t* b=g_cam.buf[e]; uint16_t* a=acc[e]; for(size_t i=0;i<px*2;i++) a[i]+=b[i]; }
            else { rgb565_to_rgb((const uint16_t*)g_cam.buf[e],tmp3,(int)px); uint16_t* a=acc[e]; for(size_t i=0;i<px*3;i++) a[i]+=tmp3[i]; } }
        got++;
    }
    if(!got){ shot_free(s); return 0; }
    for(int e=0;e<eyes;e++){ uint16_t* a=acc[e];
        if(fmt){ for(size_t i=0;i<px*2;i++) s->nat[e][i]=(uint8_t)(a[i]/got); yuv_to_rgb(s->nat[e],s->rgb[e],w,h,S[S_YORD],S[S_YRNG]); }
        else { for(size_t i=0;i<px*3;i++) s->rgb[e][i]=(uint8_t)(a[i]/got); memcpy(s->nat[e],g_cam.buf[e],px*2); } }
    return 1;
}
static int save_sidecar(const char* base,const Shot* s,int no){
    char p[96]; snprintf(p,sizeof p,"%s.TXT",base); FILE* f=fopen(p,"w"); if(!f) return 0;
    fprintf(f,"PROCAM shot %d\nsize=%dx%d\nsensor_pipe=%s\nraw_layout=%s\nstack=%d\n",no,s->w,s->h,s->fmt?"YUV422":"RGB565",s->fmt?(S[S_YORD]?"UYVY":"YUYV"):"RGB565 LE",1<<S[S_STACK]);
    for(int i=0;i<S_COUNT;i++) if(g_defs[i].type!=T_ACT){ char b[40]; fprintf(f,"%s=%s\n",g_defs[i].key,setting_text(i,b,sizeof b)); }
    fclose(f); return 1;
}
static void wiggle_frames(const uint8_t* L,const uint8_t* R,int w,int h,int dx,int dy,uint8_t** fa,uint8_t** fb,int* fw,int* fh){
    *fw=w-abs(dx); *fh=h-abs(dy);
    *fa=crop_copy(L,w,h,dx<0?-dx:0,dy<0?-dy:0,*fw,*fh); *fb=crop_copy(R,w,h,dx>0?dx:0,dy>0?dy:0,*fw,*fh);
}
static int save_shot(const Shot* s){
    int w=s->w,h=s->h,no=++g_shot_no,eyes=s->stereo?2:1,ok=1,q=S[S_JPGQ],fmt=S[S_FMT]; char base[64],p[96];
    snprintf(base,sizeof base,PHOTO_DIR"/HNI_%04d",no);
    int cx,cy,cw,ch; crop_rect(w,h,S[S_CROP],&cx,&cy,&cw,&ch);
    uint8_t *orig[2]={0,0}, *gr[2]={0,0};
    for(int e=0;e<eyes;e++){ orig[e]=crop_copy(s->rgb[e],w,h,cx,cy,cw,ch); gr[e]=(uint8_t*)malloc((size_t)cw*ch*3); if(!orig[e]||!gr[e]){ ok=0; goto done; } memcpy(gr[e],orig[e],(size_t)cw*ch*3); }
    if(s->stereo&&(S[S_BOKEH]||S[S_POP])){ uint8_t* d=(uint8_t*)malloc((size_t)cw*ch);
        if(d){ depth_map(orig[0],orig[1],cw,ch,d); for(int e=0;e<2;e++) depth_fx(gr[e],d,cw,ch,S[S_BOKEH],S[S_POP]); free(d); } }
    for(int e=0;e<eyes;e++){ Look lk; look_cfg(&lk,(uint32_t)(no*2+e)); look_apply(gr[e],cw,ch,&lk); }
    { const uint8_t* mainimg=(S[S_LOOK]==1)?orig[0]:gr[0];
      if(fmt==0||fmt==3){ snprintf(p,sizeof p,"%s.JPG",base); ok&=enc_jpg(p,mainimg,cw,ch,q); }
      else if(fmt==1){ snprintf(p,sizeof p,"%s.PNG",base); ok&=enc_png(p,mainimg,cw,ch); }
      else if(fmt==2){ snprintf(p,sizeof p,"%s.BMP",base); ok&=enc_bmp(p,mainimg,cw,ch); }
      if(S[S_LOOK]==2){ snprintf(p,sizeof p,"%s_O.JPG",base); ok&=enc_jpg(p,orig[0],cw,ch,q); }
      if(fmt>=3){ snprintf(p,sizeof p,"%s.%s",base,s->fmt?"YUV":"565"); ok&=enc_file(p,s->nat[0],(size_t)w*h*2); if(s->stereo){ snprintf(p,sizeof p,"%s_R.%s",base,s->fmt?"YUV":"565"); enc_file(p,s->nat[1],(size_t)w*h*2); } } }
    if(s->stereo){ int st=S[S_STSAVE], conv=S[S_CONV]*cw/320;
        if(st==0||st==4){ snprintf(p,sizeof p,"%s.MPO",base); ok&=enc_mpo(p,gr[0],gr[1],cw,ch,q); }
        if(st==1||st==4){ snprintf(p,sizeof p,"%s_R.JPG",base); ok&=enc_jpg(p,gr[1],cw,ch,q); }
        if(st==2||st==4){ uint8_t* a=(uint8_t*)malloc((size_t)cw*ch*3); if(a){ anaglyph(gr[0],gr[1],a,cw,ch,S[S_ANA],conv); snprintf(p,sizeof p,"%s_A.JPG",base); ok&=enc_jpg(p,a,cw,ch,q); free(a); } }
        if(st==3||st==4){ int dx=conv,dy=0; if(S[S_WALIGN]) align_pair(gr[0],gr[1],cw,ch,&dx,&dy);
            uint8_t *fa,*fb; int fw,fh; wiggle_frames(gr[0],gr[1],cw,ch,dx,dy,&fa,&fb,&fw,&fh);
            if(fa&&fb){ const uint8_t* fr[2]={fa,fb}; snprintf(p,sizeof p,"%s.GIF",base); ok&=enc_gif(p,fr,2,fw,fh,100/(S[S_WFPS]>0?S[S_WFPS]:8),1); } free(fa); free(fb); } }
    if(S[S_SIDE]) save_sidecar(base,s,no);
done:
    for(int e=0;e<2;e++){ free(orig[e]); free(gr[e]); }
    return ok;
}
static void emit_shot(Shot* s){
    if(S[S_DUAL]){
        if(!A.dual_have){ A.dual_rgb=(uint8_t*)malloc((size_t)s->w*s->h*3); A.dual_prev=(uint8_t*)malloc(320*240*3);
            if(A.dual_rgb&&A.dual_prev){ memcpy(A.dual_rgb,s->rgb[0],(size_t)s->w*s->h*3);
                for(int y=0;y<240;y++) for(int x=0;x<320;x++) memcpy(A.dual_prev+(y*320+x)*3,s->rgb[0]+((size_t)(y*s->h/240)*s->w+x*s->w/320)*3,3);
                A.dual_w=s->w; A.dual_h=s->h; A.dual_have=1; say("Dual: frame the 2nd exposure"); }
            shot_free(s); return; }
        if(A.dual_w==s->w&&A.dual_h==s->h) blend_dual(s->rgb[0],A.dual_rgb,s->rgb[0],s->w*s->h*3,S[S_DUAL]);
        free(A.dual_rgb); free(A.dual_prev); A.dual_rgb=A.dual_prev=0; A.dual_have=0;
    }
    if(!save_shot(s)) say("SAVE FAILED - check SD card"); else say("Saved HNI_%04d",g_shot_no);
    shot_free(s);
}
static void do_capture(void){
    int brk=S[S_BRKT], n=brk?3:S[S_BURST], stk=1<<S[S_STACK], hdr=brk&&S[S_HDR], best=!brk&&S[S_BEST]&&n>1;
    progress("Capturing...");
    /* Only restart the camera when the capture format differs from the live stream. A restart costs
       a second or two of exposure settling, so skipping it makes the shutter feel instant. */
    int same=g_cam.active&&g_cam.src==S[S_SRC]&&g_cam.size==S[S_RES]&&g_cam.fmt==S[S_PIPE];
    if(!same){ if(!cam_start(S[S_SRC],S[S_RES],S[S_PIPE],S[S_FPS])){ say("Camera start failed"); return; } }
    for(int i=0;i<(same?2:6);i++) cam_grab(700);
    cam_shutter_sound(0);
    Shot held[3], bestshot; int nheld=0, havebest=0; float bestsc=-1; memset(held,0,sizeof held); memset(&bestshot,0,sizeof bestshot);
    for(int i=0;i<n;i++){
        char m[48]; snprintf(m,sizeof m,"Capturing %d/%d...",i+1,n); progress(m);
        if(brk){ cam_set_ev(S[S_EV]+(i-1)*brk); for(int k=0;k<5;k++) cam_grab(700); }
        Shot s; if(!shot_grab(&s,stk)) continue;
        if(hdr){ if(nheld<3) held[nheld++]=s; else shot_free(&s); }
        else if(best){ float sc=sharpness(s.rgb[0],s.w,s.h); if(sc>bestsc){ if(havebest) shot_free(&bestshot); bestshot=s; bestsc=sc; havebest=1; } else shot_free(&s); }
        else emit_shot(&s);
    }
    if(brk) cam_apply_params();
    if(hdr&&nheld){ progress("Merging HDR...");
        int eyes=held[0].stereo?2:1; Shot* base=&held[nheld>1?1:0];
        for(int e=0;e<eyes;e++){ const uint8_t* im[3]; for(int k=0;k<nheld;k++) im[k]=held[k].rgb[e]; uint8_t* o=(uint8_t*)malloc((size_t)base->w*base->h*3);
            if(o){ hdr_fuse(im,nheld,o,base->w,base->h); memcpy(base->rgb[e],o,(size_t)base->w*base->h*3); free(o); } }
        Shot out=*base; memset(base,0,sizeof *base); for(int k=0;k<nheld;k++) shot_free(&held[k]); emit_shot(&out); }
    if(havebest){ emit_shot(&bestshot); }
    A.stab.have=0; vf_sync_camera(0);   /* restarts only if the capture format differed from the viewfinder */
}

/* ================= video ================= */
static void rec_start(void){
    A.rec=1; vf_sync_camera(1);
    int w=g_cam.w,h=g_cam.h, stereo=S[S_VST]&&g_cam.stereo; char p[64]; snprintf(p,sizeof p,PHOTO_DIR"/HNI_%04d.AVI",++g_shot_no);
    int aud=S[S_VAUD]&&mic_start();
    A.avi=avi_open(p,stereo?w*2:w,h,aud,MIC_RATE);
    if(!A.avi){ A.rec=0; say("Cannot open video file"); return; }
    A.rec_t0=now_ms(); A.last_enc=0; A.rec_frames=0; cam_shutter_sound(1); say("REC %s",p+strlen(PHOTO_DIR)+1);
}
static void rec_stop(void){
    if(!A.avi) return; double sec=(now_ms()-A.rec_t0)/1000.0; Avi* a=A.avi; A.avi=0; A.rec=0;
    avi_close(a,sec>0?A.rec_frames/sec:15.0); if(!S[S_VOICE]) mic_stop(); cam_shutter_sound(2); say("Video saved (%u frames)",A.rec_frames); vf_sync_camera(1);
}
static void rec_service(const uint8_t* cleanimg,int w,int h){
    int16_t pcm[2048]; int n=mic_read(pcm,2048); if(n>0) avi_audio(A.avi,pcm,n);
    static const int fpsv[5]={30,20,15,10,5}; u64 t=now_ms(); if(t-A.last_enc<(u64)(1000/fpsv[S[S_VFPS]])) return;
    int stereo=S[S_VST]&&g_cam.stereo; const uint8_t* src=cleanimg; int vw=w;
    if(stereo){ vw=w*2; Look lk; look_cfg(&lk,A.frame);
        for(int e=0;e<2;e++){ memcpy(tmp3,e?pvR:pvL,(size_t)w*h*3); look_apply(tmp3,w,h,&lk); for(int y=0;y<h;y++) memcpy(recbuf+((size_t)y*vw+e*w)*3,tmp3+(size_t)y*w*3,(size_t)w*3); }
        src=recbuf; }
    uint8_t* j; size_t jn=enc_jpg_mem(src,vw,h,S[S_VQ],&j); if(jn){ avi_video(A.avi,j,jn); A.rec_frames++; } free(j); A.last_enc=now_ms();
}

/* ================= viewfinder ================= */
static void read_motion(void){
    accelVector ac; angularRate gy; hidAccelRead(&ac); hidGyroRead(&gy);
    float m=sqrtf((float)ac.x*ac.x+(float)ac.y*ac.y+(float)ac.z*ac.z); A.tilt_ok=m>50&&fabsf(ac.z)/m<0.85f;
    if(A.tilt_ok){ A.tilt=atan2f((float)ac.x,(float)-ac.y)*57.29578f; if(S[S_LINV]) A.tilt=-A.tilt; }
    float g=sqrtf((float)gy.x*gy.x+(float)gy.y*gy.y+(float)gy.z*gy.z); A.blur=g>900;
}
static void hud(int x0,int w,int h){
    (void)w;(void)h; char b[24]; int d=S[S_HUD]; uint16_t fg=C_FG, ac=C_ACC; static const char* sn[3]={"OUT","3D","IN"};
    cv_rect(&g_top,0,0,40,240,C_BG); cv_rect(&g_top,360,0,40,240,C_BG); int y=4;
    cv_text(&g_top,2,y,sn[S[S_SRC]],ac); y+=11;
    if(d>=1){ int m=S[S_EXPM];
        if(m==2) snprintf(b,sizeof b,"AE-L"); else if(m==3) snprintf(b,sizeof b,"%s",g_defs[S_SHUT].labels[S[S_SHUT]]); else snprintf(b,sizeof b,"EV%+d",m==1?S[S_EV]:0);
        cv_text(&g_top,2,y,b,fg); y+=11;
        cv_text(&g_top,2,y,S[S_WB]?g_defs[S_WB].labels[S[S_WB]]:"AWB",fg); y+=11;
        static const char* rs[3]={"VGA","QVGA","QQVG"}; cv_text(&g_top,2,y,rs[S[S_RES]],fg); y+=11;
        cv_text(&g_top,2,y,S[S_PIPE]?"YUV":"565",fg); y+=11; }
    if(d>=2){ snprintf(b,sizeof b,"x%d",1<<S[S_STACK]); cv_text(&g_top,2,y,b,fg); y+=11; snprintf(b,sizeof b,"%dfps",A.fps); cv_text(&g_top,2,y,b,fg); y+=11;
        if(S[S_STAB]) { cv_text(&g_top,2,y,"STAB",fg); y+=11; } if(S[S_BRKT]){ cv_text(&g_top,2,y,"BRKT",fg); y+=11; } }
    y=4; if(A.rec){ u64 s=(now_ms()-A.rec_t0)/1000; cv_rect(&g_top,364,y,6,6,C_WARN); snprintf(b,sizeof b,"%u:%02u",(unsigned)(s/60),(unsigned)(s%60)); cv_text(&g_top,362,y+9,b,fg); y+=22; }
    if(A.tl_run){ snprintf(b,sizeof b,"TL%d",A.tl_n); cv_text(&g_top,362,y,b,C_WARN); y+=11; }
    if(A.dual_have){ cv_text(&g_top,362,y,"DUAL",ac); y+=11; }
    if(mic_active()&&S[S_VOICE]){ cv_text(&g_top,362,y,"VOX",ac); y+=11; }
    (void)x0;
}
static int voice_check(void){
    if(!S[S_VOICE]||A.rec){ return 0; } if(!mic_active()) mic_start();
    int16_t pcm[1024]; int n=mic_read(pcm,1024); int peak=0; for(int i=0;i<n;i++){ int v=abs(pcm[i]); if(v>peak) peak=v; }
    int lvl=peak*100/32768*3; return (lvl>S[S_VTH]&&now_ms()>A.voice_cool);
}
/* Everything drawn on top of the picture: guides, level, histogram, HUD, toast, timer. */
static void vf_chrome(u64 t,int w,int h){
    ui_draw_grid(&g_top,40,0,320,240,S[S_GRID]); ui_draw_guide(&g_top,40,0,320,240,S[S_GUIDE]);
    if(S[S_LEVEL]&&A.tilt_ok) ui_draw_level(&g_top,200,120,A.tilt);
    if(S[S_HIST]) ui_draw_hist(&g_top,44,196,72,40,&A.hist,S[S_HIST]);
    if(S[S_WAVE]) cv_blit_rgb(&g_top,284,190,wavebuf,64,48);
    for(int i=0;i<A.persons_n;i++){ Box* b=&A.persons[i]; cv_box(&g_top,40+b->x*320/w,b->y*240/h,b->w*320/w,b->h*240/h,rgb16(255,60,200)); if(i==0) cv_text_bg(&g_top,40+b->x*320/w,b->y*240/h-10,"PERSON?",rgb16(255,60,200),rgb16(0,0,0)); }
    hud(40,w,h);
    if(S[S_CLIP]&&A.hist.n){ if(A.hist.hi*50>A.hist.n) cv_text_bg(&g_top,44,4,"HIGHLIGHTS",C_WARN,rgb16(0,0,0)); }
    if(S[S_BLURW]&&A.blur) cv_text_bg(&g_top,150,4,"SHAKY",C_WARN,rgb16(0,0,0));
    if(A.timer_end){ char b[8]; int s=(int)((A.timer_end-t+999)/1000); snprintf(b,sizeof b,"%d",s); cv_rect(&g_top,176,92,48,56,rgb16(0,0,0)); cv_text(&g_top,196,116,b,C_ACC); }
    if(t<A.toast_until) cv_text_bg(&g_top,44,226,A.toast,C_FG,rgb16(0,0,0));
}
/* True when any per-pixel work is switched on. When nothing is, the sensor frame goes straight to the screen. */
static int vf_needs_processing(const Look* lk){
    return !look_is_neutral(lk)||S[S_STAB]||S[S_PERSON]||S[S_DEPTHV]||S[S_HIST]||S[S_CLIP]||S[S_WAVE]||
           S[S_FALSE]||S[S_PEAK]||S[S_ZEB]||A.dual_have||A.avi;
}
static void vf_frame(void){
    /* 500 ms: the sensor drops to 5 fps in the dark or with slow shutter priority, so a short timeout
       would keep declaring a healthy camera dead and restarting it. */
    if(!cam_grab(500)){ cv_clear(&g_top,C_BG); cv_text(&g_top,120,116,"Waiting for camera...",C_FG); return; }
    int w=g_cam.w,h=g_cam.h,stereo=g_cam.stereo; A.frame++; A.phase=(int)(A.frame/3);
    u64 t=now_ms(); A.frames_in_sec++; if(t-A.last_fps>=1000){ A.fps=A.frames_in_sec; A.frames_in_sec=0; A.last_fps=t; }
    int pvm=S[S_PVM]; if(!stereo) pvm=0;
    Look lk; look_cfg(&lk,A.frame);
    int heavy=vf_needs_processing(&lk);

    /* Fast path: mono, nothing to process, 320x240 -> copy RGB565 straight into the canvas. */
    if(!heavy&&pvm==0&&w==320&&h==240){
        cv_blit565(&g_top,40,0,(const uint16_t*)g_cam.buf[0],w,h);
        vf_chrome(t,w,h); return;
    }

    /* Optional fast preview: process a half-size picture (4x less work) while looks/overlays are on.
       Never used while recording or in dual exposure, which need the full frame. */
    int sw=w,sh=h, half=S[S_FASTPV]&&heavy&&!A.avi&&!A.dual_have&&w>=320; if(half){ w/=2; h/=2; }
    size_t px=(size_t)w*h;
    if(half){ rgb565_to_rgb_half((const uint16_t*)g_cam.buf[0],sw,sh,pvL); if(stereo) rgb565_to_rgb_half((const uint16_t*)g_cam.buf[1],sw,sh,pvR); }
    else { rgb565_to_rgb((const uint16_t*)g_cam.buf[0],pvL,(int)px); if(stereo) rgb565_to_rgb((const uint16_t*)g_cam.buf[1],pvR,(int)px); }
    if(pvm==0) memcpy(disp,pvL,px*3); else if(pvm==4) memcpy(disp,pvR,px*3);
    else if(pvm==1) anaglyph(pvL,pvR,disp,w,h,S[S_ANA],S[S_CONV]*w/320);
    else if(pvm==2) memcpy(disp,((t/(1000/(S[S_WFPS]>0?S[S_WFPS]:8)))&1)?pvR:pvL,px*3);
    else { for(int y=0;y<h;y++) for(int x=0;x<w/2;x++){ memcpy(disp+((size_t)y*w+x)*3,pvL+((size_t)y*w+x*2)*3,3); memcpy(disp+((size_t)y*w+w/2+x)*3,pvR+((size_t)y*w+x*2)*3,3); } }
    int ox=0,oy=0; if(S[S_STAB]){ stab_update(&A.stab,disp,w,h,S[S_STAB],&ox,&oy); translate_clamp(disp,w,h,ox,oy);
        if(stereo&&A.rec){ translate_clamp(pvL,w,h,ox,oy); translate_clamp(pvR,w,h,ox,oy); } } else A.stab.have=0;
    if(S[S_PERSON]&&(A.frame%4)==0) A.persons_n=person_detect(disp,w,h,A.persons,4); else if(!S[S_PERSON]) A.persons_n=0;
    if(A.dual_have&&w==320&&h==240) for(size_t i=0;i<px*3;i++) disp[i]=(uint8_t)((disp[i]+A.dual_prev[i])>>1);
    if(S[S_DEPTHV]&&stereo){ depth_map(pvL,pvR,w,h,dmap); depth_to_rgb(dmap,disp,w,h); }
    else look_apply(disp,w,h,&lk);
    if(A.avi){ memcpy(clean,disp,px*3); rec_service(clean,w,h); }
    int need_h=S[S_HIST]||S[S_CLIP]; if(need_h) hist_calc(disp,w,h,&A.hist);
    if(S[S_WAVE]) waveform(disp,w,h,S[S_WAVE],wavebuf,64,48);
    if(S[S_FALSE]) ov_falsecolor(disp,w,h);
    if(S[S_PEAK]) ov_peaking(disp,w,h,S[S_PEAK]);
    if(S[S_ZEB]){ static const int th[4]={255,242,230,204}; ov_zebra(disp,w,h,th[S[S_ZEB]],A.phase*4); }
    if(S[S_CLIP]) ov_clip(disp,w,h,A.phase);
    cv_clear(&g_top,C_BG); cv_blit_fit(&g_top,40,0,320,240,disp,w,h);
    vf_chrome(t,w,h);
}

/* ================= actions ================= */
static void handle_action(int act){
    switch(act){
    case ACT_SAVE_LOFI: settings_set_ends(0); say("Saved as Lo-Fi end"); break;
    case ACT_SAVE_PRO:  settings_set_ends(1); say("Saved as Pro end"); break;
    case ACT_RESET:     settings_reset(); gfx_theme(S[S_THEME]); say("Factory defaults"); break;
    case ACT_PSAVE:     settings_profile(S[S_PROF],1); say("Profile %d saved",S[S_PROF]); break;
    case ACT_SENSOR:    if(A.rec) rec_stop(); regtool_run(); A.sig=-1; vf_sync_camera(1); break;
    case ACT_PLOAD:     say(settings_profile(S[S_PROF],0)?"Profile %d loaded":"Profile %d empty",S[S_PROF]); gfx_theme(S[S_THEME]); break;
    }
    A.dirty=1;
}
static void trigger_shutter(void){
    if(A.rec) return;
    if(S[S_INTV]>0){ A.tl_run=!A.tl_run; A.tl_n=0; A.tl_next=now_ms(); say(A.tl_run?"Timelapse on":"Timelapse off"); return; }
    if(S[S_TIMER]){ static const int secs[4]={0,2,5,10}; A.timer_end=now_ms()+secs[S[S_TIMER]]*1000ULL; return; }
    do_capture();
}
int main(void){
    settings_init(); gfx_setup(); gfx_theme(S[S_THEME]); ui_init();
    osSetSpeedupEnable(S[S_SPEED]!=0);
    mkdir("/DCIM",0777); mkdir(PHOTO_DIR,0777); scan_numbers();
    pvL=(uint8_t*)malloc(MAXPX*3); pvR=(uint8_t*)malloc(MAXPX*3); disp=(uint8_t*)malloc(MAXPX*3); clean=(uint8_t*)malloc(MAXPX*3);
    recbuf=(uint8_t*)malloc(MAXPX*3*2); tmp3=(uint8_t*)malloc(MAXPX*3); wavebuf=(uint8_t*)malloc(64*48*3); dmap=(uint8_t*)malloc(MAXPX);
    acc[0]=(uint16_t*)malloc(MAXPX*3*2); acc[1]=(uint16_t*)malloc(MAXPX*3*2);
    int mem_ok=pvL&&pvR&&disp&&clean&&recbuf&&tmp3&&wavebuf&&dmap&&acc[0]&&acc[1];
    int cam_ok=mem_ok&&cam_init();
    HIDUSER_EnableAccelerometer(); HIDUSER_EnableGyroscope();
    hidSetRepeatParameters(20,5);
    /* Diagnostics: on by default, or forced by holding L or R while the app starts. They run even when the
       camera failed to start, because that is exactly when you want them. */
    hidScanInput();
    if(mem_ok&&(S[S_DIAG]||(hidKeysHeld()&(KEY_L|KEY_R)))) diag_run(pvL,pvR,disp);
    if(!cam_ok){ cv_clear(&g_top,C_BG); cv_text(&g_top,16,100,mem_ok?"Camera service unavailable.":"Out of memory.",C_WARN); cv_text(&g_top,16,120,"Press START to exit.",C_FG);
        while(aptMainLoop()){ hidScanInput(); if(hidKeysDown()&KEY_START) break; gfx_present(); } gfx_shutdown(); return 0; }
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(), rep=hidKeysDownRepeat(); touchPosition tp; hidTouchRead(&tp);
        if(down&KEY_START) break;
        int act=0; int ui=ui_input(down,rep,&tp,&act);
        if(down&KEY_SELECT){ S[S_SRC]=(S[S_SRC]+1)%3; g_menu.changed=1; }
        if(down&(KEY_A|KEY_ZL|KEY_ZR)) ui=UI_SHUTTER; if(down&KEY_B) ui=UI_VIDEO; if(down&KEY_X) ui=UI_GALLERY; if(down&KEY_Y) ui=UI_SHARE;
        if(g_menu.changed){ g_menu.changed=0; A.dirty=1; A.save_due=now_ms()+2000; gfx_theme(S[S_THEME]); }
        if(A.save_due&&now_ms()>A.save_due){ settings_save(); A.save_due=0; }
        read_motion();
        switch(ui){
        case UI_ACTION: handle_action(act); break;
        case UI_SHUTTER: if(A.timer_end) A.timer_end=0; else if(A.tl_run) { A.tl_run=0; say("Timelapse stopped"); } else trigger_shutter(); break;
        case UI_VIDEO: if(A.rec) rec_stop(); else rec_start(); break;
        case UI_GALLERY: if(A.rec) rec_stop(); cam_stop(); mic_stop(); gallery_run(); vf_sync_camera(1); break;
        case UI_SHARE: if(A.rec) rec_stop(); cam_stop(); mic_stop(); share_run(); vf_sync_camera(1); break;
        }
        if(A.timer_end&&now_ms()>=A.timer_end){ A.timer_end=0; do_capture(); }
        if(A.tl_run&&now_ms()>=A.tl_next&&!A.rec){ do_capture(); A.tl_n++; A.tl_next=now_ms()+S[S_INTV]*1000ULL; }
        if(voice_check()){ A.voice_cool=now_ms()+2500; trigger_shutter(); }
        vf_sync_camera(0);
        vf_frame();
        ui_draw_bottom(A.rec);
        gfx_present();
    }
    if(A.rec) rec_stop();
    settings_save(); mic_stop(); cam_exit(); gfx_shutdown(); return 0;
}
