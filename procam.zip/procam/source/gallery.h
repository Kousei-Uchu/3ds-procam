#pragma once
void gallery_run(void);   // blocking; returns when B pressed
