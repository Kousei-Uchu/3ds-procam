#pragma once
#include <stdint.h>
#define MIC_RATE 16360
int  mic_start(void);
void mic_stop(void);
int  mic_active(void);
int  mic_read(int16_t* out, int max);     // new samples since last call
