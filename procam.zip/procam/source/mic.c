#include <3ds.h>
#include <malloc.h>
#include <string.h>
#include "mic.h"
static u8* g_mb; static u32 g_msize, g_dsize, g_rpos; static int g_on;
int mic_active(void){ return g_on; }
int mic_start(void){
    if(g_on) return 1;
    g_msize=0x30000; g_mb=(u8*)memalign(0x1000,g_msize); if(!g_mb) return 0;
    if(R_FAILED(micInit(g_mb,g_msize))){ free(g_mb); g_mb=0; return 0; }
    g_dsize=micGetSampleDataSize();
    if(R_FAILED(MICU_StartSampling(MICU_ENCODING_PCM16_SIGNED,MICU_SAMPLE_RATE_16360,0,g_dsize,true))){ micExit(); free(g_mb); g_mb=0; return 0; }
    g_rpos=0; g_on=1; return 1;
}
void mic_stop(void){ if(!g_on) return; MICU_StopSampling(); micExit(); free(g_mb); g_mb=0; g_on=0; }
int mic_read(int16_t* out,int max){
    if(!g_on) return 0;
    u32 last=micGetLastSampleOffset(); if(last>=g_dsize) last=0;
    u32 avail=(last>=g_rpos)?(last-g_rpos):(g_dsize-g_rpos+last);
    u32 n=avail/2; if((int)n>max) n=(u32)max; u32 bytes=n*2, done=0;
    while(done<bytes){ u32 chunk=g_dsize-g_rpos; if(chunk>bytes-done) chunk=bytes-done;
        memcpy((u8*)out+done,g_mb+g_rpos,chunk); g_rpos=(g_rpos+chunk)%g_dsize; done+=chunk; }
    return (int)n;
}
