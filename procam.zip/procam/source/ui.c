#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "ui.h"
#include "settings.h"

Menu g_menu;
static int items[P_COUNT][48], nitems[P_COUNT];
#define ROWS 11
#define ROW_Y0 20
#define ROW_H 16

void ui_init(void){
    memset(nitems,0,sizeof nitems);
    for(int i=0;i<S_COUNT;i++){ int p=g_defs[i].page; items[p][nitems[p]++]=i; }
}
static void act_fire(int id,int* act){ *act=g_defs[id].min; }
int ui_input(u32 down,u32 rep,const touchPosition* tp,int* act){
    Menu* m=&g_menu; *act=0;
    if(down&KEY_L){ m->page=(m->page+P_COUNT-1)%P_COUNT; m->sel=0; }
    if(down&KEY_R){ m->page=(m->page+1)%P_COUNT; m->sel=0; }
    int n=nitems[m->page];
    if(rep&KEY_DUP) m->sel=(m->sel+n-1)%n;
    if(rep&KEY_DDOWN) m->sel=(m->sel+1)%n;
    int id=items[m->page][m->sel];
    if(rep&(KEY_DLEFT|KEY_DRIGHT)){
        if(g_defs[id].type==T_ACT){ if(down&(KEY_DLEFT|KEY_DRIGHT)){ act_fire(id,act); return UI_ACTION; } }
        else { setting_adjust(id,(rep&KEY_DRIGHT)?1:-1); m->changed=1; }
    }
    if(down&KEY_TOUCH){
        int x=tp->px, y=tp->py;
        if(y<18){ int p=x*P_COUNT/320; if(p>=0&&p<P_COUNT){ m->page=p; m->sel=0; } }
        else if(y>=204){ int b=x/80; return b==0?UI_SHUTTER:(b==1?UI_VIDEO:(b==2?UI_GALLERY:UI_SHARE)); }
        else if(y>=ROW_Y0&&y<ROW_Y0+ROWS*ROW_H){
            int scroll=m->sel>=ROWS?m->sel-ROWS+1:0; int r=(y-ROW_Y0)/ROW_H+scroll;
            if(r<n){ m->sel=r; id=items[m->page][r];
                if(g_defs[id].type==T_ACT){ act_fire(id,act); return UI_ACTION; }
                if(x>=276){ setting_adjust(id,1); m->changed=1; } else if(x>=232){ setting_adjust(id,-1); m->changed=1; }
                else if(x>=120){ setting_adjust(id,1); m->changed=1; } } }
    }
    return UI_NONE;
}
void ui_draw_bottom(int rec){
    Canvas* c=&g_bot; Menu* m=&g_menu; cv_clear(c,C_BG);
    for(int p=0;p<P_COUNT;p++){ int x=p*320/P_COUNT, w=320/P_COUNT; int on=(p==m->page);
        cv_rect(c,x,0,w-1,16,on?C_ACC:C_DIM); cv_text(c,x+(w-(int)strlen(g_page_names[p])*8)/2,4,g_page_names[p],on?C_BG:C_FG); }
    int n=nitems[m->page], scroll=m->sel>=ROWS?m->sel-ROWS+1:0; char buf[40];
    for(int r=0;r<ROWS&&r+scroll<n;r++){ int id=items[m->page][r+scroll]; int y=ROW_Y0+r*ROW_H; int on=(r+scroll==m->sel);
        if(on) cv_rect(c,0,y-2,320,ROW_H,C_DIM);
        uint16_t fg=on?C_FG:rgb16(170,170,170);
        cv_text(c,4,y+1,g_defs[id].name,fg);
        if(g_defs[id].type!=T_ACT){ cv_text(c,124,y+1,setting_text(id,buf,sizeof buf),C_ACC);
            cv_text(c,240,y+1,"<",C_ACC); cv_text(c,284,y+1,">",C_ACC); } }
    if(n>ROWS){ int bh=ROWS*ROW_H*ROWS/n; int by=ROW_Y0+(ROWS*ROW_H-bh)*scroll/(n-ROWS>0?n-ROWS:1); cv_rect(c,317,by,2,bh,C_ACC); }
    static const char* lab[4]={"PHOTO","VIDEO","GALLERY","SHARE"};
    for(int b=0;b<4;b++){ uint16_t bg=(b==1&&rec)?C_WARN:C_DIM; cv_rect(c,b*80+2,206,76,30,bg); cv_box(c,b*80+2,206,76,30,C_ACC);
        const char* t=(b==1&&rec)?"STOP":lab[b]; cv_text(c,b*80+2+(76-(int)strlen(t)*8)/2,217,t,C_FG); }
}
static void dotline(Canvas* c,int x0,int y0,int x1,int y1,uint16_t col){
    int dx=abs(x1-x0), dy=abs(y1-y0), n=dx>dy?dx:dy; if(!n) return;
    for(int i=0;i<=n;i+=2) cv_pset(c,x0+(x1-x0)*i/n,y0+(y1-y0)*i/n,col);
}
void ui_draw_grid(Canvas* c,int x,int y,int w,int h,int t){
    uint16_t col=rgb16(255,255,255);
    switch(t){
    case 1: for(int i=1;i<3;i++){ dotline(c,x+w*i/3,y,x+w*i/3,y+h-1,col); dotline(c,x,y+h*i/3,x+w-1,y+h*i/3,col); } break;
    case 2: { int a=w*382/1000,b=w*618/1000,e=h*382/1000,f=h*618/1000; dotline(c,x+a,y,x+a,y+h-1,col); dotline(c,x+b,y,x+b,y+h-1,col); dotline(c,x,y+e,x+w-1,y+e,col); dotline(c,x,y+f,x+w-1,y+f,col); } break;
    case 3: dotline(c,x,y,x+w-1,y+h-1,col); dotline(c,x+w-1,y,x,y+h-1,col); dotline(c,x+w/2,y,x+w/2,y+h-1,col); dotline(c,x,y+h/2,x+w-1,y+h/2,col); break;
    case 4: dotline(c,x+w/2,y,x+w/2,y+h-1,col); dotline(c,x,y+h/2,x+w-1,y+h/2,col); break;
    case 5: for(int i=1;i<4;i++){ dotline(c,x+w*i/4,y,x+w*i/4,y+h-1,col); dotline(c,x,y+h*i/4,x+w-1,y+h*i/4,col); } break;
    case 6: cv_rect(c,x+w/2-1,y+h/2-1,3,3,col); break;
    }
}
void ui_draw_guide(Canvas* c,int x,int y,int w,int h,int mode){
    if(!mode) return; int cx,cy,cw,ch; crop_rect(w,h,mode,&cx,&cy,&cw,&ch); uint16_t col=rgb16(255,220,0);
    dotline(c,x+cx,y+cy,x+cx+cw-1,y+cy,col); dotline(c,x+cx,y+cy+ch-1,x+cx+cw-1,y+cy+ch-1,col);
    dotline(c,x+cx,y+cy,x+cx,y+cy+ch-1,col); dotline(c,x+cx+cw-1,y+cy,x+cx+cw-1,y+cy+ch-1,col);
}
void ui_draw_hist(Canvas* c,int x,int y,int w,int h,const Hist* hi,int mode){
    cv_rect(c,x,y,w,h,rgb16(0,0,0)); cv_box(c,x,y,w,h,rgb16(90,90,90));
    uint32_t mx=1; for(int i=1;i<63;i++){ uint32_t v=mode==2?(hi->r[i]>hi->g[i]?(hi->r[i]>hi->b[i]?hi->r[i]:hi->b[i]):(hi->g[i]>hi->b[i]?hi->g[i]:hi->b[i])):hi->l[i]; if(v>mx) mx=v; }
    for(int i=0;i<w-2;i++){ int b=i*64/(w-2);
        if(mode==1){ uint32_t v=hi->l[b]; int bh=(int)((uint64_t)v*(h-3)/mx); if(bh>h-3) bh=h-3; cv_rect(c,x+1+i,y+h-1-bh,1,bh,rgb16(220,220,220)); }
        else { uint32_t v[3]={hi->r[b],hi->g[b],hi->b[b]}; static const uint16_t col[3]={0xF800,0x07E0,0x001F};
            for(int k=0;k<3;k++){ int bh=(int)((uint64_t)v[k]*(h-3)/mx); if(bh>h-3) bh=h-3; cv_pset(c,x+1+i,y+h-1-bh,col[k]); } } }
}
void ui_draw_level(Canvas* c,int cx,int cy,float deg){
    float r=deg*3.14159265f/180.f, L=56; int dx=(int)(cosf(r)*L), dy=(int)(sinf(r)*L);
    uint16_t col=fabsf(deg)<1.5f?rgb16(80,255,80):rgb16(255,200,40);
    cv_line(c,cx-dx,cy-dy,cx-dx*14/56,cy-dy*14/56,col); cv_line(c,cx+dx*14/56,cy+dy*14/56,cx+dx,cy+dy,col);
    cv_line(c,cx-12,cy,cx+12,cy,rgb16(255,255,255)); cv_rect(c,cx-1,cy-1,3,3,col);
}
