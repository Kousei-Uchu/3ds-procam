#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "ui.h"
#include "settings.h"
#include "gui.h"

Menu g_menu;
static int items[P_COUNT][48], nitems[P_COUNT];
/* ---------- touch GUI menu (bottom screen) ---------- */
#define ROWS 7
#define ROW_Y0 30
#define ROW_PITCH 22
#define ROW_H 20
#define TAB_H 22
#define BAR_Y 190
#define VAL_X 158          /* value zone starts here, minus button just left of it, plus button at the right end */

/* what is currently under the finger, so it can be drawn pressed */
static int g_press_kind=-1, g_press_idx=-1;   /* kinds: 0 tab, 1 row, 2 minus, 3 plus, 4 bar button, 5 scroll */

void ui_init(void){
    memset(nitems,0,sizeof nitems);
    for(int i=0;i<S_COUNT;i++){ int p=g_defs[i].page; items[p][nitems[p]++]=i; }
}
static void act_fire(int id,int* act){ *act=g_defs[id].min; }
static int scroll_of(const Menu* m){ return m->sel>=ROWS?m->sel-ROWS+1:0; }

/* Decode a touch into (kind, index). Returns 0 if it hit nothing. */
static int hit(int x,int y,int* kind,int* idx){
    const Menu* m=&g_menu; int n=nitems[m->page];
    if(y<ROW_Y0-4){ int p=x*P_COUNT/320; if(p>=0&&p<P_COUNT){ *kind=0; *idx=p; return 1; } return 0; }
    if(y>=BAR_Y){ int b=x/80; *kind=4; *idx=b>3?3:b; return 1; }
    if(x>=292&&y>=ROW_Y0&&y<ROW_Y0+34){ *kind=5; *idx=0; return 1; }
    if(x>=292&&y>=ROW_Y0+38&&y<ROW_Y0+72){ *kind=5; *idx=1; return 1; }
    if(y>=ROW_Y0&&y<ROW_Y0+ROWS*ROW_PITCH&&x<290){
        int r=(y-ROW_Y0)/ROW_PITCH+scroll_of(m); if(r>=n) return 0; int id=items[m->page][r];
        *idx=r; *kind=1;
        if(g_defs[id].type!=T_ACT&&g_defs[id].type!=T_BOOL){ if(x>=132&&x<VAL_X) *kind=2; else if(x>=VAL_X+98) *kind=3; }
        return 1;
    }
    return 0;
}
int ui_input(u32 down,u32 rep,const touchPosition* tp,int* act){
    Menu* m=&g_menu; *act=0;
    if(down&KEY_L){ m->page=(m->page+P_COUNT-1)%P_COUNT; m->sel=0; }
    if(down&KEY_R){ m->page=(m->page+1)%P_COUNT; m->sel=0; }
    int n=nitems[m->page];
    if(rep&KEY_DUP) m->sel=(m->sel+n-1)%n;
    if(rep&KEY_DDOWN) m->sel=(m->sel+1)%n;
    int id=items[m->page][m->sel];
    if(rep&(KEY_DLEFT|KEY_DRIGHT)){
        if(g_defs[id].type==T_ACT){ if(down&(KEY_DLEFT|KEY_DRIGHT)){ act_fire(id,act); return UI_ACTION; } }
        else { setting_adjust(id,(rep&KEY_DRIGHT)?1:-1); m->changed=1; }
    }
    if(down&KEY_TOUCH){
        int kind,idx; if(hit(tp->px,tp->py,&kind,&idx)){ g_press_kind=kind; g_press_idx=idx;
            switch(kind){
            case 0: m->page=idx; m->sel=0; break;
            case 4: return idx==0?UI_SHUTTER:(idx==1?UI_VIDEO:(idx==2?UI_GALLERY:UI_SHARE));
            case 5: m->sel=idx==0?(m->sel+n-1)%n:(m->sel+1)%n; break;
            default: { m->sel=idx; id=items[m->page][idx];
                if(g_defs[id].type==T_ACT){ act_fire(id,act); return UI_ACTION; }
                if(kind==2){ setting_adjust(id,-1); m->changed=1; } else { setting_adjust(id,1); m->changed=1; } } }
        }
    }
    return UI_NONE;
}
/* selected rows get an accent outline */
static void row_card(Canvas* c,int x,int y,int w,int h,int sel,int pressed,uint16_t fill){
    cv_rrect(c,x,y,w,h,5,sel?C_ACC:col_edge()); cv_rrect(c,x+1,y+1,w-2,h-2,4,pressed?col_edge():fill);
}
void ui_draw_bottom(int rec){
    Canvas* c=&g_bot; Menu* m=&g_menu; cv_clear(c,C_BG);
    int held=(hidKeysHeld()&KEY_TOUCH)!=0; if(!held){ g_press_kind=-1; g_press_idx=-1; }
    /* page tabs */
    int tw=320/P_COUNT;
    for(int p=0;p<P_COUNT;p++){ int on=(p==m->page), x=p*tw+1, w=tw-2;
        cv_rrect(c,x,2,w,TAB_H,6,on?C_ACC:col_edge()); cv_rrect(c,x+1,3,w-2,TAB_H-2,5,on?C_ACC:col_card());
        const char* nm=g_page_names[p]; cv_text(c,x+(w-(int)strlen(nm)*8)/2,2+(TAB_H-8)/2,nm,on?C_BG:col_dim()); }
    /* settings rows */
    int n=nitems[m->page], scroll=scroll_of(m); char buf[40];
    for(int r=0;r<ROWS&&r+scroll<n;r++){ int idx=r+scroll, id=items[m->page][idx]; int y=ROW_Y0+r*ROW_PITCH; int sel=(idx==m->sel);
        int pr=held&&g_press_kind>=1&&g_press_kind<=3&&g_press_idx==idx;
        const SDef* d=&g_defs[id]; const char* nm=d->name; if(!strncmp(nm,">> ",3)) nm+=3;
        if(d->type==T_ACT){ row_card(c,4,y,284,ROW_H,sel,pr,rgb16(22,52,78)); cv_text(c,10,y+6,nm,col_txt()); cv_text(c,274,y+6,">",C_ACC); continue; }
        row_card(c,4,y,284,ROW_H,sel,0,col_card()); cv_text(c,10,y+6,nm,sel?col_txt():col_dim());
        if(d->type==T_BOOL){ gui_switch(c,230,y+2,S[id]!=0); continue; }
        /* minus / value / plus */
        int mp=held&&g_press_kind==2&&g_press_idx==idx, pp=held&&g_press_kind==3&&g_press_idx==idx;
        cv_rrect(c,132,y+2,24,ROW_H-4,4,mp?C_ACC:col_edge()); cv_rect(c,138,y+ROW_H/2-1,12,2,col_txt());
        cv_rrect(c,VAL_X,y+2,96,ROW_H-4,4,col_edge()); cv_rrect(c,VAL_X+1,y+3,94,ROW_H-6,3,rgb16(12,14,19));
        if(d->type==T_INT&&d->max>d->min){ int fw=(94*(S[id]-d->min))/(d->max-d->min); if(fw>0) cv_rrect(c,VAL_X+1,y+3,fw,ROW_H-6,3,rgb16(20,70,100)); }
        const char* vt=setting_text(id,buf,sizeof buf); cv_text(c,VAL_X+(96-(int)strlen(vt)*8)/2,y+6,vt,C_ACC);
        cv_rrect(c,VAL_X+98,y+2,24,ROW_H-4,4,pp?C_ACC:col_edge()); cv_rect(c,VAL_X+98+6,y+ROW_H/2-1,12,2,col_txt()); cv_rect(c,VAL_X+98+11,y+ROW_H/2-6,2,12,col_txt()); }
    if(n>ROWS){ gui_button(292,ROW_Y0,26,34,BK_NEUTRAL,IC_UP,"",held&&g_press_kind==5&&g_press_idx==0);
                gui_button(292,ROW_Y0+38,26,34,BK_NEUTRAL,IC_DOWN,"",held&&g_press_kind==5&&g_press_idx==1);
                char pg[12]; snprintf(pg,sizeof pg,"%d/%d",m->sel+1,n); cv_text(c,292+(26-(int)strlen(pg)*8)/2,ROW_Y0+78,pg,col_dim()); }
    /* action bar */
    static const char* lab[4]={"PHOTO","VIDEO","GALLERY","SHARE"};
    for(int b=0;b<4;b++){ int pr=held&&g_press_kind==4&&g_press_idx==b; int on=(b==1&&rec);
        int kind=b==0?BK_ACCENT:(b==1?BK_RED:BK_NEUTRAL); int ic=b==0?IC_SHUTTER:(b==1?(on?IC_STOP:IC_REC):(b==2?IC_GALLERY:IC_SHARE));
        gui_button(4+b*80,BAR_Y,76,46,kind,ic,on?"STOP":lab[b],pr); }
}
static void dotline(Canvas* c,int x0,int y0,int x1,int y1,uint16_t col){
    int dx=abs(x1-x0), dy=abs(y1-y0), n=dx>dy?dx:dy; if(!n) return;
    for(int i=0;i<=n;i+=2) cv_pset(c,x0+(x1-x0)*i/n,y0+(y1-y0)*i/n,col);
}
void ui_draw_grid(Canvas* c,int x,int y,int w,int h,int t){
    uint16_t col=rgb16(255,255,255);
    switch(t){
    case 1: for(int i=1;i<3;i++){ dotline(c,x+w*i/3,y,x+w*i/3,y+h-1,col); dotline(c,x,y+h*i/3,x+w-1,y+h*i/3,col); } break;
    case 2: { int a=w*382/1000,b=w*618/1000,e=h*382/1000,f=h*618/1000; dotline(c,x+a,y,x+a,y+h-1,col); dotline(c,x+b,y,x+b,y+h-1,col); dotline(c,x,y+e,x+w-1,y+e,col); dotline(c,x,y+f,x+w-1,y+f,col); } break;
    case 3: dotline(c,x,y,x+w-1,y+h-1,col); dotline(c,x+w-1,y,x,y+h-1,col); dotline(c,x+w/2,y,x+w/2,y+h-1,col); dotline(c,x,y+h/2,x+w-1,y+h/2,col); break;
    case 4: dotline(c,x+w/2,y,x+w/2,y+h-1,col); dotline(c,x,y+h/2,x+w-1,y+h/2,col); break;
    case 5: for(int i=1;i<4;i++){ dotline(c,x+w*i/4,y,x+w*i/4,y+h-1,col); dotline(c,x,y+h*i/4,x+w-1,y+h*i/4,col); } break;
    case 6: cv_rect(c,x+w/2-1,y+h/2-1,3,3,col); break;
    }
}
void ui_draw_guide(Canvas* c,int x,int y,int w,int h,int mode){
    if(!mode) return; int cx,cy,cw,ch; crop_rect(w,h,mode,&cx,&cy,&cw,&ch); uint16_t col=rgb16(255,220,0);
    dotline(c,x+cx,y+cy,x+cx+cw-1,y+cy,col); dotline(c,x+cx,y+cy+ch-1,x+cx+cw-1,y+cy+ch-1,col);
    dotline(c,x+cx,y+cy,x+cx,y+cy+ch-1,col); dotline(c,x+cx+cw-1,y+cy,x+cx+cw-1,y+cy+ch-1,col);
}
void ui_draw_hist(Canvas* c,int x,int y,int w,int h,const Hist* hi,int mode){
    cv_rect(c,x,y,w,h,rgb16(0,0,0)); cv_box(c,x,y,w,h,rgb16(90,90,90));
    uint32_t mx=1; for(int i=1;i<63;i++){ uint32_t v=mode==2?(hi->r[i]>hi->g[i]?(hi->r[i]>hi->b[i]?hi->r[i]:hi->b[i]):(hi->g[i]>hi->b[i]?hi->g[i]:hi->b[i])):hi->l[i]; if(v>mx) mx=v; }
    for(int i=0;i<w-2;i++){ int b=i*64/(w-2);
        if(mode==1){ uint32_t v=hi->l[b]; int bh=(int)((uint64_t)v*(h-3)/mx); if(bh>h-3) bh=h-3; cv_rect(c,x+1+i,y+h-1-bh,1,bh,rgb16(220,220,220)); }
        else { uint32_t v[3]={hi->r[b],hi->g[b],hi->b[b]}; static const uint16_t col[3]={0xF800,0x07E0,0x001F};
            for(int k=0;k<3;k++){ int bh=(int)((uint64_t)v[k]*(h-3)/mx); if(bh>h-3) bh=h-3; cv_pset(c,x+1+i,y+h-1-bh,col[k]); } } }
}
void ui_draw_level(Canvas* c,int cx,int cy,float deg){
    float r=deg*3.14159265f/180.f, L=56; int dx=(int)(cosf(r)*L), dy=(int)(sinf(r)*L);
    uint16_t col=fabsf(deg)<1.5f?rgb16(80,255,80):rgb16(255,200,40);
    cv_line(c,cx-dx,cy-dy,cx-dx*14/56,cy-dy*14/56,col); cv_line(c,cx+dx*14/56,cy+dy*14/56,cx+dx,cy+dy,col);
    cv_line(c,cx-12,cy,cx+12,cy,rgb16(255,255,255)); cv_rect(c,cx-1,cy-1,3,3,col);
}
