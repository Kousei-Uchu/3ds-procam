#pragma once
#include <stdint.h>
typedef struct { int w, h; uint16_t* p; } Canvas;
extern Canvas g_top, g_bot;                 // 400x240 and 320x240 RGB565 back buffers
void gfx_setup(void);
void gfx_shutdown(void);
void gfx_present(void);                     // blit both canvases and flip
static inline uint16_t rgb16(int r,int g,int b){ return (uint16_t)(((r&0xF8)<<8)|((g&0xFC)<<3)|((b&0xFF)>>3)); }
void cv_clear(Canvas*,uint16_t);
void cv_pset(Canvas*,int x,int y,uint16_t c);
void cv_rect(Canvas*,int x,int y,int w,int h,uint16_t c);
void cv_box(Canvas*,int x,int y,int w,int h,uint16_t c);
void cv_line(Canvas*,int x0,int y0,int x1,int y1,uint16_t c);
void cv_text(Canvas*,int x,int y,const char* s,uint16_t fg);
void cv_text_bg(Canvas*,int x,int y,const char* s,uint16_t fg,uint16_t bg);
int  cv_text_w(const char* s);
void cv_blit_rgb(Canvas*,int x,int y,const uint8_t* rgb,int w,int h);
void cv_blit_fit(Canvas*,int x,int y,int bw,int bh,const uint8_t* rgb,int w,int h);
int  cv_qr(Canvas*,int x,int y,int scale,const char* text);   // returns pixel size or 0
// UI theme colours (set from settings)
extern uint16_t C_ACC, C_DIM, C_BG, C_FG, C_WARN;
void gfx_theme(int idx);
