#pragma once
void regtool_run(void);   // blocking sensor-register explorer with live preview; B exits
