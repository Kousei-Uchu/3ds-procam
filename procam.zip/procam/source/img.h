#pragma once
// Pure-C image engine (no libctru): colour conversion, looks, analysis overlays,
// stacking/HDR/dual-exposure, stereo tools (anaglyph, align, depth), stabilisation.
#include <stdint.h>
#include <stddef.h>

typedef struct { int style, amt, bright, con, sat, temp, tint, vign, grain, scan, crush, dither, soft, pix, funky, famt; uint32_t seed; } Look;
typedef struct { int x, y, w, h; } Box;
typedef struct { uint32_t l[64], r[64], g[64], b[64], hi, lo, n; } Hist;
typedef struct { uint8_t prev[80*60]; int have; float px, py, cx, cy; } Stab;

void yuv_to_rgb(const uint8_t* yuv, uint8_t* rgb, int w, int h, int uyvy, int limited);
void rgb565_to_rgb(const uint16_t* in, uint8_t* rgb, int n);
void rgb565_to_rgb_half(const uint16_t* in, int sw, int sh, uint8_t* rgb);
void look_apply(uint8_t* rgb, int w, int h, const Look* lk);
int  look_is_neutral(const Look* lk);

void hist_calc(const uint8_t* rgb, int w, int h, Hist* out);
void ov_zebra(uint8_t* rgb, int w, int h, int thr, int phase);
void ov_peaking(uint8_t* rgb, int w, int h, int color);
void ov_falsecolor(uint8_t* rgb, int w, int h);
void ov_clip(uint8_t* rgb, int w, int h, int phase);
void waveform(const uint8_t* rgb, int w, int h, int mode, uint8_t* out, int ww, int wh);

void blend_dual(const uint8_t* a, const uint8_t* b, uint8_t* out, int nbytes, int mode);
void hdr_fuse(const uint8_t* const* imgs, int k, uint8_t* out, int w, int h);
float sharpness(const uint8_t* rgb, int w, int h);
void crop_rect(int w, int h, int mode, int* x, int* y, int* cw, int* ch);
uint8_t* crop_copy(const uint8_t* rgb, int w, int h, int x, int y, int cw, int ch);

void anaglyph(const uint8_t* L, const uint8_t* R, uint8_t* out, int w, int h, int mode, int shift);
void align_pair(const uint8_t* L, const uint8_t* R, int w, int h, int* dx, int* dy);
void depth_map(const uint8_t* L, const uint8_t* R, int w, int h, uint8_t* d);
void depth_fx(uint8_t* rgb, const uint8_t* d, int w, int h, int bokeh, int pop);
void depth_to_rgb(const uint8_t* d, uint8_t* rgb, int w, int h);

int  person_detect(const uint8_t* rgb, int w, int h, Box* out, int max);
void stab_update(Stab* s, const uint8_t* rgb, int w, int h, int strength, int* ox, int* oy);
void translate_clamp(uint8_t* rgb, int w, int h, int dx, int dy);
void img_free_caches(void);
