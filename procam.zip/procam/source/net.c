#include <3ds.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <fcntl.h>
#include <malloc.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include <errno.h>
#include "net.h"
#include "gfx.h"
#include "settings.h"

#define PHOTO_DIR "/DCIM/100NIN03"
static const int k_ports[4]={8080,8000,8888,3000};

static const char* mime(const char* n){
    const char* e=strrchr(n,'.'); if(!e) return "application/octet-stream";
    if(!strcasecmp(e,".jpg")||!strcasecmp(e,".mpo")) return "image/jpeg"; if(!strcasecmp(e,".png")) return "image/png";
    if(!strcasecmp(e,".gif")) return "image/gif"; if(!strcasecmp(e,".bmp")) return "image/bmp"; if(!strcasecmp(e,".avi")) return "video/x-msvideo";
    if(!strcasecmp(e,".txt")) return "text/plain"; return "application/octet-stream";
}
static int is_img(const char* n){ const char* e=strrchr(n,'.'); return e&&(!strcasecmp(e,".jpg")||!strcasecmp(e,".mpo")||!strcasecmp(e,".png")||!strcasecmp(e,".gif")||!strcasecmp(e,".bmp")); }
static int send_all(int s,const void* d,size_t n){
    const char* p=(const char*)d; while(n){ ssize_t k=send(s,p,n,0); if(k<0){ if(errno==EAGAIN||errno==EWOULDBLOCK){ svcSleepThread(2000000); continue; } return 0; } if(k==0) return 0; p+=k; n-=(size_t)k; } return 1;
}
static int cmp_name(const void* a,const void* b){ return strcmp((const char*)b,(const char*)a); }   /* newest first */
static void send_index(int c){
    static char names[400][40]; int n=0; DIR* d=opendir(PHOTO_DIR);
    if(d){ struct dirent* e; while((e=readdir(d))&&n<400){ if(e->d_name[0]=='.') continue; strncpy(names[n],e->d_name,39); names[n][39]=0; n++; } closedir(d); }
    qsort(names,n,40,cmp_name);
    char buf[512];
    const char* hd="HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n";
    send_all(c,hd,strlen(hd));
    const char* top="<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>PROCAM</title>"
        "<style>body{background:#111;color:#eee;font:14px sans-serif;margin:8px}a{color:#4cf}.g{display:flex;flex-wrap:wrap;gap:8px}"
        ".c{width:46%;background:#222;padding:4px;border-radius:4px;word-break:break-all}img{width:100%;display:block}</style><h2>PROCAM photos</h2><div class=g>";
    send_all(c,top,strlen(top));
    for(int i=0;i<n;i++){
        if(is_img(names[i])) snprintf(buf,sizeof buf,"<div class=c><a href='/f/%s' download><img loading=lazy src='/f/%s'>%s</a></div>",names[i],names[i],names[i]);
        else snprintf(buf,sizeof buf,"<div class=c><a href='/f/%s' download>%s</a></div>",names[i],names[i]);
        if(!send_all(c,buf,strlen(buf))) return;
    }
    send_all(c,"</div>",6);
}
static void send_file(int c,const char* name){
    if(strchr(name,'/')||strstr(name,"..")||name[0]=='.'){ send_all(c,"HTTP/1.0 400 Bad Request\r\n\r\n",28); return; }
    char path[96]; snprintf(path,sizeof path,PHOTO_DIR"/%s",name); FILE* f=fopen(path,"rb");
    if(!f){ send_all(c,"HTTP/1.0 404 Not Found\r\n\r\nnope",30); return; }
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET);
    char h[256]; snprintf(h,sizeof h,"HTTP/1.0 200 OK\r\nContent-Type: %s\r\nContent-Length: %ld\r\nConnection: close\r\n\r\n",mime(name),sz);
    if(send_all(c,h,strlen(h))){ static char chunk[16384]; size_t k; while((k=fread(chunk,1,sizeof chunk,f))>0) if(!send_all(c,chunk,k)) break; }
    fclose(f);
}
static void draw_info(const char* url,const char* status,int served){
    cv_clear(&g_top,C_BG); cv_clear(&g_bot,C_BG);
    cv_text(&g_top,16,12,"SHARE TO PHONE (Wi-Fi)",C_ACC);
    cv_text(&g_top,16,40,"1. Join the same Wi-Fi as this 3DS",C_FG);
    cv_text(&g_top,16,56,"2. Scan the QR code (bottom screen)",C_FG);
    cv_text(&g_top,16,72,"   or type the address below",C_FG);
    cv_text(&g_top,16,100,url,C_ACC);
    cv_text(&g_top,16,130,status,C_FG);
    char b[48]; snprintf(b,sizeof b,"Files sent: %d",served); cv_text(&g_top,16,150,b,C_FG);
    cv_text(&g_top,16,220,"B = stop sharing",C_DIM);
    int sz=cv_qr(&g_bot,0,0,1,url); if(sz){ int scale=200/sz; if(scale<1) scale=1; cv_rect(&g_bot,0,0,320,240,C_BG); int px=cv_qr(&g_bot,(320-sz*scale)/2,(240-sz*scale)/2,scale,url); (void)px; }
}
void share_run(void){
    u32* buf=(u32*)memalign(0x1000,0x100000); char url[64]="no Wi-Fi?"; int served=0;
    if(!buf || R_FAILED(socInit(buf,0x100000))){ free(buf); draw_info("socInit failed","Wi-Fi unavailable",0); gfx_present(); for(int i=0;i<120;i++) gspWaitForVBlank(); return; }
    int port=k_ports[S[S_PORT]], ls=socket(AF_INET,SOCK_STREAM,0);
    struct sockaddr_in a; memset(&a,0,sizeof a); a.sin_family=AF_INET; a.sin_port=htons((uint16_t)port); a.sin_addr.s_addr=htonl(INADDR_ANY);
    int ok = ls>=0 && bind(ls,(struct sockaddr*)&a,sizeof a)==0 && listen(ls,4)==0;
    if(ok) fcntl(ls,F_SETFL,fcntl(ls,F_GETFL,0)|O_NONBLOCK);
    struct in_addr ip; ip.s_addr=(in_addr_t)gethostid();
    if(ip.s_addr) snprintf(url,sizeof url,"http://%s:%d/",inet_ntoa(ip),port);
    const char* status=ok?"Server running...":"Could not start server";
    while(aptMainLoop()){
        hidScanInput(); if(hidKeysDown()&KEY_B) break;
        if(ok){ struct sockaddr_in ca; socklen_t cl=sizeof ca; int c=accept(ls,(struct sockaddr*)&ca,&cl);
            if(c>=0){ fcntl(c,F_SETFL,fcntl(c,F_GETFL,0)&~O_NONBLOCK);
                char req[512]; ssize_t n=recv(c,req,sizeof req-1,0);
                if(n>0){ req[n]=0; if(!strncmp(req,"GET /f/",7)){ char* e=strchr(req+7,' '); if(e){ *e=0; send_file(c,req+7); served++; } }
                    else if(!strncmp(req,"GET / ",6)||!strncmp(req,"GET /index",10)) send_index(c);
                    else send_all(c,"HTTP/1.0 404 Not Found\r\n\r\n",26); }
                closesocket(c); } }
        draw_info(url,status,served); gfx_present();
    }
    if(ls>=0) closesocket(ls);
    socExit(); free(buf);
}
