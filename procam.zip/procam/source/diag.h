#pragma once
/* Diagnostic mode: runs one isolated test at a time, lets the user mark each OK or ISSUE,
   writes /3ds/procam/diag_report.txt, then returns so the normal app can start. */
void diag_run(void);
