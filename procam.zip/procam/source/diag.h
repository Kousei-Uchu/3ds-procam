#pragma once
#include <stdint.h>
/* Diagnostic mode: runs one isolated test at a time, lets the user mark each OK or ISSUE,
   writes /3ds/procam/diag_report.txt, then returns so the normal app can start. */
/* The three buffers must each hold 640*480*3 bytes; they are borrowed from the app, nothing is allocated. */
void diag_run(uint8_t* bufA,uint8_t* bufB,uint8_t* bufC);

#define DIAG_DIR "/3ds/procam/diag"      /* one timestamped report per diagnostic run */
