#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cam.h"
#include "settings.h"

Cam g_cam;
const int g_size_w[3]={640,320,160}, g_size_h[3]={480,240,120};
static const CAMU_Size k_sizes[3]={SIZE_VGA,SIZE_QVGA,SIZE_QQVGA};
static const CAMU_FrameRate k_fps[5]={FRAME_RATE_30_TO_5,FRAME_RATE_20,FRAME_RATE_15,FRAME_RATE_10,FRAME_RATE_5};
static const CAMU_FrameRate k_shut[5]={FRAME_RATE_5,FRAME_RATE_10,FRAME_RATE_15,FRAME_RATE_20,FRAME_RATE_30};

static u32 sel_of(void){ return g_cam.src==1?SELECT_OUT1_OUT2:(g_cam.src==2?SELECT_IN1:SELECT_OUT1); }
static u32 port_of(void){ return g_cam.stereo?PORT_BOTH:PORT_CAM1; }

/* optional user script /3ds/procam/regs.txt: lines "W aaaa dddd" (I2C reg) or "M aaaa dddd" (MCU var), hex; "#" comments */
static void run_regs(u32 s){
    FILE* f=fopen("/3ds/procam/regs.txt","r"); if(!f) return; char line[80];
    while(fgets(line,sizeof line,f)){ char t; unsigned a,v; if(line[0]=='#') continue;
        if(sscanf(line," %c %x %x",&t,&a,&v)==3){ if(t=='W'||t=='w') CAMU_WriteRegisterI2c(s,(u16)a,(u16)v); else if(t=='M'||t=='m') CAMU_WriteMcuVariableI2c(s,(u16)a,(u16)v); } }
    fclose(f);
}
int cam_init(void){
    if(R_FAILED(camInit())) return 0;
    for(int i=0;i<2;i++){ g_cam.buf[i]=(uint8_t*)malloc(640*480*2); if(!g_cam.buf[i]) return 0; }
    return 1;
}
void cam_exit(void){ cam_stop(); camExit(); free(g_cam.buf[0]); free(g_cam.buf[1]); }
void cam_stop(void){
    if(!g_cam.active) return;
    CAMU_StopCapture(PORT_BOTH); CAMU_Activate(SELECT_NONE); g_cam.active=0;
}
void cam_apply_params(void){
    if(!g_cam.active) return; u32 s=sel_of();
    int m=S[S_EXPM];
    CAMU_SetAutoExposure(s, m!=2);
    CAMU_SetExposure(s, (s8)((m==1||m==3)?S[S_EV]:0));
    CAMU_SetWhiteBalance(s,(CAMU_WhiteBalance)S[S_WB]);
    CAMU_SetAutoWhiteBalance(s,S[S_WB]==0);
    CAMU_SetPhotoMode(s,(CAMU_PhotoMode)S[S_PHOTO]);
    CAMU_SetSharpness(s,(s8)S[S_SHARP]);
    CAMU_SetContrast(s,(CAMU_Contrast)(S[S_CONTR]-1));
    CAMU_SetNoiseFilter(s,S[S_NOISE]!=0);
    CAMU_SetLensCorrection(s,(CAMU_LensCorrection)S[S_LENS]);
    CAMU_SetEffect(s,(CAMU_Effect)S[S_SFX],CONTEXT_A);
    CAMU_FlipImage(s,(CAMU_Flip)S[S_FLIP],CONTEXT_A);
    switch(S[S_METER]){
        case 1: CAMU_SetAutoExposureWindow(s,160,120,320,240); CAMU_SetAutoWhiteBalanceWindow(s,160,120,320,240); break;
        case 2: CAMU_SetAutoExposureWindow(s,280,210,80,60);   CAMU_SetAutoWhiteBalanceWindow(s,280,210,80,60);   break;
        default: CAMU_SetAutoExposureWindow(s,0,0,640,480);    CAMU_SetAutoWhiteBalanceWindow(s,0,0,640,480); break;
    }
}
void cam_set_ev(int ev){ if(!g_cam.active) return; u32 s=sel_of(); CAMU_SetAutoExposure(s,true); CAMU_SetExposure(s,(s8)(ev<-5?-5:(ev>5?5:ev))); }

int cam_start(int src,int size,int fmt,int fps_enum){
    cam_stop();
    g_cam.src=src; g_cam.size=size; g_cam.fmt=fmt; g_cam.fps=fps_enum; g_cam.stereo=(src==1);
    g_cam.w=g_size_w[size]; g_cam.h=g_size_h[size];
    u32 s=sel_of(), p=port_of();
    CAMU_SetSize(s,k_sizes[size],CONTEXT_A);
    CAMU_SetOutputFormat(s,fmt?OUTPUT_YUV_422:OUTPUT_RGB_565,CONTEXT_A);
    CAMU_SetFrameRate(s,(S[S_EXPM]==3)?k_shut[S[S_SHUT]]:k_fps[fps_enum]);
    CAMU_SetTrimming(PORT_CAM1,false); CAMU_SetTrimming(PORT_CAM2,false);
    u32 mb=0; CAMU_GetMaxBytes(&mb,(s16)g_cam.w,(s16)g_cam.h); g_cam.maxbytes=mb;
    CAMU_SetTransferBytes(p,mb,(s16)g_cam.w,(s16)g_cam.h);
    g_cam.active=1;
    cam_apply_params();
    CAMU_Activate(s);
    CAMU_ClearBuffer(p);
    if(g_cam.stereo) CAMU_SynchronizeVsyncTiming(SELECT_OUT1,SELECT_OUT2);
    int ok=R_SUCCEEDED(CAMU_StartCapture(p));
    if(ok&&S[S_REGS]) run_regs(s);
    return ok;
}
int cam_grab(int to_ms){
    if(!g_cam.active) return 0;
    Handle ev[2]={0,0}; u32 sz=(u32)(g_cam.w*g_cam.h*2); int ok=1, n=g_cam.stereo?2:1;
    if(R_FAILED(CAMU_SetReceiving(&ev[0],g_cam.buf[0],PORT_CAM1,sz,(s16)g_cam.maxbytes))) ok=0;
    if(g_cam.stereo && R_FAILED(CAMU_SetReceiving(&ev[1],g_cam.buf[1],PORT_CAM2,sz,(s16)g_cam.maxbytes))) ok=0;
    for(int i=0;i<n;i++){ if(ev[i]){ if(R_FAILED(svcWaitSynchronization(ev[i],(s64)to_ms*1000000LL))) ok=0; svcCloseHandle(ev[i]); } else ok=0; }
    if(!ok){ u32 p=port_of(); CAMU_StopCapture(p); CAMU_ClearBuffer(p); CAMU_StartCapture(p); }
    return ok;
}
void cam_shutter_sound(int t){ CAMU_PlayShutterSound((CAMU_ShutterSoundType)t); }
