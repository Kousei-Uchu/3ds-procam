#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cam.h"
#include "settings.h"

Cam g_cam;
int g_cam_inval=1, g_cam_skip_params=0; u32 g_cam_frames, g_cam_timeouts;
const int g_size_w[3]={640,320,160}, g_size_h[3]={480,240,120};
static const CAMU_Size k_sizes[3]={SIZE_VGA,SIZE_QVGA,SIZE_QQVGA};
static const CAMU_FrameRate k_fps[5]={FRAME_RATE_30_TO_5,FRAME_RATE_20,FRAME_RATE_15,FRAME_RATE_10,FRAME_RATE_5};
static const CAMU_FrameRate k_shut[5]={FRAME_RATE_5,FRAME_RATE_10,FRAME_RATE_15,FRAME_RATE_20,FRAME_RATE_30};

/*
 * Camera DMA buffers.
 *  - They live in linear (physically contiguous) memory, which is what the camera DMA expects.
 *  - Two buffers per eye are used as a ping-pong pair: while the app processes frame N the camera
 *    is already writing frame N+1. Without this the camera runs out of buffers during slow
 *    processing, raises a buffer error and stops delivering frames (the "frozen first frame").
 *  - The CPU data cache is invalidated after every frame, otherwise the CPU keeps reading the stale
 *    cached copy of the first frame while the DMA writes the new ones straight to RAM.
 */
static uint8_t* dma[2][2];      // [eye][ping/pong]
static int      cur;            // ping/pong index that is currently armed for the next frame
static Handle   pend[2];        // completion event of the armed receive, per eye
#define FRAME_MAX (640*480*2)

static u32 sel_of(void){ return g_cam.src==1?SELECT_OUT1_OUT2:(g_cam.src==2?SELECT_IN1:SELECT_OUT1); }
u32 cam_select(void){ return sel_of(); }
static u32 port_of(void){ return g_cam.stereo?PORT_BOTH:PORT_CAM1; }

/* Ask the camera service to fill dma[eye][cur] with the next frame. */
static int arm(void){
    int n=g_cam.stereo?2:1; u32 sz=(u32)(g_cam.w*g_cam.h*2);
    for(int e=0;e<n;e++){
        pend[e]=0;
        if(R_FAILED(CAMU_SetReceiving(&pend[e],dma[e][cur],e?PORT_CAM2:PORT_CAM1,sz,(s16)g_cam.maxbytes))) return 0;
    }
    return 1;
}
static void drop_pending(void){ for(int e=0;e<2;e++) if(pend[e]){ svcCloseHandle(pend[e]); pend[e]=0; } }

/* optional user script /3ds/procam/regs.txt: lines "W aaaa dddd" (I2C reg) or "M aaaa dddd" (MCU var), hex; "#" comments */
static void run_regs(u32 s){
    FILE* f=fopen("/3ds/procam/regs.txt","r"); if(!f) return; char line[80];
    while(fgets(line,sizeof line,f)){ char t; unsigned a,v; if(line[0]=='#') continue;
        if(sscanf(line," %c %x %x",&t,&a,&v)==3){ if(t=='W'||t=='w') CAMU_WriteRegisterI2c(s,(u16)a,(u16)v); else if(t=='M'||t=='m') CAMU_WriteMcuVariableI2c(s,(u16)a,(u16)v); } }
    fclose(f);
}
int cam_init(void){
    if(R_FAILED(camInit())) return 0;
    for(int e=0;e<2;e++) for(int k=0;k<2;k++){
        dma[e][k]=(uint8_t*)linearAlloc(FRAME_MAX); if(!dma[e][k]) return 0;
        memset(dma[e][k],0,FRAME_MAX);
    }
    g_cam.buf[0]=dma[0][0]; g_cam.buf[1]=dma[1][0];
    return 1;
}
void cam_stop(void){
    if(!g_cam.active) return;
    CAMU_StopCapture(PORT_BOTH); CAMU_Activate(SELECT_NONE); drop_pending(); g_cam.active=0;
}
void cam_exit(void){
    cam_stop(); camExit();
    for(int e=0;e<2;e++) for(int k=0;k<2;k++){ if(dma[e][k]) linearFree(dma[e][k]); dma[e][k]=0; }
}
void cam_apply_params(void){
    if(!g_cam.active) return; u32 s=sel_of();
    int m=S[S_EXPM];
    CAMU_SetAutoExposure(s, m!=2);
    CAMU_SetExposure(s, (s8)((m==1||m==3)?S[S_EV]:0));
    CAMU_SetWhiteBalance(s,(CAMU_WhiteBalance)S[S_WB]);
    CAMU_SetAutoWhiteBalance(s,S[S_WB]==0);
    CAMU_SetPhotoMode(s,(CAMU_PhotoMode)S[S_PHOTO]);
    CAMU_SetSharpness(s,(s8)S[S_SHARP]);
    CAMU_SetContrast(s,(CAMU_Contrast)(S[S_CONTR]-1));
    CAMU_SetNoiseFilter(s,S[S_NOISE]!=0);
    CAMU_SetLensCorrection(s,(CAMU_LensCorrection)S[S_LENS]);
    CAMU_SetEffect(s,(CAMU_Effect)S[S_SFX],CONTEXT_A);
    CAMU_FlipImage(s,(CAMU_Flip)S[S_FLIP],CONTEXT_A);
    switch(S[S_METER]){
        case 1: CAMU_SetAutoExposureWindow(s,160,120,320,240); CAMU_SetAutoWhiteBalanceWindow(s,160,120,320,240); break;
        case 2: CAMU_SetAutoExposureWindow(s,280,210,80,60);   CAMU_SetAutoWhiteBalanceWindow(s,280,210,80,60);   break;
        default: CAMU_SetAutoExposureWindow(s,0,0,640,480);    CAMU_SetAutoWhiteBalanceWindow(s,0,0,640,480); break;
    }
}
void cam_set_ev(int ev){ if(!g_cam.active) return; u32 s=sel_of(); CAMU_SetAutoExposure(s,true); CAMU_SetExposure(s,(s8)(ev<-5?-5:(ev>5?5:ev))); }

int cam_start(int src,int size,int fmt,int fps_enum){
    cam_stop();
    g_cam.src=src; g_cam.size=size; g_cam.fmt=fmt; g_cam.fps=fps_enum; g_cam.stereo=(src==1);
    g_cam.w=g_size_w[size]; g_cam.h=g_size_h[size];
    u32 s=sel_of(), p=port_of();
    CAMU_SetSize(s,k_sizes[size],CONTEXT_A);
    CAMU_SetOutputFormat(s,fmt?OUTPUT_YUV_422:OUTPUT_RGB_565,CONTEXT_A);
    CAMU_SetFrameRate(s,(S[S_EXPM]==3)?k_shut[S[S_SHUT]]:k_fps[fps_enum]);
    CAMU_SetTrimming(PORT_CAM1,false); CAMU_SetTrimming(PORT_CAM2,false);
    u32 mb=0; CAMU_GetMaxBytes(&mb,(s16)g_cam.w,(s16)g_cam.h); g_cam.maxbytes=mb;
    CAMU_SetTransferBytes(p,mb,(s16)g_cam.w,(s16)g_cam.h);
    g_cam.active=1;
    if(!g_cam_skip_params) cam_apply_params();
    CAMU_Activate(s);
    CAMU_ClearBuffer(p);
    if(g_cam.stereo) CAMU_SynchronizeVsyncTiming(SELECT_OUT1,SELECT_OUT2);
    int ok=R_SUCCEEDED(CAMU_StartCapture(p));
    cur=0; drop_pending(); if(ok) ok=arm();      // queue the first receive straight away
    if(ok&&S[S_REGS]) run_regs(s);
    return ok;
}

/*
 * Wait for the next frame. On return g_cam.buf[eye] points at the finished frame, and the camera has
 * already been re-armed on the other buffer, so the caller can take as long as it likes with it.
 * The pointer stays valid until the next cam_grab call.
 */
int cam_grab(int to_ms){
    if(!g_cam.active) return 0;
    int n=g_cam.stereo?2:1, ok=1; u32 sz=(u32)(g_cam.w*g_cam.h*2);
    for(int e=0;e<n&&ok;e++){
        if(!pend[e] || R_FAILED(svcWaitSynchronization(pend[e],(s64)to_ms*1000000LL))) ok=0;
    }
    if(ok){
        for(int e=0;e<n;e++){
            if(g_cam_inval) GSPGPU_InvalidateDataCache(dma[e][cur],sz);   // drop stale cache lines of the old frame
            g_cam.buf[e]=dma[e][cur];
        }
        drop_pending(); cur^=1; arm(); g_cam_frames++;
        return 1;
    }
    /* Timeout or error: restart the capture pipeline and queue a fresh receive. */
    u32 p=port_of(); drop_pending(); g_cam_timeouts++;
    CAMU_StopCapture(p); CAMU_ClearBuffer(p); CAMU_StartCapture(p); cur=0; arm();
    return 0;
}
void cam_shutter_sound(int t){ CAMU_PlayShutterSound((CAMU_ShutterSoundType)t); }
