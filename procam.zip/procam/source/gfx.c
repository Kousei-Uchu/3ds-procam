#include <3ds.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "gfx.h"
#include "third/font8x8_basic.h"
#include "third/qrcodegen.h"

Canvas g_top = {400,240,0}, g_bot = {320,240,0};
uint16_t C_ACC, C_DIM, C_BG, C_FG, C_WARN;

void gfx_theme(int i){
    static const uint8_t acc[4][3] = {{0,220,255},{255,176,0},{80,255,100},{230,230,230}};
    C_ACC = rgb16(acc[i][0],acc[i][1],acc[i][2]);
    C_DIM = rgb16(acc[i][0]/3,acc[i][1]/3,acc[i][2]/3);
    C_BG = rgb16(8,8,10); C_FG = rgb16(235,235,235); C_WARN = rgb16(255,60,40);
}
void gfx_setup(void){
    gfxInit(GSP_RGB565_OES, GSP_RGB565_OES, false);
    g_top.p = (uint16_t*)calloc(400*240, 2);
    g_bot.p = (uint16_t*)calloc(320*240, 2);
    gfx_theme(0);
}
void gfx_shutdown(void){ free(g_top.p); free(g_bot.p); gfxExit(); }

/* The 3DS framebuffer is column-major and rotated, so every canvas needs a transpose.
   Walking it in 8-column tiles keeps both the reads and the writes inside the cache. */
static void present_one(gfxScreen_t s, Canvas* c){
    u16 fw, fh; uint16_t* fb = (uint16_t*)gfxGetFramebuffer(s, GFX_LEFT, &fw, &fh);
    for(int xb=0; xb<c->w; xb+=8){
        for(int y=0; y<240; y++){
            const uint16_t* src = c->p + y*c->w + xb;
            uint16_t* dst = fb + xb*240 + (239-y);
            for(int i=0; i<8; i++) dst[i*240] = src[i];
        }
    }
}
void gfx_present(void){
    present_one(GFX_TOP,&g_top); present_one(GFX_BOTTOM,&g_bot);
    gfxFlushBuffers(); gfxSwapBuffers(); gspWaitForVBlank();
}
void cv_clear(Canvas* c,uint16_t col){ for(int i=0;i<c->w*c->h;i++) c->p[i]=col; }
void cv_pset(Canvas* c,int x,int y,uint16_t col){ if((unsigned)x<(unsigned)c->w && (unsigned)y<(unsigned)c->h) c->p[y*c->w+x]=col; }
void cv_rect(Canvas* c,int x,int y,int w,int h,uint16_t col){
    if(x<0){w+=x;x=0;} if(y<0){h+=y;y=0;} if(x+w>c->w) w=c->w-x; if(y+h>c->h) h=c->h-y;
    for(int j=0;j<h;j++){ uint16_t* r=c->p+(y+j)*c->w+x; for(int i=0;i<w;i++) r[i]=col; }
}
void cv_rrect(Canvas* c,int x,int y,int w,int h,int r,uint16_t col){
    if(r*2>h) r=h/2; if(r*2>w) r=w/2; if(r<0) r=0;
    for(int j=0;j<h;j++){
        int jj=j<r?j:(j>=h-r?h-1-j:-1), inset=0;          // row index inside a corner band, or -1 for straight rows
        if(jj>=0){ float dy=r-(jj+0.5f); inset=(int)(r-sqrtf((float)(r*r)-dy*dy)+0.5f); }
        cv_rect(c,x+inset,y+j,w-2*inset,1,col);
    }
}
void cv_rect_a(Canvas* c,int x,int y,int w,int h,uint16_t col,int a){
    if(x<0){w+=x;x=0;} if(y<0){h+=y;y=0;} if(x+w>c->w) w=c->w-x; if(y+h>c->h) h=c->h-y;
    int cr=(col>>11)&31, cg=(col>>5)&63, cb=col&31;
    for(int j=0;j<h;j++){ uint16_t* q=c->p+(y+j)*c->w+x;
        for(int i=0;i<w;i++){ uint16_t p=q[i]; int r=(p>>11)&31, g=(p>>5)&63, b=p&31;
            r+=((cr-r)*a)>>8; g+=((cg-g)*a)>>8; b+=((cb-b)*a)>>8; q[i]=(uint16_t)((r<<11)|(g<<5)|b); } }
}
void cv_box(Canvas* c,int x,int y,int w,int h,uint16_t col){
    cv_rect(c,x,y,w,1,col); cv_rect(c,x,y+h-1,w,1,col); cv_rect(c,x,y,1,h,col); cv_rect(c,x+w-1,y,1,h,col);
}
void cv_line(Canvas* c,int x0,int y0,int x1,int y1,uint16_t col){
    int dx=abs(x1-x0), sx=x0<x1?1:-1, dy=-abs(y1-y0), sy=y0<y1?1:-1, err=dx+dy;
    for(;;){ cv_pset(c,x0,y0,col); if(x0==x1&&y0==y1) break; int e2=2*err;
        if(e2>=dy){err+=dy;x0+=sx;} if(e2<=dx){err+=dx;y0+=sy;} }
}
int cv_text_w(const char* s){ return (int)strlen(s)*8; }
int cv_text_scale_w(const char* s,int sc){ return (int)strlen(s)*8*sc; }
void cv_text_scale(Canvas* c,int x,int y,const char* s,uint16_t fg,int sc){
    for(;*s;s++,x+=8*sc){
        unsigned ch=(unsigned)(unsigned char)*s; if(ch>127) ch='?';
        const char* g=font8x8_basic[ch];
        for(int r=0;r<8;r++) for(int b=0;b<8;b++) if((g[r]>>b)&1) cv_rect(c,x+b*sc,y+r*sc,sc,sc,fg);
    }
}
void cv_text(Canvas* c,int x,int y,const char* s,uint16_t fg){
    for(;*s;s++,x+=8){
        unsigned ch=(unsigned char)*s; if(ch>127) ch='?';
        const char* g=font8x8_basic[ch];
        for(int r=0;r<8;r++) for(int b=0;b<8;b++) if((g[r]>>b)&1) cv_pset(c,x+b,y+r,fg);
    }
}
void cv_text_bg(Canvas* c,int x,int y,const char* s,uint16_t fg,uint16_t bg){
    cv_rect(c,x-1,y-1,cv_text_w(s)+2,10,bg); cv_text(c,x,y,s,fg);
}
void cv_blit_rgb(Canvas* c,int x,int y,const uint8_t* rgb,int w,int h){
    for(int j=0;j<h;j++){ int yy=y+j; if((unsigned)yy>=(unsigned)c->h) continue;
        for(int i=0;i<w;i++){ int xx=x+i; if((unsigned)xx>=(unsigned)c->w) continue;
            const uint8_t* s=rgb+(j*w+i)*3; c->p[yy*c->w+xx]=rgb16(s[0],s[1],s[2]); } }
}
/* Copy an RGB565 image 1:1 into the canvas (used for the unprocessed viewfinder). */
void cv_blit565(Canvas* c,int x,int y,const uint16_t* src,int w,int h){
    for(int j=0;j<h;j++){ int yy=y+j; if((unsigned)yy>=(unsigned)c->h) continue;
        int x0=x<0?-x:0, x1=(x+w>c->w)?c->w-x:w; if(x1<=x0) continue;
        memcpy(c->p+yy*c->w+x+x0, src+j*w+x0, (size_t)(x1-x0)*2); }
}
/* Scale-to-fit blit. The source column table is built once per call so the inner loop has no divisions
   (the 3DS CPU has no hardware divider, so a divide per pixel was very costly). */
void cv_blit_fit(Canvas* c,int x,int y,int bw,int bh,const uint8_t* rgb,int w,int h){
    int dw=bw, dh=(int)((long)h*bw/w);
    if(dh>bh){ dh=bh; dw=(int)((long)w*bh/h); }
    int ox=x+(bw-dw)/2, oy=y+(bh-dh)/2;
    static int colmap[400]; if(dw>400) dw=400;
    for(int i=0;i<dw;i++) colmap[i]=(i*w/dw)*3;
    for(int j=0;j<dh;j++){ int yy=oy+j; if((unsigned)yy>=(unsigned)c->h) continue;
        const uint8_t* row=rgb+(size_t)(j*h/dh)*w*3; uint16_t* d=c->p+yy*c->w;
        for(int i=0;i<dw;i++){ int xx=ox+i; if((unsigned)xx>=(unsigned)c->w) continue;
            const uint8_t* s=row+colmap[i]; d[xx]=(uint16_t)(((s[0]&0xF8)<<8)|((s[1]&0xFC)<<3)|(s[2]>>3)); } }
}
int cv_qr(Canvas* c,int x,int y,int scale,const char* text){
    static uint8_t qr[qrcodegen_BUFFER_LEN_MAX], tmp[qrcodegen_BUFFER_LEN_MAX];
    if(!qrcodegen_encodeText(text,tmp,qr,qrcodegen_Ecc_LOW,qrcodegen_VERSION_MIN,qrcodegen_VERSION_MAX,qrcodegen_Mask_AUTO,true)) return 0;
    int n=qrcodegen_getSize(qr), q=2;
    cv_rect(c,x,y,(n+2*q)*scale,(n+2*q)*scale,0xFFFF);
    for(int j=0;j<n;j++) for(int i=0;i<n;i++) if(qrcodegen_getModule(qr,i,j))
        cv_rect(c,x+(i+q)*scale,y+(j+q)*scale,scale,scale,0);
    return (n+2*q)*scale;
}
