#pragma once
#include <3ds.h>
#include "gfx.h"
#include "img.h"
enum { UI_NONE, UI_SHUTTER, UI_VIDEO, UI_GALLERY, UI_SHARE, UI_ACTION };
typedef struct { int page, sel, changed; } Menu;
extern Menu g_menu;
void ui_init(void);
int  ui_input(u32 down, u32 rep, const touchPosition* tp, int* act);
void ui_draw_bottom(int recording);
void ui_draw_grid(Canvas* c, int x, int y, int w, int h, int type);
void ui_draw_guide(Canvas* c, int x, int y, int w, int h, int mode);
void ui_draw_hist(Canvas* c, int x, int y, int w, int h, const Hist* hi, int mode);
void ui_draw_level(Canvas* c, int cx, int cy, float deg);
