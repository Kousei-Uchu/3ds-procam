// Experimental sensor register explorer: read/write camera I2C registers and MCU variables with a live preview.
// Uses libctru's CAMU_{Read,Write}RegisterI2c / McuVariableI2c. Register maps are sensor-specific: probe carefully.
#include <3ds.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "regtool.h"
#include "cam.h"
#include "gfx.h"
#include "img.h"
#include "settings.h"

static char g_log[8][48];
static void logf_(const char* fmt,...){
    memmove(g_log[1], g_log[0], sizeof g_log - sizeof g_log[0]);
    va_list ap; va_start(ap,fmt); vsnprintf(g_log[0], sizeof g_log[0], fmt, ap); va_end(ap);
}
static u32 sel_for(int tgt){ return tgt==0?SELECT_OUT1:(tgt==1?SELECT_OUT2:SELECT_IN1); }
static const char* tname[3]={"OUT1 (outer L)","OUT2 (outer R)","IN1  (inner)"};
static const char* tshort[3]={"OUT1","OUT2","IN1"};

static void dump_range(int tgt,int mcu,unsigned start){
    char p[96]; snprintf(p,sizeof p,"/3ds/procam/%s_%s_%04X.txt",mcu?"mcudump":"regdump",tshort[tgt],start);
    FILE* f=fopen(p,"w"); if(!f){ logf_("dump: cannot open file"); return; }
    unsigned okc=0;
    for(unsigned i=0;i<256&&start+i<=0xFFFF;i++){ u16 v=0; Result rc=mcu?CAMU_ReadMcuVariableI2cExclusive(&v,sel_for(tgt),(u16)(start+i)):CAMU_ReadRegisterI2cExclusive(&v,sel_for(tgt),(u16)(start+i));
        if(R_SUCCEEDED(rc)){ fprintf(f,"%04X %04X\n",start+i,v); okc++; } else fprintf(f,"%04X ----  rc=%08lX\n",start+i,(unsigned long)rc); }
    fclose(f); logf_("dumped %u regs from %04X",okc,start);
}
static void append_script(int tgt,int mcu,unsigned a,unsigned v){
    (void)tgt; FILE* f=fopen("/3ds/procam/regs.txt","a"); if(!f){ logf_("script: cannot open file"); return; }
    fprintf(f,"%c %04X %04X\n",mcu?'M':'W',a,v); fclose(f); logf_("script += %c %04X %04X",mcu?'M':'W',a,v);
}
void regtool_run(void){
    int tgt=0, mcu=0, cur=0; unsigned addr=0, val=0; memset(g_log,0,sizeof g_log);
    uint8_t* rgb=(uint8_t*)malloc(320*240*3); if(!rgb) return;
    int started=0;
    #define RESTART() do{ cam_start(tgt==2?2:(tgt==1?1:0),1,0,0); started=1; }while(0)
    RESTART(); logf_("Target %s ready",tshort[tgt]); 
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(), rep=hidKeysDownRepeat(); touchPosition tp; hidTouchRead(&tp);
        if(down&KEY_B) break;
        if(rep&KEY_DLEFT) cur=(cur+7)&7; if(rep&KEY_DRIGHT) cur=(cur+1)&7;
        if(rep&(KEY_DUP|KEY_DDOWN)){ unsigned* fld=cur<4?&addr:&val; int sh=(3-(cur&3))*4; unsigned d=(*fld>>sh)&15; d=(rep&KEY_DUP)?((d+1)&15):((d+15)&15); *fld=(*fld&~(0xFu<<sh))|(d<<sh); }
        if(down&KEY_X) mcu=!mcu;
        if(down&KEY_SELECT){ tgt=(tgt+1)%3; RESTART(); logf_("Target %s",tshort[tgt]); }
        int doread=down&KEY_A, dowrite=down&KEY_Y, dodump=down&KEY_ZL, dosave=down&KEY_START;
        if(down&KEY_TOUCH&&tp.py>=206){ int b=tp.px/80; doread=b==0; dowrite=b==1; dodump=b==2; dosave=b==3; }
        if(doread){ u16 v=0; Result rc=mcu?CAMU_ReadMcuVariableI2cExclusive(&v,sel_for(tgt),(u16)addr):CAMU_ReadRegisterI2cExclusive(&v,sel_for(tgt),(u16)addr);
            if(R_SUCCEEDED(rc)){ val=v; logf_("%s %04X = %04X",mcu?"MCU":"REG",addr,(unsigned)v); }
            else logf_("read %04X failed rc=%08X",addr,(unsigned)rc); }
        if(dowrite){ Result rc=mcu?CAMU_WriteMcuVariableI2c(sel_for(tgt),(u16)addr,(u16)val):CAMU_WriteRegisterI2c(sel_for(tgt),(u16)addr,(u16)val);
            logf_("write %04X <- %04X rc=%08X",addr,val,(unsigned)rc); }
        if(dodump){ cv_text_bg(&g_bot,60,100,"Dumping 256 registers...",C_FG,C_BG); gfx_present(); dump_range(tgt,mcu,addr&0xFF00u); }
        if(dosave) append_script(tgt,mcu,addr,val);
        /* live preview */
        cv_clear(&g_top,C_BG);
        if(cam_grab(120)){ rgb565_to_rgb((const uint16_t*)g_cam.buf[tgt==1?1:0],rgb,320*240); cv_blit_rgb(&g_top,40,0,rgb,320,240); }
        cv_text_bg(&g_top,44,4,"LIVE - watch the effect of writes",C_FG,rgb16(0,0,0));
        /* controls */
        cv_clear(&g_bot,C_BG); char b[64];
        cv_text(&g_bot,4,4,"SENSOR REGISTERS (EXPERIMENTAL)",C_WARN);
        snprintf(b,sizeof b,"Target: %s",tname[tgt]); cv_text(&g_bot,4,20,b,C_FG);
        snprintf(b,sizeof b,"Space : %s",mcu?"MCU variable":"I2C register"); cv_text(&g_bot,4,32,b,C_FG);
        cv_text(&g_bot,4,54,"Address",C_ACC); cv_text(&g_bot,4,80,"Value",C_ACC);
        for(int i=0;i<8;i++){ unsigned fld=i<4?addr:val; int sh=(3-(i&3))*4; char d[2]={"0123456789ABCDEF"[(fld>>sh)&15],0}; int x=80+i*16+(i>=4?24:0), y=i<4?50:76;
            cv_rect(&g_bot,x-2,y-3,14,16,i==cur?C_ACC:C_DIM); cv_text(&g_bot,x+2,y+1,d,i==cur?C_BG:C_FG); }
        cv_text(&g_bot,4,104,"Log:",C_DIM);
        for(int i=0;i<8;i++) cv_text(&g_bot,4,114+i*9,g_log[i],i==0?C_FG:rgb16(130,130,130));
        cv_text(&g_bot,4,190,"Pad:digit/edit X:space Sel:target B:exit",C_DIM);
        static const char* lab[4]={"READ","WRITE","DUMP","SCRIPT"};
        for(int i=0;i<4;i++){ cv_rect(&g_bot,i*80+2,206,76,30,C_DIM); cv_box(&g_bot,i*80+2,206,76,30,C_ACC); cv_text(&g_bot,i*80+2+(76-(int)strlen(lab[i])*8)/2,217,lab[i],C_FG); }
        gfx_present();
    }
    (void)started; cam_stop(); free(rgb);
}
