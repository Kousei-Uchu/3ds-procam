// Log exporter, see logs.h.
#include <3ds.h>
#include <arpa/inet.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <malloc.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <unistd.h>
#include "logs.h"
#include "diag.h"
#include "gui.h"
#include "gfx.h"
#include "settings.h"

/* ---------- saved sessions ---------- */
typedef struct { char name[24]; char title[24]; int ok, issue, total; } Sess;
#define MAXSESS 40
static Sess g_s[MAXSESS]; static int g_ns;
enum { F_ALL, F_ISSUES, F_LAST };
static const char* const k_fname[3]={"all","issues","last"};

static int cmp_sess(const void* a,const void* b){ return strcmp(((const Sess*)b)->name,((const Sess*)a)->name); }   /* newest first */
static void path_of(const char* name,char* out,int n){ snprintf(out,n,DIAG_DIR"/%s.txt",name); }

static void scan_session(Sess* s){
    char p[96]; path_of(s->name,p,sizeof p); FILE* f=fopen(p,"r"); if(!f) return; char line[512];
    while(fgets(line,sizeof line,f)){
        if(!strncmp(line,"session: ",9)){ size_t n=strcspn(line+9,"\r\n"); if(n>=sizeof s->title) n=sizeof s->title-1; memcpy(s->title,line+9,n); s->title[n]=0; }
        else if(line[0]>='0'&&line[0]<='9'){ s->total++; if(strstr(line," | OK ")) s->ok++; else if(strstr(line," | ISSUE ")) s->issue++; }
    }
    fclose(f);
}
static void list_sessions(void){
    g_ns=0; DIR* d=opendir(DIAG_DIR);
    if(d){ struct dirent* e;
        while((e=readdir(d))&&g_ns<MAXSESS){ size_t n=strlen(e->d_name); if(n<5||strcmp(e->d_name+n-4,".txt")) continue; if(n-4>=sizeof g_s[0].name) continue;
            Sess* s=&g_s[g_ns]; memset(s,0,sizeof *s); memcpy(s->name,e->d_name,n-4); snprintf(s->title,sizeof s->title,"%s",s->name); scan_session(s); g_ns++; }
        closedir(d); }
    qsort(g_s,g_ns,sizeof g_s[0],cmp_sess);
}

/* ---------- building the text that gets sent ---------- */
#define TEXT_MAX 24576
static char g_text[TEXT_MAX];
/* compact=1 drops the test name column so more fits into each QR code. */
static int build_text(const Sess* s,int filter,int compact){
    char p[96]; path_of(s->name,p,sizeof p); FILE* f=fopen(p,"r"); g_text[0]=0; if(!f) return 0;
    char line[512], last[512]; last[0]=0; size_t n=0;
    while(fgets(line,sizeof line,f)){
        int is_test=(line[0]>='0'&&line[0]<='9');
        if(is_test){
            int answered=(strstr(line," | OK ")||strstr(line," | ISSUE "));
            if(filter==F_ISSUES&&!strstr(line," | ISSUE ")) continue;
            if(filter==F_LAST){ if(answered) snprintf(last,sizeof last,"%s",line); continue; }
            if(!answered) continue;                                   /* never send tests that were not run */
            if(compact){                                              /* drop the test name column, keep number, result and numbers */
                const char* c=line; for(int k=0;k<3&&c;k++){ c=strstr(c," | "); if(c) c+=3; }
                if(c){ char tmp[512]; snprintf(tmp,sizeof tmp,"%.2s|%s|%s",line,strstr(line," | ISSUE ")?"ISSUE":"OK",c); snprintf(line,sizeof line,"%s",tmp); } }
        }
        size_t l=strlen(line); if(n+l+1>=TEXT_MAX) break; memcpy(g_text+n,line,l); n+=l;
    }
    if(filter==F_LAST&&last[0]){ size_t l=strlen(last); if(n+l+1<TEXT_MAX){ memcpy(g_text+n,last,l); n+=l; } }
    fclose(f); g_text[n]=0; return (int)n;
}

/* ---------- tiny HTTP server ---------- */
static int send_all(int s,const void* d,size_t n){
    const char* p=(const char*)d; while(n){ ssize_t k=send(s,p,n,0); if(k<0){ if(errno==EAGAIN||errno==EWOULDBLOCK){ svcSleepThread(2000000); continue; } return 0; } if(k==0) return 0; p+=k; n-=(size_t)k; } return 1;
}
static int name_ok(const char* n){ if(!*n||strlen(n)>20) return 0; for(;*n;n++) if(!((*n>='0'&&*n<='9')||*n=='-')) return 0; return 1; }
static size_t html_escape(char* out,size_t cap,const char* in){
    size_t n=0; for(;*in&&n+7<cap;in++){ const char* r=*in=='<'?"&lt;":(*in=='>'?"&gt;":(*in=='&'?"&amp;":NULL)); if(r){ size_t l=strlen(r); memcpy(out+n,r,l); n+=l; } else out[n++]=*in; }
    out[n]=0; return n;
}
static int g_hits;
/* Copy logic, in layers because phone browsers differ and plain http blocks the modern clipboard API:
   1 select the visible text box and run execCommand('copy') (works on current iOS Safari and Android Chrome),
   2 an off-screen box selected through a range (older iOS),
   3 navigator.clipboard when the page is allowed to use it.
   The button only says COPIED when a method really reported success; otherwise the text is left selected so a
   long press shows the system Copy menu. */
static const char k_copy_js[]=
"function sel(t){t.readOnly=false;t.focus();t.select();try{t.setSelectionRange(0,t.value.length)}catch(e){}}"
"function done(ok,n){var b=document.getElementById('b');b.textContent=ok?'COPIED '+n+' characters':'Copy blocked: tap SELECT ALL, then Copy in the popup';b.style.background=ok?'#3ddc84':'#ffb02e'}"
"function cp(){var t=document.getElementById('t'),x=t.value,ok=false;sel(t);"
"try{ok=document.execCommand('copy')}catch(e){}"
"if(!ok){var a=document.createElement('textarea');a.value=x;a.contentEditable=true;a.readOnly=false;a.style.cssText='position:fixed;top:0;left:0;opacity:0';document.body.appendChild(a);"
"var r=document.createRange();r.selectNodeContents(a);var s=getSelection();s.removeAllRanges();s.addRange(r);a.setSelectionRange(0,999999);"
"try{ok=document.execCommand('copy')}catch(e){}document.body.removeChild(a)}"
"if(!ok&&navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(x).then(function(){done(true,x.length)},function(){done(false);sel(t)});return}"
"done(ok,x.length);if(!ok)sel(t)}";
static void serve_page(int c,const Sess* s,int filter){
    static char html[TEXT_MAX*2];
    build_text(s,filter,0);
    static char esc[TEXT_MAX*2-3000]; html_escape(esc,sizeof esc,g_text);
    int n=snprintf(html,sizeof html,
        "HTTP/1.0 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nConnection: close\r\n\r\n"
        "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>PROCAM log</title>"
        "<style>body{background:#0b0c10;color:#eee;font:15px sans-serif;margin:12px}"
        "button,a.l{display:block;box-sizing:border-box;font-size:19px;padding:15px;width:100%%;border:0;border-radius:12px;background:#2bc0ff;color:#012;font-weight:700;margin-top:10px;text-align:center;text-decoration:none}"
        "button.s{background:#2a2f3a;color:#dfe}"
        "textarea{width:100%%;box-sizing:border-box;height:50vh;margin-top:12px;background:#15181f;color:#cfe;border:1px solid #333;border-radius:8px;font:13px monospace}</style>"
        "<h3>PROCAM log %s (%s)</h3><button id=b onclick='cp()'>COPY ALL</button>"
        "<button class=s onclick='sel(document.getElementById(\"t\"))'>SELECT ALL</button>"
        "<a class=l style='background:#2a2f3a;color:#dfe' href='/t/%s?f=%s'>OPEN AS PLAIN TEXT</a>"
        "<textarea id=t>%s</textarea><script>%s</script>",
        s->title,k_fname[filter],s->name,k_fname[filter],esc,k_copy_js);
    send_all(c,html,(size_t)n);
}
static void serve_text(int c,const Sess* s,int filter){        /* raw text, for long-press select or saving */
    static char out[TEXT_MAX+160]; build_text(s,filter,0);
    int n=snprintf(out,sizeof out,"HTTP/1.0 200 OK\r\nContent-Type: text/plain; charset=utf-8\r\nConnection: close\r\n\r\n%s",g_text);
    send_all(c,out,(size_t)n);
}
static void serve_index(int c){
    static char html[4096]; int n=snprintf(html,sizeof html,
        "HTTP/1.0 200 OK\r\nContent-Type: text/html\r\nConnection: close\r\n\r\n"
        "<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><title>PROCAM logs</title>"
        "<style>body{background:#0b0c10;color:#eee;font:16px sans-serif;margin:12px}a{color:#4cf;display:block;padding:12px 0}</style><h3>PROCAM saved runs</h3>");
    for(int i=0;i<g_ns&&n<(int)sizeof html-200;i++) n+=snprintf(html+n,sizeof html-n,"<a href='/s/%s?f=all'>%s (OK %d, ISSUE %d)</a>",g_s[i].name,g_s[i].title,g_s[i].ok,g_s[i].issue);
    send_all(c,html,(size_t)n);
}
static void handle_client(int c){
    char req[400]; ssize_t n=recv(c,req,sizeof req-1,0); if(n<=0) return; req[n]=0;
    if(strncmp(req,"GET ",4)){ send_all(c,"HTTP/1.0 405 Method Not Allowed\r\n\r\n",35); return; }
    char* path=req+4; char* sp=strchr(path,' '); if(sp) *sp=0;
    int filter=F_ALL; char* q=strchr(path,'?'); if(q){ *q=0; if(strstr(q+1,"f=issues")) filter=F_ISSUES; else if(strstr(q+1,"f=last")) filter=F_LAST; }
    if(!strcmp(path,"/")){ serve_index(c); g_hits++; return; }
    if(!strncmp(path,"/s/",3)&&name_ok(path+3)){
        for(int i=0;i<g_ns;i++) if(!strcmp(g_s[i].name,path+3)){ serve_page(c,&g_s[i],filter); g_hits++; return; } }
    if(!strncmp(path,"/t/",3)&&name_ok(path+3)){
        for(int i=0;i<g_ns;i++) if(!strcmp(g_s[i].name,path+3)){ serve_text(c,&g_s[i],filter); g_hits++; return; } }
    send_all(c,"HTTP/1.0 404 Not Found\r\n\r\nnot found",33);
}

/* ---------- screens ---------- */
enum { SC_LIST, SC_SEND, SC_TEXTQR };
#define LIST_Y0 24
#define LIST_ROW 20
#define LIST_ROWS 8
static int g_scroll;
static int hit_list(int px,int py){
    if(py>=192&&py<236&&px>=4&&px<316) return 1;                                   /* back */
    if(px>=292&&px<318&&py>=LIST_Y0&&py<LIST_Y0+34) return 2;                      /* up */
    if(px>=292&&px<318&&py>=LIST_Y0+38&&py<LIST_Y0+72) return 3;                   /* down */
    if(px>=4&&px<288&&py>=LIST_Y0&&py<LIST_Y0+LIST_ROWS*LIST_ROW){ int r=(py-LIST_Y0)/LIST_ROW+g_scroll; if(r<g_ns) return 400+r; }
    return -1;
}
static void draw_list(const GuiTouch* tc){
    char b[48]; cv_clear(&g_top,C_BG); cv_clear(&g_bot,C_BG);
    cv_text_scale(&g_top,200-cv_text_scale_w("SEND LOGS",3)/2,60,"SEND LOGS",col_txt(),3);
    snprintf(b,sizeof b,"%d saved run%s",g_ns,g_ns==1?"":"s"); cv_text(&g_top,200-cv_text_w(b)/2,110,b,col_dim());
    cv_text(&g_top,200-cv_text_w("Pick a run on the bottom screen")/2,130,"Pick a run on the bottom screen",col_dim());
    cv_text(&g_bot,6,8,"SAVED RUNS (green OK, red ISSUE)",C_ACC);
    if(!g_ns){ gui_card(&g_bot,4,LIST_Y0,284,LIST_ROWS*LIST_ROW,col_card()); cv_text(&g_bot,146-cv_text_w("No runs saved yet")/2,LIST_Y0+70,"No runs saved yet",col_dim()); }
    for(int r=0;r<LIST_ROWS&&r+g_scroll<g_ns;r++){ const Sess* s=&g_s[r+g_scroll]; int y=LIST_Y0+r*LIST_ROW;
        gui_card(&g_bot,4,y,284,LIST_ROW-2,gui_down(tc,400+r+g_scroll)?col_edge():col_card());
        cv_text(&g_bot,10,y+5,s->title,col_txt());
        snprintf(b,sizeof b,"%d",s->issue); int w=gui_pill_w(b); gui_pill(&g_bot,282-w,y+2,b,s->issue?col_bad():col_edge(),col_txt());
        snprintf(b,sizeof b,"%d",s->ok); int w2=gui_pill_w(b); gui_pill(&g_bot,282-w-4-w2,y+2,b,s->ok?col_ok():col_edge(),rgb16(8,12,10)); }
    if(g_ns>LIST_ROWS){ gui_button(292,LIST_Y0,26,34,BK_NEUTRAL,IC_UP,"",gui_down(tc,2)); gui_button(292,LIST_Y0+38,26,34,BK_NEUTRAL,IC_DOWN,"",gui_down(tc,3)); }
    gui_button(4,192,312,44,BK_NEUTRAL,IC_BACK,"BACK",gui_down(tc,1));
}

/* Draw a QR code as large as an integer pixel scale allows inside max x max pixels, return its size. */
static int draw_qr(Canvas* c,int x,int y,int max,const char* text){
    int m=cv_qr_modules(text); if(!m) return 0; int scale=max/m; if(scale<1) scale=1;
    return cv_qr(c,x,y,scale,text);
}

static int g_ls=-1, g_soc_up; static u32* g_socbuf;
static char g_url[96];
static void net_up(void){
    if(g_soc_up) return;
    g_socbuf=(u32*)memalign(0x1000,0x100000);
    if(g_socbuf&&R_SUCCEEDED(socInit(g_socbuf,0x100000))) g_soc_up=1; else { free(g_socbuf); g_socbuf=NULL; }
}
static void net_down(void){
    if(g_ls>=0){ closesocket(g_ls); g_ls=-1; }
    if(g_soc_up){ socExit(); free(g_socbuf); g_socbuf=NULL; g_soc_up=0; }
}
static int server_start(void){
    net_up(); if(!g_soc_up) return 0;
    if(g_ls>=0) return 1;
    static const int ports[4]={8080,8000,8888,3000}; int port=ports[S[S_PORT]];
    g_ls=socket(AF_INET,SOCK_STREAM,0); if(g_ls<0) return 0;
    struct sockaddr_in a; memset(&a,0,sizeof a); a.sin_family=AF_INET; a.sin_port=htons((uint16_t)port); a.sin_addr.s_addr=htonl(INADDR_ANY);
    if(bind(g_ls,(struct sockaddr*)&a,sizeof a)!=0||listen(g_ls,4)!=0){ closesocket(g_ls); g_ls=-1; return 0; }
    fcntl(g_ls,F_SETFL,fcntl(g_ls,F_GETFL,0)|O_NONBLOCK);
    struct in_addr ip; ip.s_addr=(in_addr_t)gethostid(); if(!ip.s_addr){ closesocket(g_ls); g_ls=-1; return 0; }
    snprintf(g_url,sizeof g_url,"http://%s:%d",inet_ntoa(ip),port); return 1;
}
static void server_poll(void){
    if(g_ls<0) return; struct sockaddr_in ca; socklen_t cl=sizeof ca; int c=accept(g_ls,(struct sockaddr*)&ca,&cl);
    if(c>=0){ fcntl(c,F_SETFL,fcntl(c,F_GETFL,0)&~O_NONBLOCK); handle_client(c); closesocket(c); }
}

enum { B_BACK=1, B_FALL=10, B_FISS=11, B_FLAST=12, B_TEXTQR=13, B_PREV=14, B_NEXT=15 };
static int hit_send(int px,int py){
    if(py>=60&&py<98){ if(px>=4&&px<106) return B_FALL; if(px>=110&&px<212) return B_FISS; if(px>=216&&px<316) return B_FLAST; }
    if(py>=190&&py<236){ if(px>=4&&px<160) return B_TEXTQR; if(px>=164&&px<316) return B_BACK; }
    return -1;
}
static void draw_send(const Sess* s,int filter,int net_ok,const GuiTouch* tc){
    char b[96], url[160]; cv_clear(&g_top,C_BG); cv_clear(&g_bot,C_BG);
    if(net_ok){ snprintf(url,sizeof url,"%s/s/%s?f=%s",g_url,s->name,k_fname[filter]);
        gui_card(&g_top,6,2,236,236,0xFFFF); draw_qr(&g_top,10,6,228,url);
        cv_text(&g_top,252,16,"SCAN WITH",col_dim()); cv_text(&g_top,252,28,"YOUR PHONE",col_dim());
        cv_text(&g_top,252,52,"1 Same Wi-Fi",col_txt()); cv_text(&g_top,252,66,"2 Scan QR",col_txt()); cv_text(&g_top,252,80,"3 Tap COPY ALL",col_txt()); cv_text(&g_top,252,94,"4 Paste to me",col_txt());
        cv_text(&g_top,252,112,g_url+7,C_ACC); snprintf(b,sizeof b,"pages sent: %d",g_hits); cv_text(&g_top,252,140,b,col_dim()); }
    else { cv_text_scale(&g_top,200-cv_text_scale_w("NO WI-FI",3)/2,70,"NO WI-FI",col_bad(),3);
        cv_text(&g_top,200-cv_text_w("Connect the 3DS to Wi-Fi, or use TEXT QR")/2,120,"Connect the 3DS to Wi-Fi, or use TEXT QR",col_dim()); }
    gui_card(&g_bot,4,6,312,46,col_card()); cv_text(&g_bot,12,14,s->title,col_txt());
    snprintf(b,sizeof b,"OK %d",s->ok); gui_pill(&g_bot,12,30,b,col_ok(),rgb16(8,12,10)); int w=gui_pill_w(b);
    snprintf(b,sizeof b,"ISSUE %d",s->issue); gui_pill(&g_bot,12+w+6,30,b,s->issue?col_bad():col_edge(),col_txt());
    gui_button(4,60,102,38,filter==F_ALL?BK_ACCENT:BK_NEUTRAL,IC_NONE,"ALL",gui_down(tc,B_FALL));
    gui_button(110,60,102,38,filter==F_ISSUES?BK_ACCENT:BK_NEUTRAL,IC_NONE,"ISSUES",gui_down(tc,B_FISS));
    gui_button(216,60,100,38,filter==F_LAST?BK_ACCENT:BK_NEUTRAL,IC_NONE,"LAST TEST",gui_down(tc,B_FLAST));
    gui_wrap(&g_bot,8,108,"ALL sends every test that was run. ISSUES sends only flagged tests. LAST TEST sends the newest result.",38,4,col_dim());
    gui_button(4,190,156,46,BK_NEUTRAL,IC_NONE,"TEXT QR",gui_down(tc,B_TEXTQR));
    gui_button(164,190,152,46,BK_NEUTRAL,IC_BACK,"BACK",gui_down(tc,B_BACK));
}

/* Offline mode: the text is cut into pages that each fit one QR code. */
#define PAGE_MAX 40
#define PAGE_BYTES 320
static int g_pages, g_poff[PAGE_MAX+1];
static void paginate(void){
    g_pages=0; size_t n=strlen(g_text), pos=0;
    while(pos<n&&g_pages<PAGE_MAX){ g_poff[g_pages]=(int)pos; size_t end=pos;
        while(end<n){ const char* nl=memchr(g_text+end,'\n',n-end); size_t le=nl?(size_t)(nl-(g_text+end))+1:n-end; if(end+le-pos>PAGE_BYTES&&end>pos) break; end+=le; if(end-pos>=PAGE_BYTES) break; }
        pos=end; g_pages++; }
    g_poff[g_pages]=(int)n;
}
static int hit_textqr(int px,int py){
    if(py>=190&&py<236){ if(px>=4&&px<104) return B_PREV; if(px>=108&&px<208) return B_NEXT; if(px>=212&&px<316) return B_BACK; }
    return -1;
}
static void draw_textqr(const Sess* s,int page,const GuiTouch* tc){
    char hdr[48], b[48]; static char buf[PAGE_BYTES+96];
    cv_clear(&g_top,C_BG); cv_clear(&g_bot,C_BG);
    if(!g_pages){ cv_text(&g_top,200-cv_text_w("Nothing to send for this filter")/2,116,"Nothing to send for this filter",col_dim()); }
    else { snprintf(hdr,sizeof hdr,"PROCAM %s %d/%d\n",s->name,page+1,g_pages);
        int len=g_poff[page+1]-g_poff[page]; snprintf(buf,sizeof buf,"%s%.*s",hdr,len,g_text+g_poff[page]);
        gui_card(&g_top,80,2,240,236,0xFFFF); if(!draw_qr(&g_top,84,6,232,buf)) cv_text(&g_top,150,116,"too long",col_bad()); }
    snprintf(b,sizeof b,"PAGE %d OF %d",g_pages?page+1:0,g_pages); cv_text(&g_bot,160-cv_text_w(b)/2,20,b,C_ACC);
    gui_wrap(&g_bot,8,50,"Scan each page in order, pasting after each scan. For long logs, the Wi-Fi page is easier.",38,4,col_dim());
    gui_button(4,190,100,46,BK_NEUTRAL,IC_UP,"PREV",gui_down(tc,B_PREV)); gui_button(108,190,100,46,BK_NEUTRAL,IC_DOWN,"NEXT",gui_down(tc,B_NEXT));
    gui_button(212,190,104,46,BK_NEUTRAL,IC_BACK,"BACK",gui_down(tc,B_BACK));
}

void logs_run(void){
    int screen=SC_LIST, sel=0, filter=F_ISSUES, net_ok=0, page=0; GuiTouch tc={-1,-1,0,0}; g_scroll=0; g_hits=0;
    list_sessions();
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(), up=hidKeysUp(), held=hidKeysHeld(); touchPosition tp; hidTouchRead(&tp);
        GuiHit hit=screen==SC_LIST?hit_list:(screen==SC_SEND?hit_send:hit_textqr);
        int id=gui_touch(&tc,hit,down,up,held,&tp);
        if(down&KEY_B) id=(screen==SC_LIST)?1:B_BACK;
        if(screen==SC_LIST){
            if(id==1) break;
            if(id==2&&g_scroll>0) g_scroll--; if(id==3&&g_scroll<g_ns-LIST_ROWS) g_scroll++;
            if(id>=400){ sel=id-400; screen=SC_SEND; net_ok=server_start(); }
            draw_list(&tc);
        } else if(screen==SC_SEND){
            if(id==B_BACK){ screen=SC_LIST; if(g_ls>=0){ closesocket(g_ls); g_ls=-1; } }
            else if(id==B_FALL) filter=F_ALL; else if(id==B_FISS) filter=F_ISSUES; else if(id==B_FLAST) filter=F_LAST;
            else if(id==B_TEXTQR){ build_text(&g_s[sel],filter,1); paginate(); page=0; screen=SC_TEXTQR; }
            if(screen==SC_SEND){ if(net_ok) server_poll(); draw_send(&g_s[sel],filter,net_ok,&tc); }
        } else {
            if(id==B_BACK) screen=SC_SEND; else if(id==B_PREV&&page>0) page--; else if(id==B_NEXT&&page<g_pages-1) page++;
            if(screen==SC_TEXTQR) draw_textqr(&g_s[sel],page,&tc);
        }
        gfx_present();
    }
    net_down();
}
