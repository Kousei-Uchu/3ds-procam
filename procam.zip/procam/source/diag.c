// PROCAM diagnostic mode.
// Runs ONE isolated test at a time (camera feed, a single sensor setting, a single software stage...),
// shows live numbers, and lets you mark the test OK or ISSUE. Results are written to
// /3ds/procam/diag_report.txt after every answer, so nothing is lost if you quit early.
//
// Controls (touch buttons on the bottom screen or keys):
//   OK    / A      test is fine, go to the next one
//   ISSUE / X      flag this exact test as having a problem, go to the next one
//   BACK  / B      previous test
//   END   / START  jump to the summary screen
#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "diag.h"
#include "settings.h"
#include "gfx.h"
#include "img.h"
#include "enc.h"
#include "cam.h"
#include "ui.h"

#define REPORT_PATH "/3ds/procam/diag_report.txt"
#define MAXPX (640*480)

/* What the test does with the frame once it has been grabbed. */
enum { SH_DIRECT, SH_RGB, SH_LOOK0, SH_LOOKAPP, SH_ZEB, SH_PEAK, SH_HIST, SH_CLIP, SH_STAB,
       SH_HALF, SH_ANA, SH_PRESENT, SH_JPG, SH_MOTION };
/* Which single sensor setting is applied on top of the untouched hardware defaults. */
enum { PR_NONE, PR_APP, PR_SHARP, PR_NOISE, PR_LENS, PR_CONTRAST };

typedef struct {
    const char* name;      // short title
    const char* look;      // what to look for, shown on the bottom screen
    int src, size, fmt, fps;   // camera setup (src -1 = no camera needed)
    int params;            // PR_*
    int inval;             // 1 = invalidate cache after each frame (normal), 0 = skip (cache experiment)
    int yord, yrng;        // YUV decode options for fmt 1
    int show;              // SH_*
} Test;

static const Test T[] = {
 /* ---- A. camera feed on its own, nothing else running ---- */
 {"Bare feed RGB565 QVGA","Sensor at hardware defaults, straight to screen. Expect a clean, smooth, moving picture.",        0,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Bare feed, cache NOT flushed","Same as test 1 but with the cache fix switched off. Does it freeze or look garbled?",     0,1,0,0, PR_NONE,0, 0,0, SH_DIRECT},
 {"Feed + your camera settings","Applies the CAM page settings (exposure, WB, sharpness, contrast, noise, lens).",          0,1,0,0, PR_APP, 1, 0,0, SH_DIRECT},
 {"Sharpness +1 only","Only sharpness +1 on top of defaults. Is the picture crunchy or over sharpened?",                      0,1,0,0, PR_SHARP,1,0,0, SH_DIRECT},
 {"Noise filter only","Only the sensor noise filter on top of defaults.",                                                    0,1,0,0, PR_NOISE,1,0,0, SH_DIRECT},
 {"Lens correction only","Only lens correction (70) on top of defaults. Look at the corners.",                               0,1,0,0, PR_LENS, 1,0,0, SH_DIRECT},
 {"Contrast pattern only","Only the contrast pattern from settings on top of defaults.",                                     0,1,0,0, PR_CONTRAST,1,0,0, SH_DIRECT},
 {"Fixed 15 fps","Frame rate forced to 15. The fps readout should sit near 15.",                                             0,1,0,2, PR_NONE,1, 0,0, SH_DIRECT},
 {"Inner camera","Selfie camera, bare. Clean and smooth?",                                                                   2,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Stereo pair, left eye","Both outer cameras are running, only the left eye is shown. Check the numbers.",                 1,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Stereo anaglyph","Red/cyan mix of both eyes. Smooth, with a sensible fps?",                                               1,1,0,0, PR_NONE,1, 0,0, SH_ANA},
 {"VGA 640x480 RGB565","Full size sensor mode, converted and scaled to fit. Expect slower, but still moving.",               0,0,0,0, PR_NONE,1, 0,0, SH_RGB},
 {"YUV422 YUYV full range","Raw sensor pipe. Are the colours right? (checks the YUV byte order/range settings)",            0,1,1,0, PR_NONE,1, 0,0, SH_RGB},
 {"YUV422 UYVY full range","Raw sensor pipe, other byte order. Better or worse than the previous test?",                    0,1,1,0, PR_NONE,1, 1,0, SH_RGB},
 {"YUV422 YUYV limited","Raw sensor pipe, limited range.",                                                                   0,1,1,0, PR_NONE,1, 0,1, SH_RGB},
 {"YUV422 UYVY limited","Raw sensor pipe, other order, limited range.",                                                      0,1,1,0, PR_NONE,1, 1,1, SH_RGB},
 /* ---- B. software stages, one at a time, on the bare QVGA feed ---- */
 {"RGB888 convert + fit","Converts to RGB888 and scales to fit, like the app does when overlays are on, but with none enabled.",0,1,0,0, PR_NONE,1, 0,0, SH_RGB},
 {"Look: neutral","Runs the look engine with everything off. Should look identical to the previous test.",                      0,1,0,0, PR_NONE,1, 0,0, SH_LOOK0},
 {"Look: your settings","Runs the look engine with the STY page settings (grain, crush, vignette...). Compare speed.",         0,1,0,0, PR_NONE,1, 0,0, SH_LOOKAPP},
 {"Zebras","Zebra stripes over bright areas only.",                                                                          0,1,0,0, PR_NONE,1, 0,0, SH_ZEB},
 {"Focus peaking","Red edge highlight only. Is it covering the whole picture?",                                              0,1,0,0, PR_NONE,1, 0,0, SH_PEAK},
 {"Histogram","Histogram widget only.",                                                                                      0,1,0,0, PR_NONE,1, 0,0, SH_HIST},
 {"Clip warning","Blinking highlight clip warning only.",                                                                    0,1,0,0, PR_NONE,1, 0,0, SH_CLIP},
 {"Stabiliser","Image stabiliser only. Wave the console around gently.",                                                     0,1,0,0, PR_NONE,1, 0,0, SH_STAB},
 {"Half-size look (fast preview)","Look engine on a half-size picture, as Fast preview does. Compare speed with the look tests.",0,1,0,0, PR_NONE,1, 0,0, SH_HALF},
 /* ---- C. everything that is not the camera ---- */
 {"Screen present speed","No camera. A bar sweeps across the top screen. Is it smooth?",                                     -1,0,0,0, PR_NONE,1, 0,0, SH_PRESENT},
 {"JPG encode + SD write","No camera. Encodes a 320x240 test image and writes it to the SD card. Check the times.",           -1,0,0,0, PR_NONE,1, 0,0, SH_JPG},
 {"Motion sensors","No camera. Tilt and shake the console. Do the accelerometer and gyro numbers move?",                       -1,0,0,0, PR_NONE,1, 0,0, SH_MOTION},
};
#define NT ((int)(sizeof T/sizeof T[0]))

enum { R_NONE, R_OK, R_ISSUE };
enum { A_OK, A_ISSUE, A_BACK, A_END };

static int  g_res[NT];             // R_*
static char g_det[NT][112];        // numbers captured when the test was answered
static uint8_t *rgbA, *rgbB, *disp;

/* ---------- small helpers ---------- */
static u64 us_now(void){ return svcGetSystemTick()/268; }   // ARM11 ticks at about 268.1 MHz
static void fmt1(char* b,int n,u64 us){ snprintf(b,n,"%u.%u",(unsigned)(us/1000),(unsigned)((us%1000)/100)); }

static void look_from_settings(Look* l,uint32_t seed){
    l->style=S[S_STYLE]; l->amt=S[S_SAMT]; l->bright=S[S_BRIGHT]; l->con=S[S_CON]; l->sat=S[S_SAT]; l->temp=S[S_TEMP]; l->tint=S[S_TINT];
    l->vign=S[S_VIGN]; l->grain=S[S_GRAIN]; l->scan=S[S_SCAN]; l->crush=S[S_CRUSH]; l->dither=S[S_DITH]; l->soft=S[S_SOFT];
    l->pix=S[S_PIX]; l->funky=S[S_FUNKY]; l->famt=S[S_FAMT]; l->seed=seed;
}
/* Decode a raw sensor buffer (RGB565 or YUV422) into RGB888. */
static void to_rgb(const uint8_t* b,int w,int h,const Test* t,uint8_t* out){
    if(t->fmt) yuv_to_rgb(b,out,w,h,t->yord,t->yrng); else rgb565_to_rgb((const uint16_t*)b,out,w*h);
}
/* Cheap fingerprint of a frame (64 sampled pixels). Identical fingerprints on a live sensor mean stale data. */
static uint32_t fingerprint(const uint8_t* b,int w,int h){
    const uint16_t* p=(const uint16_t*)b; uint32_t n=(uint32_t)w*h, hsh=2166136261u;
    for(int k=0;k<64;k++){ hsh^=p[(k*7919u)%n]; hsh*=16777619u; }
    return hsh;
}
static void wrap_text(Canvas* c,int x,int y,const char* s,int cols,int maxlines,uint16_t col){
    char line[48]; int n=(int)strlen(s), pos=0;
    for(int ln=0;ln<maxlines&&pos<n;ln++){
        int len=(n-pos<cols)?n-pos:cols;
        if(pos+len<n){ int k=len; while(k>0&&s[pos+k]!=' ') k--; if(k>0) len=k; }
        memcpy(line,s+pos,len); line[len]=0; cv_text(c,x,y,line,col); y+=10; pos+=len; while(s[pos]==' ') pos++;
    }
}
static void button(int x,int y,int w,int h,const char* label,uint16_t fill,uint16_t edge){
    cv_rect(&g_bot,x,y,w,h,fill); cv_box(&g_bot,x,y,w,h,edge);
    cv_text(&g_bot,x+(w-cv_text_w(label))/2,y+(h-8)/2,label,C_FG);
}

/* ---------- report ---------- */
static const char* res_name(int r){ return r==R_OK?"OK":(r==R_ISSUE?"ISSUE":"-"); }
static void write_report(void){
    FILE* f=fopen(REPORT_PATH,"w"); if(!f) return;
    fprintf(f,"PROCAM diagnostic report\nsettings: speed=%d fastpv=%d res=%d pipe=%d expm=%d bal=%d\n\n",
            S[S_SPEED],S[S_FASTPV],S[S_RES],S[S_PIPE],S[S_EXPM],S[S_BAL]);
    for(int i=0;i<NT;i++) fprintf(f,"%02d | %-5s | %s | %s\n",i+1,res_name(g_res[i]),T[i].name,g_det[i]);
    fclose(f);
}

/* ---------- one test ---------- */
typedef struct { u32 frames, stale, tmo0; u64 t_first, grab_us, proc_us, pres_us; uint32_t last_fp; int have_fp; char extra[80], note[40]; } Stats;

static void stats_line(const Stats* s,char* out,int n){
    char a[16],b[16],c[16]; u64 fr=s->frames?s->frames:1;
    u64 el=us_now()-s->t_first; unsigned fps10=(s->frames>1&&el>0)?(unsigned)((s->frames-1)*10000000ULL/el):0;
    fmt1(a,sizeof a,s->grab_us/fr); fmt1(b,sizeof b,s->proc_us/fr); fmt1(c,sizeof c,s->pres_us/fr);
    snprintf(out,n,"fps=%u.%u grab=%sms proc=%sms pres=%sms frames=%u stale=%u tmo=%u",
             fps10/10,fps10%10,a,b,c,(unsigned)s->frames,(unsigned)s->stale,(unsigned)(g_cam_timeouts-s->tmo0));
}

static void draw_bottom(int idx,const Stats* st){
    const Test* t=&T[idx]; char b[64];
    cv_clear(&g_bot,C_BG);
    snprintf(b,sizeof b,"TEST %02d/%02d   [%s]",idx+1,NT,res_name(g_res[idx])); cv_text(&g_bot,4,4,b,C_ACC);
    cv_text(&g_bot,4,16,t->name,C_FG);
    wrap_text(&g_bot,4,30,t->look,38,5,C_FG);
    /* live numbers */
    char a[16],c[16],p[16]; u64 fr=st->frames?st->frames:1; u64 el=us_now()-st->t_first;
    unsigned fps10=(st->frames>1&&el>0)?(unsigned)((st->frames-1)*10000000ULL/el):0;
    fmt1(a,sizeof a,st->grab_us/fr); fmt1(c,sizeof c,st->proc_us/fr); fmt1(p,sizeof p,st->pres_us/fr);
    snprintf(b,sizeof b,"fps %u.%u  grab %sms",fps10/10,fps10%10,a); cv_text(&g_bot,4,88,b,C_ACC);
    snprintf(b,sizeof b,"proc %sms  present %sms",c,p);              cv_text(&g_bot,4,98,b,C_ACC);
    snprintf(b,sizeof b,"frames %u stale %u timeouts %u",(unsigned)st->frames,(unsigned)st->stale,(unsigned)(g_cam_timeouts-st->tmo0)); cv_text(&g_bot,4,108,b,C_ACC);
    if(st->extra[0]) wrap_text(&g_bot,4,120,st->extra,38,2,C_FG);
    cv_text(&g_bot,4,148,"A:OK  X:ISSUE  B:BACK  START:END",C_DIM);
    button(  6,166,70,64,"BACK", C_DIM, C_ACC);
    button( 86,166,70,64,"ISSUE",rgb16(110,24,16),C_WARN);
    button(166,166,70,64,"OK",   C_DIM, C_ACC);
    button(246,166,70,64,"END",  C_DIM, C_ACC);
}
static int touch_action(const touchPosition* tp){
    if(tp->py<166||tp->py>230) return -1;
    if(tp->px>=6  &&tp->px<76 ) return A_BACK;
    if(tp->px>=86 &&tp->px<156) return A_ISSUE;
    if(tp->px>=166&&tp->px<236) return A_OK;
    if(tp->px>=246&&tp->px<316) return A_END;
    return -1;
}

/* Process the grabbed frame for this test and draw the picture on the top screen. */
static void run_stage(const Test* t,Stats* st,int frame){
    int w=g_cam.w,h=g_cam.h; Look lk; memset(&lk,0,sizeof lk); lk.pix=1;
    static Stab stab; static Hist hist;
    switch(t->show){
    case SH_DIRECT:
        if(t->fmt==0&&w==320&&h==240) cv_blit565(&g_top,40,0,(const uint16_t*)g_cam.buf[0],w,h);
        else { to_rgb(g_cam.buf[0],w,h,t,rgbA); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); }
        break;
    case SH_RGB:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_LOOK0:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); look_apply(rgbA,w,h,&lk); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_LOOKAPP:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); look_from_settings(&lk,(uint32_t)frame); look_apply(rgbA,w,h,&lk); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_ZEB:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); ov_zebra(rgbA,w,h,230,(frame/3)*4); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_PEAK:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); ov_peaking(rgbA,w,h,1); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_HIST:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); hist_calc(rgbA,w,h,&hist); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h);
        ui_draw_hist(&g_top,44,196,72,40,&hist,1); break;
    case SH_CLIP:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); hist_calc(rgbA,w,h,&hist); ov_clip(rgbA,w,h,frame/3); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_STAB: { int ox=0,oy=0; if(frame==0) stab.have=0;
        to_rgb(g_cam.buf[0],w,h,t,rgbA); stab_update(&stab,rgbA,w,h,2,&ox,&oy); translate_clamp(rgbA,w,h,ox,oy);
        cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); } break;
    case SH_HALF:
        rgb565_to_rgb_half((const uint16_t*)g_cam.buf[0],w,h,rgbA); look_from_settings(&lk,(uint32_t)frame);
        look_apply(rgbA,w/2,h/2,&lk); cv_blit_fit(&g_top,40,0,320,240,rgbA,w/2,h/2); break;
    case SH_ANA:
        rgb565_to_rgb((const uint16_t*)g_cam.buf[0],rgbA,w*h); rgb565_to_rgb((const uint16_t*)g_cam.buf[1],rgbB,w*h);
        anaglyph(rgbA,rgbB,disp,w,h,0,0); cv_blit_fit(&g_top,40,0,320,240,disp,w,h); break;
    default: break;
    }
    (void)st;
}
/* Tests that do not use the camera. */
static void run_nocam(const Test* t,Stats* st,int frame){
    char b[64]; (void)b;
    if(t->show==SH_PRESENT){
        int x=(frame*6)%400; cv_rect(&g_top,x,0,24,240,C_ACC); cv_rect(&g_top,(x+200)%376,100,24,40,C_WARN);
    } else if(t->show==SH_JPG){
        if(frame==0){ for(int y=0;y<240;y++) for(int x=0;x<320;x++){ uint8_t* p=rgbA+((size_t)y*320+x)*3; p[0]=(uint8_t)x; p[1]=(uint8_t)y; p[2]=(uint8_t)((x^y)&255); }
            u64 t0=us_now(); int ok=enc_jpg("/3ds/procam/diag_test.jpg",rgbA,320,240,75); u64 t1=us_now(); char m[16]; fmt1(m,sizeof m,t1-t0);
            snprintf(st->note,sizeof st->note,"file write %s: %sms",ok?"ok":"FAILED",m); }
        uint8_t* j=NULL; u64 t0=us_now(); size_t n=enc_jpg_mem(rgbA,320,240,75,&j); u64 t1=us_now(); free(j);
        char m[16]; fmt1(m,sizeof m,t1-t0);
        snprintf(st->extra,sizeof st->extra,"%s | mem enc %sms %uB",st->note,m,(unsigned)n);
        cv_blit_fit(&g_top,40,0,320,240,rgbA,320,240);
    } else if(t->show==SH_MOTION){
        accelVector ac; angularRate gy; hidAccelRead(&ac); hidGyroRead(&gy);
        snprintf(b,sizeof b,"acc %d %d %d",ac.x,ac.y,ac.z); cv_text(&g_top,100,100,b,C_FG);
        snprintf(b,sizeof b,"gyro %d %d %d",gy.x,gy.y,gy.z); cv_text(&g_top,100,116,b,C_FG);
        snprintf(st->extra,sizeof st->extra,"acc %d %d %d  %s",ac.x,ac.y,ac.z,b);
    }
}

static void test_cleanup(void){ cam_stop(); g_cam_inval=1; g_cam_skip_params=0; }

/* Run test idx until the user answers. Returns an A_* action. */
static int run_test(int idx){
    const Test* t=&T[idx]; Stats st; memset(&st,0,sizeof st); st.tmo0=g_cam_timeouts;
    int frame=0, action=-1;
    if(t->src>=0){
        cv_clear(&g_top,C_BG); cv_text(&g_top,128,116,"Starting camera...",C_ACC); gfx_present();
        g_cam_inval=t->inval; g_cam_skip_params=(t->params!=PR_APP);
        if(!cam_start(t->src,t->size,t->fmt,t->fps)) snprintf(st.extra,sizeof st.extra,"cam_start FAILED");
        u32 sel=cam_select();
        switch(t->params){
        case PR_SHARP:    CAMU_SetSharpness(sel,1); break;
        case PR_NOISE:    CAMU_SetNoiseFilter(sel,true); break;
        case PR_LENS:     CAMU_SetLensCorrection(sel,(CAMU_LensCorrection)1); break;
        case PR_CONTRAST: CAMU_SetContrast(sel,(CAMU_Contrast)(S[S_CONTR]-1)); break;
        default: break;
        }
    }
    st.t_first=us_now();
    while(aptMainLoop()&&action<0){
        hidScanInput(); u32 down=hidKeysDown(); touchPosition tp; hidTouchRead(&tp);
        if(down&KEY_A) action=A_OK; else if(down&KEY_X) action=A_ISSUE; else if(down&KEY_B) action=A_BACK; else if(down&KEY_START) action=A_END;
        else if(down&KEY_TOUCH){ int a=touch_action(&tp); if(a>=0) action=a; }
        if(action>=0) break;

        cv_clear(&g_top,C_BG);
        if(t->src>=0){
            u64 g0=us_now(); int ok=cam_grab(500); u64 g1=us_now();
            if(ok){
                if(st.frames==0) st.t_first=us_now();
                uint32_t fp=fingerprint(g_cam.buf[0],g_cam.w,g_cam.h);
                if(st.have_fp&&fp==st.last_fp) st.stale++; st.last_fp=fp; st.have_fp=1;
                st.grab_us+=g1-g0; u64 p0=us_now(); run_stage(t,&st,frame); st.proc_us+=us_now()-p0; st.frames++;
            } else cv_text(&g_top,120,116,"Waiting for camera...",C_FG);
        } else {
            if(st.frames==0) st.t_first=us_now();
            u64 p0=us_now(); run_nocam(t,&st,frame); st.proc_us+=us_now()-p0; st.frames++;
        }
        frame++;
        draw_bottom(idx,&st);
        u64 q0=us_now(); gfx_present(); st.pres_us+=us_now()-q0;
    }
    stats_line(&st,g_det[idx],sizeof g_det[idx]);
    if(st.extra[0]){ size_t n=strlen(g_det[idx]); snprintf(g_det[idx]+n,sizeof g_det[idx]-n," | %s",st.extra); }
    test_cleanup();
    return action;
}

/* ---------- summary screen ---------- */
enum { END_RUN, END_RUN_NODIAG, END_RESTART };
static int summary(void){
    int issues=0, done=0; for(int i=0;i<NT;i++){ if(g_res[i]==R_ISSUE) issues++; if(g_res[i]!=R_NONE) done++; }
    write_report();
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(); touchPosition tp; hidTouchRead(&tp);
        int act=-1;
        if(down&(KEY_A|KEY_START)) act=END_RUN; else if(down&KEY_B) act=END_RESTART;
        else if((down&KEY_TOUCH)&&tp.py>=190&&tp.py<=232){
            if(tp.px<106) act=END_RUN; else if(tp.px<212) act=END_RUN_NODIAG; else act=END_RESTART; }
        if(act>=0) return act;

        char b[64]; cv_clear(&g_top,C_BG);
        cv_text(&g_top,132,70,"DIAG SUMMARY",C_ACC);
        snprintf(b,sizeof b,"%d answered, %d flagged ISSUE",done,issues); cv_text(&g_top,(400-cv_text_w(b))/2,96,b,C_FG);
        cv_text(&g_top,(400-cv_text_w("Report saved to:"))/2,128,"Report saved to:",C_FG);
        cv_text(&g_top,(400-cv_text_w(REPORT_PATH))/2,140,REPORT_PATH,C_ACC);
        cv_clear(&g_bot,C_BG); cv_text(&g_bot,4,4,"Flagged tests:",C_ACC); int y=18, shown=0;
        for(int i=0;i<NT;i++) if(g_res[i]==R_ISSUE){ if(shown>=12){ cv_text(&g_bot,4,y,"...more in the report",C_DIM); break; }
            snprintf(b,sizeof b,"%02d %s",i+1,T[i].name); cv_text(&g_bot,4,y,b,C_WARN); y+=11; shown++; }
        if(!issues) cv_text(&g_bot,4,18,"None.",C_FG);
        button(  4,190,102,42,"RUN APP",C_DIM,C_ACC);
        button(110,190,102,42,"APP+DIAG OFF",C_DIM,C_ACC);
        button(216,190,100,42,"RESTART",C_DIM,C_ACC);
        gfx_present();
    }
    return END_RUN;
}

void diag_run(void){
    rgbA=(uint8_t*)malloc(MAXPX*3); rgbB=(uint8_t*)malloc(MAXPX*3); disp=(uint8_t*)malloc(MAXPX*3);
    if(!rgbA||!rgbB||!disp){ free(rgbA); free(rgbB); free(disp); return; }   // not enough memory: skip straight to the app
    int idx=0;
    for(;;){
        memset(g_res,0,sizeof g_res); memset(g_det,0,sizeof g_det); idx=0;
        while(idx<NT&&aptMainLoop()){
            int a=run_test(idx);
            if(a==A_OK||a==A_ISSUE){ g_res[idx]=(a==A_OK)?R_OK:R_ISSUE; write_report(); idx++; }
            else if(a==A_BACK){ if(idx>0) idx--; }
            else break;                      // A_END
        }
        int e=summary();
        if(e==END_RESTART) continue;
        if(e==END_RUN_NODIAG){ S[S_DIAG]=0; settings_save(); }
        break;
    }
    free(rgbA); free(rgbB); free(disp); rgbA=rgbB=disp=NULL;
}
