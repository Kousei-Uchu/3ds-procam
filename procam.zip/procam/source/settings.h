#pragma once
// Table-driven settings: every user-facing option lives here once.
// X(id, key, label, page, type, min, max, step, labels, lofi, pro, interp)
//   interp: 1 = blends linearly with the Lo-Fi<->Pro slider, 0 = switches at 50%, -1 = never touched by slider
//   The "pro" column doubles as the factory default.
enum { P_CAM, P_CAP, P_STY, P_OVR, P_3D, P_VID, P_SYS, P_COUNT };
enum { T_BOOL, T_INT, T_ENUM, T_ACT };
enum { ACT_SAVE_LOFI = 1, ACT_SAVE_PRO, ACT_RESET, ACT_PSAVE, ACT_PLOAD, ACT_SENSOR, ACT_DIAG, ACT_LOGS };

#define SETTINGS(X) \
 X(S_SRC,   "src",   "Camera",        P_CAM, T_ENUM, 0, 2, 1, L_SRC,   0, 0, -1) \
 X(S_EXPM,  "expm",  "Exposure mode", P_CAM, T_ENUM, 0, 3, 1, L_EXPM,  0, 1, 0) \
 X(S_EV,    "ev",    "EV bias",       P_CAM, T_INT, -5, 5, 1, 0,       0, 0, -1) \
 X(S_SHUT,  "shut",  "Shutter pri.",  P_CAM, T_ENUM, 0, 4, 1, L_SHUT,  2, 2, -1) \
 X(S_WB,    "wb",    "White balance", P_CAM, T_ENUM, 0, 5, 1, L_WB,    0, 0, -1) \
 X(S_PHOTO, "photo", "Scene mode",    P_CAM, T_ENUM, 0, 4, 1, L_PHOTO, 0, 0, -1) \
 X(S_SHARP, "sharp", "Sharpness",     P_CAM, T_INT, -2, 2, 1, 0,       -1, 1, 1) \
 X(S_CONTR, "contr", "Contrast pat.", P_CAM, T_INT, 1, 11, 1, 0,       6, 6, -1) \
 X(S_NOISE, "noise", "Noise filter",  P_CAM, T_BOOL, 0, 1, 1, 0,       0, 1, 0) \
 X(S_LENS,  "lens",  "Lens correct",  P_CAM, T_ENUM, 0, 2, 1, L_LENS,  0, 1, 0) \
 X(S_FLIP,  "flip",  "Flip image",    P_CAM, T_ENUM, 0, 3, 1, L_FLIP,  0, 0, -1) \
 X(S_FPS,   "fps",   "Frame rate",    P_CAM, T_ENUM, 0, 5, 1, L_FPS,   5, 5, -1) \
 X(S_SFX,   "sfx",   "Sensor FX",     P_CAM, T_ENUM, 0, 5, 1, L_SFX,   0, 0, -1) \
 X(S_METER, "meter", "Metering",      P_CAM, T_ENUM, 0, 2, 1, L_METER, 0, 0, -1) \
 X(S_RES,   "res",   "Resolution",    P_CAP, T_ENUM, 0, 2, 1, L_RES,   1, 0, 0) \
 X(S_PIPE,  "pipe",  "Sensor pipe",   P_CAP, T_ENUM, 0, 1, 1, L_PIPE,  0, 1, 0) \
 X(S_FMT,   "fmt",   "Save as",       P_CAP, T_ENUM, 0, 4, 1, L_FMT,   0, 3, 0) \
 X(S_JPGQ,  "jpgq",  "JPG quality",   P_CAP, T_INT, 30, 100, 5, 0,     50, 95, 1) \
 X(S_STACK, "stack", "Frame stack",   P_CAP, T_ENUM, 0, 4, 1, L_STACK, 0, 2, 1) \
 X(S_LOOK,  "look",  "Save look",     P_CAP, T_ENUM, 0, 2, 1, L_LOOK,  0, 2, 0) \
 X(S_CROP,  "crop",  "Crop saved",    P_CAP, T_ENUM, 0, 3, 1, L_CROP,  0, 0, -1) \
 X(S_TIMER, "timer", "Self timer",    P_CAP, T_ENUM, 0, 3, 1, L_TIMER, 0, 0, -1) \
 X(S_BURST, "burst", "Burst shots",   P_CAP, T_INT, 1, 10, 1, 0,       1, 1, -1) \
 X(S_INTV,  "intv",  "Timelapse sec", P_CAP, T_INT, 0, 60, 1, 0,       0, 0, -1) \
 X(S_BRKT,  "brkt",  "EV bracket",    P_CAP, T_ENUM, 0, 3, 1, L_BRKT,  0, 0, -1) \
 X(S_HDR,   "hdr",   "HDR merge",     P_CAP, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_BEST,  "best",  "Best of burst", P_CAP, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_DUAL,  "dual",  "Dual exposure", P_CAP, T_ENUM, 0, 7, 1, L_DUAL,  0, 0, -1) \
 X(S_SIDE,  "side",  "Sidecar .txt",  P_CAP, T_BOOL, 0, 1, 1, 0,       0, 1, 0) \
 X(S_VOICE, "voice", "Voice shutter", P_CAP, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_VTH,   "vth",   "Voice level",   P_CAP, T_INT, 5, 90, 5, 0,       40, 40, -1) \
 X(S_STYLE, "style", "Style",         P_STY, T_ENUM, 0, 15, 1, L_STYLE, 12, 0, 0) \
 X(S_SAMT,  "samt",  "Style amount",  P_STY, T_INT, 0, 100, 10, 0,     100, 60, 1) \
 X(S_BRIGHT,"bright","Brightness",    P_STY, T_INT, -50, 50, 5, 0,     0, 0, -1) \
 X(S_CON,   "con",   "Contrast",      P_STY, T_INT, -50, 50, 5, 0,     15, 0, 1) \
 X(S_SAT,   "sat",   "Saturation",    P_STY, T_INT, -100, 100, 10, 0,  30, 0, 1) \
 X(S_TEMP,  "temp",  "Temperature",   P_STY, T_INT, -50, 50, 5, 0,     0, 0, -1) \
 X(S_TINT,  "tint",  "Tint",          P_STY, T_INT, -50, 50, 5, 0,     0, 0, -1) \
 X(S_VIGN,  "vign",  "Vignette",      P_STY, T_INT, 0, 100, 10, 0,     50, 0, 1) \
 X(S_GRAIN, "grain", "Film grain",    P_STY, T_INT, 0, 100, 10, 0,     40, 0, 1) \
 X(S_SCAN,  "scan",  "Scanlines",     P_STY, T_INT, 0, 100, 10, 0,     30, 0, 1) \
 X(S_CRUSH, "crush", "Colour crush",  P_STY, T_INT, 0, 100, 10, 0,     40, 0, 1) \
 X(S_DITH,  "dith",  "Dither",        P_STY, T_BOOL, 0, 1, 1, 0,       1, 0, 0) \
 X(S_SOFT,  "soft",  "Softness",      P_STY, T_INT, 0, 100, 10, 0,     40, 0, 1) \
 X(S_PIX,   "pix",   "Pixelate",      P_STY, T_INT, 1, 8, 1, 0,        1, 1, -1) \
 X(S_FUNKY, "funky", "Funky mode",    P_STY, T_ENUM, 0, 10, 1, L_FUNKY, 0, 0, -1) \
 X(S_FAMT,  "famt",  "Funky amount",  P_STY, T_INT, 0, 100, 10, 0,     50, 50, -1) \
 X(S_GRID,  "grid",  "Grid",          P_OVR, T_ENUM, 0, 6, 1, L_GRID,  0, 1, 0) \
 X(S_ZEB,   "zeb",   "Zebras",        P_OVR, T_ENUM, 0, 3, 1, L_ZEB,   0, 0, 0) \
 X(S_HIST,  "hist",  "Histogram",     P_OVR, T_ENUM, 0, 2, 1, L_HIST,  0, 0, 0) \
 X(S_WAVE,  "wave",  "Waveform",      P_OVR, T_ENUM, 0, 2, 1, L_WAVE,  0, 0, -1) \
 X(S_PEAK,  "peak",  "Focus peaking", P_OVR, T_ENUM, 0, 3, 1, L_PEAK,  0, 0, 0) \
 X(S_FALSE, "false", "False colour",  P_OVR, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_CLIP,  "clip",  "Clip warning",  P_OVR, T_BOOL, 0, 1, 1, 0,       0, 0, 0) \
 X(S_LEVEL, "level", "Level (gyro)",  P_OVR, T_BOOL, 0, 1, 1, 0,       0, 1, 0) \
 X(S_LINV,  "linv",  "Level invert",  P_OVR, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_BLURW, "blurw", "Blur warning",  P_OVR, T_BOOL, 0, 1, 1, 0,       0, 1, 0) \
 X(S_HUD,   "hud",   "HUD detail",    P_OVR, T_ENUM, 0, 2, 1, L_HUD,   0, 2, 0) \
 X(S_GUIDE, "guide", "Crop guide",    P_OVR, T_ENUM, 0, 3, 1, L_CROP,  0, 0, -1) \
 X(S_PERSON,"person","Person detect EXP",P_OVR,T_BOOL,0,1,1, 0,        0, 0, -1) \
 X(S_PVM,   "pvm",   "3D preview",    P_3D,  T_ENUM, 0, 4, 1, L_PVM,   1, 1, -1) \
 X(S_ANA,   "ana",   "Anaglyph type", P_3D,  T_ENUM, 0, 3, 1, L_ANA,   0, 0, -1) \
 X(S_CONV,  "conv",  "Convergence",   P_3D,  T_INT, -30, 30, 1, 0,     0, 0, -1) \
 X(S_STSAVE,"stsave","Stereo save",   P_3D,  T_ENUM, 0, 4, 1, L_STSAVE,0, 0, -1) \
 X(S_WFPS,  "wfps",  "Wiggle fps",    P_3D,  T_INT, 2, 20, 1, 0,       8, 8, -1) \
 X(S_WALIGN,"walign","Wiggle align",  P_3D,  T_BOOL, 0, 1, 1, 0,       1, 1, -1) \
 X(S_BOKEH, "bokeh", "Depth bokeh",   P_3D,  T_INT, 0, 100, 10, 0,     0, 0, -1) \
 X(S_POP,   "pop",   "Subject pop",   P_3D,  T_INT, 0, 100, 10, 0,     0, 0, -1) \
 X(S_DEPTHV,"depthv","Show depth",    P_3D,  T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_VRES,  "vres",  "Video size",    P_VID, T_ENUM, 0, 2, 1, L_VRES,  1, 1, -1) \
 X(S_VFPS,  "vfps",  "Video fps",     P_VID, T_ENUM, 0, 4, 1, L_VFPS,  2, 2, -1) \
 X(S_VQ,    "vq",    "Video quality", P_VID, T_INT, 30, 95, 5, 0,      45, 75, 1) \
 X(S_VST,   "vst",   "Stereo video",  P_VID, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_VAUD,  "vaud",  "Record audio",  P_VID, T_BOOL, 0, 1, 1, 0,       1, 1, -1) \
 X(S_STAB,  "stab",  "Stabilise",     P_VID, T_ENUM, 0, 3, 1, L_STAB,  0, 0, 0) \
 X(S_BAL,   "bal",   "Lo-Fi <> Pro",  P_SYS, T_INT, 0, 100, 5, 0,      100, 100, -1) \
 X(A_LOFI,  "",      ">> Save as Lo-Fi", P_SYS, T_ACT, ACT_SAVE_LOFI, 0, 0, 0, 0, 0, -1) \
 X(A_PRO,   "",      ">> Save as Pro",   P_SYS, T_ACT, ACT_SAVE_PRO, 0, 0, 0, 0, 0, -1) \
 X(S_PROF,  "prof",  "Profile slot",  P_SYS, T_INT, 1, 4, 1, 0,        1, 1, -1) \
 X(A_PSAVE, "",      ">> Save profile",  P_SYS, T_ACT, ACT_PSAVE, 0, 0, 0, 0, 0, -1) \
 X(A_PLOAD, "",      ">> Load profile",  P_SYS, T_ACT, ACT_PLOAD, 0, 0, 0, 0, 0, -1) \
 X(A_RESET, "",      ">> Factory reset", P_SYS, T_ACT, ACT_RESET, 0, 0, 0, 0, 0, -1) \
 X(A_SENSOR,"",      ">> Sensor registers", P_SYS, T_ACT, ACT_SENSOR, 0, 0, 0, 0, 0, -1) \
 X(A_DIAG,  "",      ">> Run diagnostics",  P_SYS, T_ACT, ACT_DIAG,   0, 0, 0, 0, 0, -1) \
 X(A_LOGS,  "",      ">> Send logs to phone", P_SYS, T_ACT, ACT_LOGS,  0, 0, 0, 0, 0, -1) \
 X(S_REGS,  "regs",  "Run reg script",P_SYS, T_BOOL, 0, 1, 1, 0,       0, 0, -1) \
 X(S_SPEED, "speed", "804MHz mode",   P_SYS, T_BOOL, 0, 1, 1, 0,       1, 1, -1) \
 X(S_FASTPV,"fastpv","Fast preview",  P_SYS, T_BOOL, 0, 1, 1, 0,       1, 1, -1) \
 X(S_DIAG,  "diag2", "Launch diag",   P_SYS, T_BOOL, 0, 1, 1, 0,       1, 1, -1) \
 X(S_YORD,  "yord",  "YUV byte order",P_SYS, T_ENUM, 0, 1, 1, L_YORD,  0, 0, -1) \
 X(S_YRNG,  "yrng",  "YUV range",     P_SYS, T_ENUM, 0, 1, 1, L_YRNG,  0, 0, -1) \
 X(S_PORT,  "port",  "Share port",    P_SYS, T_ENUM, 0, 3, 1, L_PORT,  0, 0, -1) \
 X(S_THEME, "theme", "UI theme",      P_SYS, T_ENUM, 0, 3, 1, L_THEME, 0, 0, -1)

enum {
#define X(id,...) id,
SETTINGS(X)
#undef X
S_COUNT };

typedef struct { const char* key; const char* name; int page, type, min, max, step; const char* const* labels; int lofi, pro, interp; } SDef;
extern const SDef g_defs[S_COUNT];
extern int S[S_COUNT];
extern const char* const g_page_names[P_COUNT];

void settings_init(void);            // defaults, then load /3ds/procam/*.cfg
void settings_save(void);
void settings_balance(void);         // apply S[S_BAL] to every slider-controlled option
void settings_set_ends(int pro);     // store current values as Lo-Fi (0) or Pro (1) end
void settings_reset(void);
int  settings_profile(int slot, int save);
void setting_adjust(int id, int dir);
const char* setting_text(int id, char* buf, int n);
