#include <3ds.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "gallery.h"
#include "gfx.h"
#include "img.h"
#include "enc.h"
#include "settings.h"
#define STBI_ONLY_JPEG
#define STBI_ONLY_PNG
#define STBI_ONLY_BMP
#define STBI_ONLY_GIF
#define STB_IMAGE_IMPLEMENTATION
#include "third/stb_image.h"

#define DIRP "/DCIM/100NIN03"
#define MAXI 600
#define TW_ 78
#define TH_ 58
static char g_name[MAXI][32]; static int g_n;
static uint16_t* g_thumb[MAXI];

static int viewable(const char* n){ const char* e=strrchr(n,'.'); if(!e) return 0;
    return !strcasecmp(e,".jpg")||!strcasecmp(e,".mpo")||!strcasecmp(e,".png")||!strcasecmp(e,".bmp")||!strcasecmp(e,".gif"); }
static int cmp(const void* a,const void* b){ return strcmp((const char*)b,(const char*)a); }
static void scan(void){
    for(int i=0;i<g_n;i++){ free(g_thumb[i]); g_thumb[i]=0; } g_n=0;
    DIR* d=opendir(DIRP); if(!d) return; struct dirent* e;
    while((e=readdir(d))&&g_n<MAXI){ if(e->d_name[0]!='.'&&viewable(e->d_name)){ strncpy(g_name[g_n],e->d_name,31); g_name[g_n][31]=0; g_n++; } }
    closedir(d); qsort(g_name,g_n,32,cmp);
}
static uint8_t* slurp(const char* name,size_t* n){
    char p[96]; snprintf(p,sizeof p,DIRP"/%s",name); FILE* f=fopen(p,"rb"); if(!f) return 0;
    fseek(f,0,SEEK_END); long sz=ftell(f); fseek(f,0,SEEK_SET); if(sz<=0||sz>12*1024*1024){ fclose(f); return 0; }
    uint8_t* b=(uint8_t*)malloc((size_t)sz); if(b&&fread(b,1,(size_t)sz,f)!=(size_t)sz){ free(b); b=0; } fclose(f); *n=(size_t)sz; return b;
}
static void make_thumb(int i){
    size_t n; uint8_t* b=slurp(g_name[i],&n); g_thumb[i]=(uint16_t*)calloc(TW_*TH_,2); if(!g_thumb[i]){ free(b); return; }
    if(b){ int w,h,c; uint8_t* px=stbi_load_from_memory(b,(int)n,&w,&h,&c,3);
        if(px){ for(int y=0;y<TH_;y++) for(int x=0;x<TW_;x++){ const uint8_t* s=px+((size_t)(y*h/TH_)*w+(x*w/TW_))*3; g_thumb[i][y*TW_+x]=rgb16(s[0],s[1],s[2]); } stbi_image_free(px); } }
    free(b);
}
typedef struct { uint8_t* img[2]; uint8_t* gif; int w,h,frames,*delays,stereo; } View;
static void view_free(View* v){ if(v->img[0]) stbi_image_free(v->img[0]); if(v->img[1]) stbi_image_free(v->img[1]); if(v->gif) stbi_image_free(v->gif); free(v->delays); memset(v,0,sizeof *v); }
static int view_load(View* v,const char* name){
    view_free(v); size_t n; uint8_t* b=slurp(name,&n); if(!b) return 0; int c; const char* e=strrchr(name,'.');
    if(!strcasecmp(e,".gif")){ int z; v->gif=stbi_load_gif_from_memory(b,(int)n,&v->delays,&v->w,&v->h,&z,&c,3); v->frames=z; }
    else { v->img[0]=stbi_load_from_memory(b,(int)n,&v->w,&v->h,&c,3); v->frames=1;
        if(!strcasecmp(e,".mpo")){ size_t o=mpo_second_offset(b,n); if(o){ int w2,h2; v->img[1]=stbi_load_from_memory(b+o,(int)(n-o),&w2,&h2,&c,3); if(v->img[1]&&(w2!=v->w||h2!=v->h)){ stbi_image_free(v->img[1]); v->img[1]=0; } v->stereo=v->img[1]!=0; } } }
    free(b); return (v->img[0]||v->gif);
}
static void delete_group(int i){
    char stem[16]; snprintf(stem,sizeof stem,"%.8s",g_name[i]); DIR* d=opendir(DIRP); if(!d) return; struct dirent* e; char path[96];
    while((e=readdir(d))){ if(!strncmp(e->d_name,stem,8)){ snprintf(path,sizeof path,DIRP"/%s",e->d_name); remove(path); } } closedir(d);
}
static void draw_view(const uint8_t* rgb,int w,int h,int zoom,int px,int py){
    cv_clear(&g_top,rgb16(0,0,0)); if(!rgb) return;
    int zw=w/zoom, zh=h/zoom, x0=(w-zw)/2+px, y0=(h-zh)/2+py; if(x0<0)x0=0; if(y0<0)y0=0; if(x0+zw>w)x0=w-zw; if(y0+zh>h)y0=h-zh;
    int dw=400, dh=zh*400/zw; if(dh>240){ dh=240; dw=zw*240/zh; } int ox=(400-dw)/2, oy=(240-dh)/2;
    for(int y=0;y<dh;y++){ int sy=y0+y*zh/dh; for(int x=0;x<dw;x++){ const uint8_t* s=rgb+((size_t)sy*w+x0+x*zw/dw)*3; g_top.p[(oy+y)*400+ox+x]=rgb16(s[0],s[1],s[2]); } }
}
void gallery_run(void){
    scan(); int sel=0, mode=0, zoom=1, px=0, py=0, confirm=0, slide=0; View v; memset(&v,0,sizeof v); int loaded=-1;
    uint8_t* ana=0; u64 t_slide=osGetTime(); u64 t_anim=t_slide; int fr=0;
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(), rep=hidKeysDownRepeat(), held=hidKeysHeld(); touchPosition tp; hidTouchRead(&tp);
        if(confirm){ if(down&KEY_A){ delete_group(sel); scan(); if(sel>=g_n) sel=g_n-1; if(sel<0) sel=0; loaded=-1; } if(down&(KEY_A|KEY_B)){ confirm=0; } }
        else {
            if(down&KEY_B) break;
            if(rep&KEY_DLEFT) sel--; if(rep&KEY_DRIGHT) sel++; if(rep&KEY_DUP) sel-=4; if(rep&KEY_DDOWN) sel+=4;
            if(down&KEY_L) sel--; if(down&KEY_R) sel++;
            if(down&KEY_TOUCH){ int c=tp.px/80, r=(tp.py-14)/58; if(tp.py>=14&&r<3&&c<4){ int base=(sel/12)*12; int ni=base+r*4+c; if(ni<g_n) sel=ni; } }
            if(down&KEY_A) mode=(mode+1)%4;
            if(down&KEY_X){ zoom=zoom==1?2:1; px=py=0; }
            if(down&KEY_Y&&g_n) confirm=1;
            if(down&KEY_START) slide=!slide;
            if(zoom>1){ circlePosition cp; hidCircleRead(&cp); px+=cp.dx/24; py-=cp.dy/24; }
            if(slide&&osGetTime()-t_slide>3000){ sel++; t_slide=osGetTime(); }
            if(g_n){ if(sel<0) sel=g_n-1; if(sel>=g_n) sel=0; }
        }
        if(g_n&&loaded!=sel){ view_load(&v,g_name[sel]); loaded=sel; mode=0; fr=0; free(ana); ana=0; px=py=0; }
        if(g_n&&!g_thumb[sel]) make_thumb(sel);
        else for(int k=(sel/12)*12;k<(sel/12)*12+12&&k<g_n;k++) if(!g_thumb[k]){ make_thumb(k); break; }
        /* top screen */
        const uint8_t* show=0; u64 now=osGetTime();
        if(v.gif){ if(now-t_anim>(u64)(v.delays&&v.delays[fr]>0?v.delays[fr]:100)){ fr=(fr+1)%v.frames; t_anim=now; } show=v.gif+(size_t)fr*v.w*v.h*3; }
        else if(v.stereo){
            if(mode==0) show=v.img[0]; else if(mode==3) show=v.img[1];
            else if(mode==1){ if(!ana){ ana=(uint8_t*)malloc((size_t)v.w*v.h*3); if(ana) anaglyph(v.img[0],v.img[1],ana,v.w,v.h,S[S_ANA],S[S_CONV]*v.w/320); } show=ana?ana:v.img[0]; }
            else show=((now/(1000/(S[S_WFPS]>0?S[S_WFPS]:8)))&1)?v.img[1]:v.img[0]; }
        else show=v.img[0];
        draw_view(show,v.w,v.h,zoom,px,py);
        char b[64];
        if(g_n){ snprintf(b,sizeof b,"%d/%d %s",sel+1,g_n,g_name[sel]); cv_text_bg(&g_top,4,4,b,C_FG,rgb16(0,0,0));
            if(v.stereo){ static const char* mn[4]={"L","ANAGLYPH","WIGGLE","R"}; cv_text_bg(&g_top,4,16,mn[mode],C_ACC,rgb16(0,0,0)); }
            if(v.gif) cv_text_bg(&g_top,4,16,"GIF",C_ACC,rgb16(0,0,0)); if(slide) cv_text_bg(&g_top,340,4,"SLIDE",C_ACC,rgb16(0,0,0)); }
        else cv_text(&g_top,120,110,"No photos yet",C_FG);
        if(confirm){ cv_rect(&g_top,60,90,280,50,rgb16(30,0,0)); cv_box(&g_top,60,90,280,50,C_WARN); cv_text(&g_top,72,100,"Delete this shot + extras?",C_FG); cv_text(&g_top,72,118,"A = delete    B = cancel",C_FG); }
        /* bottom: thumbnail grid */
        cv_clear(&g_bot,C_BG); cv_text(&g_bot,2,3,"GALLERY",C_ACC);
        int base=(sel/12)*12;
        for(int k=0;k<12&&base+k<g_n;k++){ int i=base+k, cx=(k%4)*80+1, cy=14+(k/4)*58; if(g_thumb[i]) for(int y=0;y<TH_;y++) memcpy(g_bot.p+(cy+y)*320+cx,g_thumb[i]+y*TW_,TW_*2); else cv_rect(&g_bot,cx,cy,TW_,TH_,C_DIM);
            if(i==sel) cv_box(&g_bot,cx-1,cy-1,TW_+2,TH_+2,C_ACC); }
        cv_text(&g_bot,2,190,"A view mode  X zoom  Y delete",C_DIM); cv_text(&g_bot,2,202,"Start slideshow  B back",C_DIM);
        cv_text(&g_bot,2,222,"Open Share on phone for GIF/video",C_DIM);
        (void)held; gfx_present();
    }
    view_free(&v); free(ana); for(int i=0;i<g_n;i++){ free(g_thumb[i]); g_thumb[i]=0; }
}
