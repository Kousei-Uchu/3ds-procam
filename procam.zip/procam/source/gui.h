#pragma once
// Shared touch-GUI toolkit: rounded cards, pills, buttons, icons and release-to-fire touch handling.
// Used by the diagnostics, the log exporter and the main app menu so everything looks the same.
#include <3ds.h>
#include "gfx.h"

/* palette (functions because rgb16 is an inline function) */
uint16_t col_card(void); uint16_t col_edge(void); uint16_t col_dim(void); uint16_t col_txt(void);
uint16_t col_ok(void);   uint16_t col_bad(void);  uint16_t col_amb(void);

/* text helpers */
void gui_wrap(Canvas* c,int x,int y,const char* s,int cols,int maxlines,uint16_t col);   // word-wrapped text
void gui_clip(char* dst,int n,const char* src,int max);                                   // copy at most max chars

/* widgets (the button and icon helpers draw on the bottom screen) */
void gui_card(Canvas* c,int x,int y,int w,int h,uint16_t fill);
void gui_pill(Canvas* c,int x,int y,const char* s,uint16_t bg,uint16_t fg);
int  gui_pill_w(const char* s);
enum { IC_NONE, IC_BACK, IC_X, IC_CHECK, IC_END, IC_UP, IC_DOWN, IC_PLUS, IC_MINUS, IC_SHUTTER, IC_REC, IC_STOP, IC_GALLERY, IC_SHARE, IC_SEND };
void gui_icon(int id,int cx,int cy,uint16_t col);
enum { BK_NEUTRAL, BK_GREEN, BK_RED, BK_ACCENT };
void gui_button(int x,int y,int w,int h,int kind,int ic,const char* label,int pressed);
void gui_switch(Canvas* c,int x,int y,int on);                                            // 36x16 on/off switch

/* touch: a button fires when the finger is lifted while still over the same button */
typedef int (*GuiHit)(int px,int py);
typedef struct { int pressed, cur, lx, ly; } GuiTouch;
int  gui_touch(GuiTouch* t,GuiHit hit,u32 down,u32 up,u32 held,const touchPosition* tp);   // returns the id that fired, or -1
int  gui_down(const GuiTouch* t,int id);                                                    // 1 while that id is being pressed
