#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define STB_IMAGE_WRITE_IMPLEMENTATION
#define STBIW_ASSERT(x)
#include "third/stb_image_write.h"
#include "enc.h"

typedef struct { uint8_t* b; size_t n, cap; } Mem;
static void mem_put(Mem* m,const void* d,size_t n){
    if(m->n+n>m->cap){ size_t c=m->cap?m->cap*2:65536; while(c<m->n+n) c*=2; uint8_t* nb=(uint8_t*)realloc(m->b,c); if(!nb) return; m->b=nb; m->cap=c; }
    memcpy(m->b+m->n,d,n); m->n+=n;
}
static void mem_cb(void* ctx,void* d,int n){ mem_put((Mem*)ctx,d,(size_t)n); }

int enc_file(const char* path,const void* d,size_t n){ FILE* f=fopen(path,"wb"); if(!f) return 0; size_t w=fwrite(d,1,n,f); fclose(f); return w==n; }
size_t enc_jpg_mem(const uint8_t* rgb,int w,int h,int q,uint8_t** out){
    Mem m={0,0,0}; if(!stbi_write_jpg_to_func(mem_cb,&m,w,h,3,rgb,q)){ free(m.b); *out=0; return 0; } *out=m.b; return m.n;
}
int enc_jpg(const char* p,const uint8_t* rgb,int w,int h,int q){ uint8_t* b; size_t n=enc_jpg_mem(rgb,w,h,q,&b); if(!n) return 0; int ok=enc_file(p,b,n); free(b); return ok; }
int enc_png(const char* p,const uint8_t* rgb,int w,int h){ return stbi_write_png(p,w,h,3,rgb,w*3); }
int enc_bmp(const char* p,const uint8_t* rgb,int w,int h){ return stbi_write_bmp(p,w,h,3,rgb); }

/* ---------------- MPO (two JPEGs + MP Format index in APP2) ---------------- */
static void le16(uint8_t* p,uint32_t v){ p[0]=v&255; p[1]=(v>>8)&255; }
static void le32(uint8_t* p,uint32_t v){ p[0]=v&255; p[1]=(v>>8)&255; p[2]=(v>>16)&255; p[3]=(v>>24)&255; }
int enc_mpo(const char* path,const uint8_t* L,const uint8_t* R,int w,int h,int q){
    uint8_t *a=0,*b=0; size_t na=enc_jpg_mem(L,w,h,q,&a), nb=enc_jpg_mem(R,w,h,q,&b);
    if(!na||!nb||na<4){ free(a); free(b); return 0; }
    uint8_t seg[90]; memset(seg,0,sizeof seg);
    seg[0]=0xFF; seg[1]=0xE2; seg[2]=0; seg[3]=88; memcpy(seg+4,"MPF\0",4);
    uint8_t* m=seg+8;                                  /* MP header starts here (file offset 10) */
    m[0]='I'; m[1]='I'; m[2]=0x2A; m[3]=0; le32(m+4,8);
    uint8_t* ifd=m+8; le16(ifd,3);
    le16(ifd+2,0xB000); le16(ifd+4,7); le32(ifd+6,4);  memcpy(ifd+10,"0100",4);
    le16(ifd+14,0xB001); le16(ifd+16,4); le32(ifd+18,1); le32(ifd+22,2);
    le16(ifd+26,0xB002); le16(ifd+28,7); le32(ifd+30,32); le32(ifd+34,50);
    le32(ifd+38,0);                                    /* next IFD */
    uint8_t* e=m+50; size_t size1=na+90;
    le32(e,0x20020002); le32(e+4,(uint32_t)size1); le32(e+8,0);
    le32(e+16,0x00020002); le32(e+20,(uint32_t)nb); le32(e+24,(uint32_t)(size1-10));
    FILE* f=fopen(path,"wb"); if(!f){ free(a); free(b); return 0; }
    fwrite(a,1,2,f); fwrite(seg,1,90,f); fwrite(a+2,1,na-2,f); fwrite(b,1,nb,f); fclose(f);
    free(a); free(b); return 1;
}
size_t mpo_second_offset(const uint8_t* b,size_t n){
    if(n<64||b[0]!=0xFF||b[1]!=0xD8) return 0;
    size_t lim=n<8192?n:8192;
    for(size_t i=2;i+12<lim;i++) if(!memcmp(b+i,"MPF\0",4)){
        const uint8_t* m=b+i+4; if(m[0]!='I') return 0;
        uint32_t ifd=m[4]|(m[5]<<8)|(m[6]<<16)|((uint32_t)m[7]<<24); const uint8_t* t=m+ifd; int cnt=t[0]|(t[1]<<8);
        for(int k=0;k<cnt;k++){ const uint8_t* en=t+2+k*12; if((en[0]|(en[1]<<8))==0xB002){
            uint32_t off=en[8]|(en[9]<<8)|(en[10]<<16)|((uint32_t)en[11]<<24); const uint8_t* e2=m+off+16;
            uint32_t o2=e2[8]|(e2[9]<<8)|(e2[10]<<16)|((uint32_t)e2[11]<<24); size_t pos=(size_t)(m-b)+o2; return pos<n?pos:0; } }
        return 0; }
    return 0;
}

/* ---------------- GIF (median-cut palette, optional Floyd-Steinberg, LZW) ---------------- */
static uint32_t g_hist[32768]; static int g_axis; static uint8_t g_pal[256][3]; static uint8_t g_inv[32768];
static int cmp_axis(const void* a,const void* b){ int x=*(const int*)a, y=*(const int*)b;
    int sh=g_axis==0?10:(g_axis==1?5:0); return ((x>>sh)&31)-((y>>sh)&31); }
static void build_palette(const uint8_t* const* fr,int n,int w,int h){
    memset(g_hist,0,sizeof g_hist);
    for(int k=0;k<n;k++) for(int i=0;i<w*h;i+=2){ const uint8_t* p=fr[k]+i*3; g_hist[((p[0]>>3)<<10)|((p[1]>>3)<<5)|(p[2]>>3)]++; }
    static int bins[32768]; int nb=0; for(int i=0;i<32768;i++) if(g_hist[i]) bins[nb++]=i;
    struct { int s,e; } box[256]; int nbox=1; box[0].s=0; box[0].e=nb;
    while(nbox<256){
        int bi=-1; long bc=0;
        for(int i=0;i<nbox;i++){ if(box[i].e-box[i].s<2) continue; long c=0; for(int j=box[i].s;j<box[i].e;j++) c+=g_hist[bins[j]]; if(c>bc){ bc=c; bi=i; } }
        if(bi<0) break;
        int mn[3]={31,31,31}, mx[3]={0,0,0};
        for(int j=box[bi].s;j<box[bi].e;j++){ int v=bins[j], c[3]={v>>10,(v>>5)&31,v&31}; for(int k=0;k<3;k++){ if(c[k]<mn[k]) mn[k]=c[k]; if(c[k]>mx[k]) mx[k]=c[k]; } }
        g_axis=0; if(mx[1]-mn[1]>mx[g_axis]-mn[g_axis]) g_axis=1; if(mx[2]-mn[2]>mx[g_axis]-mn[g_axis]) g_axis=2;
        qsort(bins+box[bi].s,box[bi].e-box[bi].s,sizeof(int),cmp_axis);
        long half=bc/2, acc=0; int mid=box[bi].s;
        for(int j=box[bi].s;j<box[bi].e;j++){ acc+=g_hist[bins[j]]; mid=j+1; if(acc>=half) break; }
        if(mid<=box[bi].s) mid=box[bi].s+1; if(mid>=box[bi].e) mid=box[bi].e-1;
        box[nbox].s=mid; box[nbox].e=box[bi].e; box[bi].e=mid; nbox++;
    }
    memset(g_pal,0,sizeof g_pal);
    for(int i=0;i<nbox;i++){ long r=0,g=0,b=0,c=0; for(int j=box[i].s;j<box[i].e;j++){ int v=bins[j]; long cn=g_hist[v]; r+=cn*(v>>10); g+=cn*((v>>5)&31); b+=cn*(v&31); c+=cn; }
        if(c){ g_pal[i][0]=(uint8_t)(r*8/c+4); g_pal[i][1]=(uint8_t)(g*8/c+4); g_pal[i][2]=(uint8_t)(b*8/c+4); } }
    for(int v=0;v<32768;v++){ int r=((v>>10)<<3)+4, g=(((v>>5)&31)<<3)+4, b=((v&31)<<3)+4, best=0, bd=1<<30;
        for(int i=0;i<nbox;i++){ int dr=r-g_pal[i][0], dg=g-g_pal[i][1], db=b-g_pal[i][2]; int d=dr*dr*3+dg*dg*4+db*db*2; if(d<bd){ bd=d; best=i; } }
        g_inv[v]=(uint8_t)best; }
}
static void map_frame(const uint8_t* rgb,int w,int h,int dither,uint8_t* idx){
    if(!dither){ for(int i=0;i<w*h;i++){ const uint8_t* p=rgb+i*3; idx[i]=g_inv[((p[0]>>3)<<10)|((p[1]>>3)<<5)|(p[2]>>3)]; } return; }
    int* err=(int*)calloc((size_t)(w+2)*3*2,sizeof(int)); if(!err) return; int* cur=err; int* nxt=err+(w+2)*3;
    for(int y=0;y<h;y++){ memset(nxt,0,(size_t)(w+2)*3*sizeof(int));
        for(int x=0;x<w;x++){ const uint8_t* p=rgb+((size_t)y*w+x)*3; int c[3];
            for(int k=0;k<3;k++){ int v=p[k]+cur[(x+1)*3+k]/16; c[k]=v<0?0:(v>255?255:v); }
            int id=g_inv[((c[0]>>3)<<10)|((c[1]>>3)<<5)|(c[2]>>3)]; idx[(size_t)y*w+x]=(uint8_t)id;
            for(int k=0;k<3;k++){ int e=c[k]-g_pal[id][k];
                cur[(x+2)*3+k]+=e*7; nxt[x*3+k]+=e*3; nxt[(x+1)*3+k]+=e*5; nxt[(x+2)*3+k]+=e*1; } }
        int* t=cur; cur=nxt; nxt=t; }
    free(err);
}
typedef struct { Mem m; uint32_t acc; int nb; } BW;
static void bw_put(BW* b,int code,int bits){ b->acc|=(uint32_t)code<<b->nb; b->nb+=bits; while(b->nb>=8){ uint8_t c=b->acc&255; mem_put(&b->m,&c,1); b->acc>>=8; b->nb-=8; } }
#define HS 5003
static void lzw(const uint8_t* idx,int n,Mem* out){
    static int32_t hk[HS]; static uint16_t hv[HS];
    BW bw={{0,0,0},0,0}; int nbits=9, maxcode=511, free_ent=258;
    memset(hk,-1,sizeof hk);
    #define OUT(code) do{ bw_put(&bw,(code),nbits); if(free_ent>maxcode && nbits<12){ nbits++; maxcode=(1<<nbits)-1; } }while(0)
    bw_put(&bw,256,nbits);
    int ent=idx[0];
    for(int i=1;i<n;i++){ int c=idx[i]; int32_t key=(ent<<8)|c; int h=(int)(((uint32_t)key*2654435761u)>>8)%HS; int found=0;
        while(hk[h]!=-1){ if(hk[h]==key){ ent=hv[h]; found=1; break; } h=(h+1)%HS; }
        if(found) continue;
        OUT(ent);
        if(free_ent<4096){ hk[h]=key; hv[h]=(uint16_t)free_ent++; }
        else { bw_put(&bw,256,nbits); memset(hk,-1,sizeof hk); free_ent=258; nbits=9; maxcode=511; }
        ent=c; }
    OUT(ent); bw_put(&bw,257,nbits); if(bw.nb>0){ uint8_t c=bw.acc&255; mem_put(&bw.m,&c,1); }
    #undef OUT
    *out=bw.m;
}
int enc_gif(const char* path,const uint8_t* const* fr,int nf,int w,int h,int delay,int dither){
    if(nf<1) return 0; build_palette(fr,nf,w,h);
    FILE* f=fopen(path,"wb"); if(!f) return 0; uint8_t* idx=(uint8_t*)malloc((size_t)w*h); if(!idx){ fclose(f); return 0; }
    uint8_t hd[13]={'G','I','F','8','9','a',0,0,0,0,0xF7,0,0}; le16(hd+6,w); le16(hd+8,h); fwrite(hd,1,13,f); fwrite(g_pal,1,768,f);
    static const uint8_t ns[19]={0x21,0xFF,0x0B,'N','E','T','S','C','A','P','E','2','.','0',3,1,0,0,0}; fwrite(ns,1,19,f);
    for(int k=0;k<nf;k++){
        map_frame(fr[k],w,h,dither,idx);
        uint8_t gc[8]={0x21,0xF9,4,0,0,0,0,0}; le16(gc+4,delay); fwrite(gc,1,8,f);
        uint8_t id[11]={0x2C,0,0,0,0,0,0,0,0,0,8}; le16(id+5,w); le16(id+7,h); fwrite(id,1,11,f);
        Mem m; lzw(idx,w*h,&m);
        for(size_t o=0;o<m.n;){ size_t c=m.n-o>255?255:m.n-o; uint8_t l=(uint8_t)c; fwrite(&l,1,1,f); fwrite(m.b+o,1,c,f); o+=c; }
        uint8_t z=0; fwrite(&z,1,1,f); free(m.b); }
    uint8_t t=0x3B; fwrite(&t,1,1,f); fclose(f); free(idx); return 1;
}

/* ---------------- AVI (MJPG video + PCM16 mono audio) ---------------- */
struct Avi { FILE* f; int w,h,audio,rate; uint32_t nv, nsamp, maxchunk; long riff, movi_list, movi4, o_us, o_frames, o_vrate, o_vlen, o_alen; uint32_t* idx; uint32_t ni, ncap; };
static void w32(FILE* f,uint32_t v){ uint8_t b[4]; le32(b,v); fwrite(b,1,4,f); }
static void w16(FILE* f,uint32_t v){ uint8_t b[2]; le16(b,v); fwrite(b,1,2,f); }
static void patch32(FILE* f,long pos,uint32_t v){ long cur=ftell(f); fseek(f,pos,SEEK_SET); w32(f,v); fseek(f,cur,SEEK_SET); }
static long list_begin(FILE* f,const char* t){ fwrite("LIST",1,4,f); long p=ftell(f); w32(f,0); fwrite(t,1,4,f); return p; }
static void list_end(FILE* f,long p){ patch32(f,p,(uint32_t)(ftell(f)-p-4)); }
Avi* avi_open(const char* path,int w,int h,int audio,int rate){
    Avi* a=(Avi*)calloc(1,sizeof *a); if(!a) return 0; a->f=fopen(path,"wb"); if(!a->f){ free(a); return 0; }
    a->w=w; a->h=h; a->audio=audio; a->rate=rate; FILE* f=a->f;
    fwrite("RIFF",1,4,f); a->riff=ftell(f); w32(f,0); fwrite("AVI ",1,4,f);
    long hdrl=list_begin(f,"hdrl");
    fwrite("avih",1,4,f); w32(f,56); a->o_us=ftell(f); w32(f,66666); w32(f,0); w32(f,0); w32(f,0x10); a->o_frames=ftell(f); w32(f,0); w32(f,0); w32(f,audio?2:1); w32(f,w*h); w32(f,w); w32(f,h); for(int i=0;i<4;i++) w32(f,0);
    long s1=list_begin(f,"strl");
    fwrite("strh",1,4,f); w32(f,56); fwrite("vidsMJPG",1,8,f); w32(f,0); w16(f,0); w16(f,0); w32(f,0); w32(f,1000); a->o_vrate=ftell(f); w32(f,15000); w32(f,0); a->o_vlen=ftell(f); w32(f,0); w32(f,w*h); w32(f,0xFFFFFFFF); w32(f,0); w16(f,0); w16(f,0); w16(f,w); w16(f,h);
    fwrite("strf",1,4,f); w32(f,40); w32(f,40); w32(f,w); w32(f,h); w16(f,1); w16(f,24); fwrite("MJPG",1,4,f); w32(f,w*h*3); w32(f,0); w32(f,0); w32(f,0); w32(f,0);
    list_end(f,s1);
    if(audio){ long s2=list_begin(f,"strl");
        fwrite("strh",1,4,f); w32(f,56); fwrite("auds",1,4,f); w32(f,0); w32(f,0); w16(f,0); w16(f,0); w32(f,0); w32(f,1); w32(f,rate); w32(f,0); a->o_alen=ftell(f); w32(f,0); w32(f,rate); w32(f,0xFFFFFFFF); w32(f,2); w16(f,0); w16(f,0); w16(f,0); w16(f,0);
        fwrite("strf",1,4,f); w32(f,16); w16(f,1); w16(f,1); w32(f,rate); w32(f,rate*2); w16(f,2); w16(f,16);
        list_end(f,s2); }
    list_end(f,hdrl);
    a->movi_list=list_begin(f,"movi"); a->movi4=a->movi_list+4;
    return a;
}
static int avi_chunk(Avi* a,const char* id,const void* d,size_t n,int key){
    FILE* f=a->f; long pos=ftell(f);
    if(a->ni+4>a->ncap){ a->ncap=a->ncap?a->ncap*2:4096; uint32_t* t=(uint32_t*)realloc(a->idx,a->ncap*4); if(!t) return 0; a->idx=t; }
    uint32_t cc; memcpy(&cc,id,4); uint32_t* e=a->idx+a->ni; e[0]=cc; e[1]=key?0x10:0; e[2]=(uint32_t)(pos-a->movi4); e[3]=(uint32_t)n; a->ni+=4;
    fwrite(id,1,4,f); w32(f,(uint32_t)n); fwrite(d,1,n,f); if(n&1){ uint8_t z=0; fwrite(&z,1,1,f); }
    if(n>a->maxchunk) a->maxchunk=(uint32_t)n; return 1;
}
int avi_video(Avi* a,const uint8_t* j,size_t n){ a->nv++; return avi_chunk(a,"00dc",j,n,1); }
int avi_audio(Avi* a,const int16_t* p,int s){ if(!a->audio||s<=0) return 1; a->nsamp+=s; return avi_chunk(a,"01wb",p,(size_t)s*2,1); }
int avi_close(Avi* a,double fps){
    FILE* f=a->f; list_end(f,a->movi_list);
    fwrite("idx1",1,4,f); w32(f,a->ni*4); for(uint32_t i=0;i<a->ni;i++) w32(f,a->idx[i]);
    patch32(f,a->riff,(uint32_t)(ftell(f)-a->riff-4));
    if(fps<0.5) fps=0.5;
    patch32(f,a->o_us,(uint32_t)(1000000.0/fps)); patch32(f,a->o_frames,a->nv);
    patch32(f,a->o_vrate,(uint32_t)(fps*1000.0)); patch32(f,a->o_vlen,a->nv);
    if(a->audio) patch32(f,a->o_alen,a->nsamp);
    fclose(f); free(a->idx); free(a); return 1;
}
