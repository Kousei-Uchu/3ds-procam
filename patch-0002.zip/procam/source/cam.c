#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cam.h"
#include "settings.h"

Cam g_cam;
int g_cam_inval=1, g_cam_skip_params=0, g_cam_threaded=1; u32 g_cam_frames, g_cam_timeouts; u64 g_cam_frame_us; int g_cam_param_mask=CAM_M_ALL;
int g_cam_fx_force=-1, g_cam_fx_late=0;     // diagnostics only: force an effect value (-1 = use the setting) / send it in the old, broken order
const int g_size_w[3]={640,320,160}, g_size_h[3]={480,240,120};
static const CAMU_Size k_sizes[3]={SIZE_VGA,SIZE_QVGA,SIZE_QQVGA};
/* index matches the Frame rate setting: 0 auto 30-5, 1 fixed 20, 2 fixed 15, 3 fixed 10, 4 fixed 5, 5 fixed 30 */
static const CAMU_FrameRate k_fps[6]={FRAME_RATE_30_TO_5,FRAME_RATE_20,FRAME_RATE_15,FRAME_RATE_10,FRAME_RATE_5,FRAME_RATE_30};
static const CAMU_FrameRate k_shut[5]={FRAME_RATE_5,FRAME_RATE_10,FRAME_RATE_15,FRAME_RATE_20,FRAME_RATE_30};

/*
 * Camera DMA buffers.
 *  - They live in linear (physically contiguous) memory, which is what the camera DMA expects.
 *  - The CPU data cache is invalidated after every frame, otherwise the CPU can keep reading the stale
 *    cached copy of an old frame while the DMA writes new ones straight to RAM.
 *  - There are three buffers per eye. In threaded mode a dedicated camera thread re-arms the camera the
 *    instant a frame lands (so slow processing in the main thread can never starve the camera) and the
 *    main thread always picks up the newest finished frame. In direct mode (used only for comparison in
 *    the diagnostics) buffers 0 and 1 are used as a ping-pong pair from the main thread.
 *  - Queueing two receives at once does NOT work on hardware: the second one completes immediately with
 *    stale data, so exactly one receive is kept in flight.
 */
#define NBUF 3                  // one receive in flight + one ready + one being read
static uint8_t* dma[2][NBUF];   // [eye][buffer], allocated in cam_start at the real frame size
static u32      s_bufsz;
static int      cur;            // direct mode: buffer that is currently armed for the next frame
static Handle   pend[2];        // direct mode: completion event of the armed receive, per eye

/* threaded mode state, protected by s_lock */
static Thread     s_thr;
static volatile int s_quit;
static LightLock  s_lock;
static LightEvent s_evt;
static int        s_ready=-1, s_held=-1;   // newest finished buffer, and the one the main thread is reading
static u32        s_seq, s_seen;           // frame counter, and the last one the main thread took
static u64        s_ready_us;              // arrival time of the newest finished frame (microseconds)
static int        s_threaded;              // 1 while the camera thread is running

/* src: 0 outer left, 1 outer pair (stereo), 2 inner, 3 outer right.
   Checked on a real console: OUT2 / CAM2 is the physically LEFT outer camera and OUT1 / CAM1 is the RIGHT one,
   so left is mapped to CAM2 here. In stereo, eye 0 (left) is CAM2 and eye 1 (right) is CAM1. */
static u32 sel_of(void){ return g_cam.src==1?SELECT_OUT1_OUT2:(g_cam.src==2?SELECT_IN1:(g_cam.src==3?SELECT_OUT1:SELECT_OUT2)); }
u32 cam_select(void){ return sel_of(); }
static u32 port_of(void){ return g_cam.stereo?PORT_BOTH:((g_cam.src==0)?PORT_CAM2:PORT_CAM1); }
static u32 port_eye(int e){ return g_cam.stereo?(e?PORT_CAM1:PORT_CAM2):port_of(); }

/* Ask the camera service to fill dma[eye][cur] with the next frame. */
static int arm(void){
    int n=g_cam.stereo?2:1; u32 sz=(u32)(g_cam.w*g_cam.h*2);
    for(int e=0;e<n;e++){
        pend[e]=0;
        if(R_FAILED(CAMU_SetReceiving(&pend[e],dma[e][cur],port_eye(e),sz,(s16)g_cam.maxbytes))) return 0;
    }
    return 1;
}
static void drop_pending(void){ for(int e=0;e<2;e++) if(pend[e]){ svcCloseHandle(pend[e]); pend[e]=0; } }

static void bufs_free(void){ for(int e=0;e<2;e++) for(int k=0;k<NBUF;k++){ if(dma[e][k]) linearFree(dma[e][k]); dma[e][k]=0; } s_bufsz=0; }
/* (Re)allocate the DMA buffers when the frame size changes. Linear memory is physically contiguous, as the camera DMA needs. */
static int bufs_alloc(u32 sz){
    if(s_bufsz==sz&&dma[0][0]) return 1;
    bufs_free();
    for(int e=0;e<2;e++) for(int k=0;k<NBUF;k++){ dma[e][k]=(uint8_t*)linearAlloc(sz); if(!dma[e][k]){ bufs_free(); return 0; } memset(dma[e][k],0,sz); }
    s_bufsz=sz; g_cam.buf[0]=dma[0][0]; g_cam.buf[1]=dma[1][0]; return 1;
}

/* optional user script /3ds/procam/regs.txt: lines "W aaaa dddd" (I2C reg) or "M aaaa dddd" (MCU var), hex; "#" comments */
static void run_regs(u32 s){
    FILE* f=fopen("/3ds/procam/regs.txt","r"); if(!f) return; char line[80];
    while(fgets(line,sizeof line,f)){ char t; unsigned a,v; if(line[0]=='#') continue;
        if(sscanf(line," %c %x %x",&t,&a,&v)==3){ if(t=='W'||t=='w') CAMU_WriteRegisterI2c(s,(u16)a,(u16)v); else if(t=='M'||t=='m') CAMU_WriteMcuVariableI2c(s,(u16)a,(u16)v); } }
    fclose(f);
}
int cam_init(void){
    if(R_FAILED(camInit())) return 0;
    LightLock_Init(&s_lock); LightEvent_Init(&s_evt,RESET_ONESHOT);
    return 1;
}
static void thread_stop(void){
    if(!s_threaded) return;
    s_quit=1; threadJoin(s_thr,U64_MAX); threadFree(s_thr); s_thr=NULL; s_threaded=0;
}
void cam_stop(void){
    if(!g_cam.active) return;
    thread_stop();                     // the thread must be gone before the capture is torn down
    CAMU_StopCapture(PORT_BOTH); CAMU_ClearBuffer(PORT_BOTH); CAMU_Activate(SELECT_NONE); drop_pending(); g_cam.active=0;
}
void cam_exit(void){
    cam_stop(); camExit(); bufs_free();
}
/*
 * Sensor settings. Measured on hardware: sending exposure, white balance, scene mode, metering window, effect or
 * flip to a sensor that is already running drops it to about 10 fps and makes brightness and colour hunt, while
 * sending the very same settings BEFORE the camera is activated keeps a smooth 30 fps. So cam_start sends all of
 * them up front (cam_apply_params), and a change to any of them must restart the camera. The sensor effect is the
 * exception: see cam_start. Only sharpness, contrast,
 * noise filter and lens correction were fine on a running sensor (cam_apply_live).
 * g_cam_param_mask lets the diagnostics send just some groups.
 */
void cam_apply_params(void){
    if(!g_cam.active) return; u32 s=sel_of(); int k=g_cam_param_mask;
    if(k&CAM_M_AE){ int m=S[S_EXPM]; CAMU_SetAutoExposure(s, m!=2); CAMU_SetExposure(s, (s8)((m==1||m==3)?S[S_EV]:0)); }
    if(k&CAM_M_WB){ CAMU_SetWhiteBalance(s,(CAMU_WhiteBalance)S[S_WB]); CAMU_SetAutoWhiteBalance(s,S[S_WB]==0); }
    if(k&CAM_M_PHOTO) CAMU_SetPhotoMode(s,(CAMU_PhotoMode)S[S_PHOTO]);
    if(k&CAM_M_SHARP) CAMU_SetSharpness(s,(s8)S[S_SHARP]);
    if(k&CAM_M_CONTR) CAMU_SetContrast(s,(CAMU_Contrast)(S[S_CONTR]-1));
    if(k&CAM_M_NOISE) CAMU_SetNoiseFilter(s,S[S_NOISE]!=0);
    if(k&CAM_M_LENS)  CAMU_SetLensCorrection(s,(CAMU_LensCorrection)S[S_LENS]);
    if(k&CAM_M_FLIP)  CAMU_FlipImage(s,(CAMU_Flip)S[S_FLIP],CONTEXT_A);
    if(k&CAM_M_METER) switch(S[S_METER]){
        case 1: CAMU_SetAutoExposureWindow(s,160,120,320,240); CAMU_SetAutoWhiteBalanceWindow(s,160,120,320,240); break;
        case 2: CAMU_SetAutoExposureWindow(s,280,210,80,60);   CAMU_SetAutoWhiteBalanceWindow(s,280,210,80,60);   break;
        default: CAMU_SetAutoExposureWindow(s,0,0,640,480);    CAMU_SetAutoWhiteBalanceWindow(s,0,0,640,480); break;
    }
}
/* The settings that are safe to change while the camera is running. */
void cam_apply_live(void){
    if(!g_cam.active) return; u32 s=sel_of();
    CAMU_SetSharpness(s,(s8)S[S_SHARP]);
    CAMU_SetContrast(s,(CAMU_Contrast)(S[S_CONTR]-1));
    CAMU_SetNoiseFilter(s,S[S_NOISE]!=0);
    CAMU_SetLensCorrection(s,(CAMU_LensCorrection)S[S_LENS]);
}
void cam_set_ev(int ev){ if(!g_cam.active) return; u32 s=sel_of(); CAMU_SetAutoExposure(s,true); CAMU_SetExposure(s,(s8)(ev<-5?-5:(ev>5?5:ev))); }


/*
 * Camera thread. Loop: queue a receive into the next free buffer, wait for the frame, flush the cache,
 * publish it as "ready" together with its arrival time, and immediately queue the next receive. Because this
 * is all the thread does, the gap between two receives is tiny no matter how long the main thread spends
 * processing a frame. The main thread always takes the newest finished frame.
 */
typedef struct { Handle ev[2]; } Req;

static int req_arm(Req* r,int buf){
    int n=g_cam.stereo?2:1; u32 sz=(u32)(g_cam.w*g_cam.h*2); r->ev[0]=r->ev[1]=0;
    for(int e=0;e<n;e++) if(R_FAILED(CAMU_SetReceiving(&r->ev[e],dma[e][buf],port_eye(e),sz,(s16)g_cam.maxbytes))){
        for(int k=0;k<e;k++) if(r->ev[k]){ svcCloseHandle(r->ev[k]); r->ev[k]=0; } return 0; }
    return 1;
}
static void req_close(Req* r){ for(int e=0;e<2;e++) if(r->ev[e]){ svcCloseHandle(r->ev[e]); r->ev[e]=0; } }
static void restart_capture(void){ u32 p=port_of(); g_cam_timeouts++; CAMU_StopCapture(p); CAMU_ClearBuffer(p); CAMU_StartCapture(p); }

static void cam_thread(void* arg){
    (void)arg; int wr=0;
    while(!s_quit){
        int n=g_cam.stereo?2:1; u32 sz=(u32)(g_cam.w*g_cam.h*2); Req r;
        if(!req_arm(&r,wr)){ svcSleepThread(5000000); if(!s_quit) restart_capture(); continue; }
        int ok=1;                                          /* wait in 100 ms slices so a stop request is noticed quickly */
        for(int e=0;e<n&&ok;e++){ int waited=0;
            for(;;){ if(R_SUCCEEDED(svcWaitSynchronization(r.ev[e],100000000LL))) break; waited+=100; if(s_quit||waited>=1000){ ok=0; break; } } }
        req_close(&r);
        if(s_quit) break;
        if(!ok){ restart_capture(); continue; }            /* no frame for a full second: restart the capture pipeline */
        if(g_cam_inval) for(int e=0;e<n;e++) GSPGPU_InvalidateDataCache(dma[e][wr],sz);
        LightLock_Lock(&s_lock);
        s_ready=wr; s_ready_us=svcGetSystemTick()/268; s_seq++; g_cam_frames++;
        for(int k=0;k<NBUF;k++) if(k!=s_ready&&k!=s_held){ wr=k; break; }       /* never write over what the main thread is reading */
        LightLock_Unlock(&s_lock);
        LightEvent_Signal(&s_evt);
    }
}
static int thread_start(void){
    s32 prio=0x30; svcGetThreadPriority(&prio,CUR_THREAD_HANDLE);
    s_quit=0; s_ready=s_held=-1; s_seq=s_seen=0; LightEvent_Clear(&s_evt);
    s_thr=threadCreate(cam_thread,NULL,0x8000,prio>0x19?prio-1:prio,-2,false);   // one step above the main thread
    s_threaded=(s_thr!=NULL);
    return s_threaded;
}

int cam_start(int src,int size,int fmt,int fps_enum){
    cam_stop();
    if(fps_enum<0||fps_enum>5) fps_enum=0;     // never index past the table
    g_cam.src=src; g_cam.size=size; g_cam.fmt=fmt; g_cam.fps=fps_enum; g_cam.stereo=(src==1);
    g_cam.w=g_size_w[size]; g_cam.h=g_size_h[size];
    if(!bufs_alloc((u32)(g_cam.w*g_cam.h*2))) return 0;
    u32 s=sel_of(), p=port_of();
    /* The sensor effect lives in the same context as the size and output format. Sending it AFTER them, even
       'none', turned the RGB565 picture into YUV bytes shown as RGB565 (the red to purple noise seen on hardware).
       So it is sent first, and skipped completely when it is 'none'. */
    int fx_forced=(g_cam_fx_force>=0), fx=fx_forced?g_cam_fx_force:S[S_SFX];
    int send_fx=fx_forced||(!g_cam_skip_params&&(g_cam_param_mask&CAM_M_FX)&&fx!=0);
    if(send_fx&&!g_cam_fx_late) CAMU_SetEffect(s,(CAMU_Effect)fx,CONTEXT_A);
    CAMU_SetSize(s,k_sizes[size],CONTEXT_A);
    CAMU_SetOutputFormat(s,fmt?OUTPUT_YUV_422:OUTPUT_RGB_565,CONTEXT_A);
    if(send_fx&&g_cam_fx_late) CAMU_SetEffect(s,(CAMU_Effect)fx,CONTEXT_A);      // old order, kept for the diagnostics only
    CAMU_SetFrameRate(s,(S[S_EXPM]==3)?k_shut[S[S_SHUT]]:k_fps[fps_enum]);
    CAMU_SetTrimming(PORT_CAM1,false); CAMU_SetTrimming(PORT_CAM2,false);
    u32 mb=0; CAMU_GetMaxBytes(&mb,(s16)g_cam.w,(s16)g_cam.h); g_cam.maxbytes=mb;
    CAMU_SetTransferBytes(p,mb,(s16)g_cam.w,(s16)g_cam.h);
    g_cam.active=1;
    if(!g_cam_skip_params) cam_apply_params();
    CAMU_Activate(s);
    CAMU_ClearBuffer(p);
    if(g_cam.stereo) CAMU_SynchronizeVsyncTiming(SELECT_OUT1,SELECT_OUT2);
    int ok=R_SUCCEEDED(CAMU_StartCapture(p));
    cur=0; drop_pending();
    if(ok){ if(!(g_cam_threaded&&thread_start())) ok=arm(); }   // threaded if possible, otherwise queue the first receive here
    if(ok&&S[S_REGS]) run_regs(s);
    return ok;
}

/*
 * Wait for the next frame. On return g_cam.buf[eye] points at the finished frame, and the camera has
 * already been re-armed on the other buffer, so the caller can take as long as it likes with it.
 * The pointer stays valid until the next cam_grab call.
 */
int cam_grab(int to_ms){
    if(!g_cam.active) return 0;
    if(s_threaded){
        /* Take the newest finished frame; wait for the camera thread if there is none yet. */
        u64 deadline=osGetTime()+(u64)to_ms;
        for(;;){
            LightLock_Lock(&s_lock);
            if(s_seq!=s_seen&&s_ready>=0){
                s_held=s_ready; s_seen=s_seq; g_cam_frame_us=s_ready_us; for(int e=0;e<2;e++) g_cam.buf[e]=dma[e][s_held];
                LightLock_Unlock(&s_lock); return 1;
            }
            LightLock_Unlock(&s_lock);
            u64 now=osGetTime(); if(now>=deadline){ g_cam_timeouts++; return 0; }
            LightEvent_WaitTimeout(&s_evt,(s64)(deadline-now)*1000000LL);
        }
    }
    int n=g_cam.stereo?2:1, ok=1; u32 sz=(u32)(g_cam.w*g_cam.h*2);
    for(int e=0;e<n&&ok;e++){
        if(!pend[e] || R_FAILED(svcWaitSynchronization(pend[e],(s64)to_ms*1000000LL))) ok=0;
    }
    if(ok){
        for(int e=0;e<n;e++){
            if(g_cam_inval) GSPGPU_InvalidateDataCache(dma[e][cur],sz);   // drop stale cache lines of the old frame
            g_cam.buf[e]=dma[e][cur];
        }
        drop_pending(); cur^=1; arm(); g_cam_frames++; g_cam_frame_us=svcGetSystemTick()/268;
        return 1;
    }
    /* Timeout or error: restart the capture pipeline and queue a fresh receive. */
    u32 p=port_of(); drop_pending(); g_cam_timeouts++;
    CAMU_StopCapture(p); CAMU_ClearBuffer(p); CAMU_StartCapture(p); cur=0; arm();
    return 0;
}
void cam_shutter_sound(int t){ CAMU_PlayShutterSound((CAMU_ShutterSoundType)t); }
