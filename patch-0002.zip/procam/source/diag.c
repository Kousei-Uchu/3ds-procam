// PROCAM diagnostic mode.
// Runs ONE isolated test at a time (camera feed, a single sensor setting, a single software stage...),
// shows live numbers, and lets you mark the test OK or ISSUE. Results are written to
// /3ds/procam/diag_report.txt after every answer, so nothing is lost if you quit early.
//
// GuiTouch GUI on the bottom screen (buttons fire on release, like a normal touch UI):
//   OK    / A      test is fine, go to the next one
//   ISSUE / X      flag this exact test as having a problem, go to the next one
//   BACK  / B      previous test
//   END   / START  jump to the summary screen
//   progress strip tap any block to jump straight to that test
// The top screen shows the live output with FPS and processing-time gauges on the side rails.
#include <3ds.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/stat.h>
#include "diag.h"
#include "logs.h"
#include "settings.h"
#include "gfx.h"
#include "img.h"
#include "enc.h"
#include "cam.h"
#include "ui.h"
#include "gui.h"

#define REPORT_PATH "/3ds/procam/diag_report.txt"
#define MAXPX (640*480)

/* What the test does with the frame once it has been grabbed. */
enum { SH_DIRECT, SH_RGB, SH_LOOK0, SH_LOOKAPP, SH_ZEB, SH_PEAK, SH_HIST, SH_CLIP, SH_STAB,
       SH_HALF, SH_ANA, SH_PRESENT, SH_JPG, SH_MOTION, SH_SDBENCH };
/* Which single sensor setting is applied on top of the untouched hardware defaults. */
enum { PR_NONE, PR_APP, PR_SHARP, PR_NOISE, PR_LENS, PR_CONTRAST, PR_AEWB, PR_WINDOW, PR_FX,
       PR_AE, PR_EV, PR_WBENUM, PR_AWB, PR_PHOTO, PR_APPLATE };

typedef struct {
    const char* name;      // short title
    const char* look;      // what to look for, shown on the bottom screen
    int src, size, fmt, fps;   // camera setup (src -1 = no camera needed)
    int params;            // PR_*
    int inval;             // 1 = invalidate cache after each frame (normal), 0 = skip (cache experiment)
    int yord, yrng;        // YUV decode options for fmt 1
    int show;              // SH_*
    int nothr;             // 1 = grab from the main thread instead of the camera thread (comparison tests)
    int pmask;             // for PR_APP tests: which CAM_M_* groups of your settings are sent before start (0 = all)
    int fxf;               // 0 = use your Sensor FX setting, else force effect (fxf-1) and send it even if 'none'
    int fxlate;            // 1 = send the effect after size and output format (the old, broken order)
} Test;

static const Test T[] = {
 /* ---- A. camera feed on its own, nothing else running ---- */
 {"Bare feed RGB565 QVGA","Sensor at hardware defaults, straight to screen. Expect a clean, smooth, moving picture.",        0,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Bare feed, cache NOT flushed","Same as test 1 but with the cache fix switched off. Does it freeze or look garbled?",     0,1,0,0, PR_NONE,0, 0,0, SH_DIRECT},
 {"Feed + your camera settings","Applies the CAM page settings (exposure, WB, sharpness, contrast, noise, lens).",          0,1,0,0, PR_APP, 1, 0,0, SH_DIRECT},
 {"Sharpness +1 only","Only sharpness +1 on top of defaults. Is the picture crunchy or over sharpened?",                      0,1,0,0, PR_SHARP,1,0,0, SH_DIRECT},
 {"Noise filter only","Only the sensor noise filter on top of defaults.",                                                    0,1,0,0, PR_NOISE,1,0,0, SH_DIRECT},
 {"Lens correction only","Only lens correction (70) on top of defaults. Look at the corners.",                               0,1,0,0, PR_LENS, 1,0,0, SH_DIRECT},
 {"Contrast pattern only","Only the contrast pattern from settings on top of defaults.",                                     0,1,0,0, PR_CONTRAST,1,0,0, SH_DIRECT},
 {"Fixed 15 fps","Frame rate forced to 15. The fps readout should sit near 15.",                                             0,1,0,2, PR_NONE,1, 0,0, SH_DIRECT},
 {"Inner camera","Selfie camera, bare. Clean and smooth?",                                                                   2,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Stereo pair, left eye","Both outer cameras are running, only the left eye is shown. Check the numbers.",                 1,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Stereo anaglyph","Red/cyan mix of both eyes. Smooth, with a sensible fps?",                                               1,1,0,0, PR_NONE,1, 0,0, SH_ANA},
 {"VGA 640x480 RGB565","Full size sensor mode, converted and scaled to fit. Expect slower, but still moving.",               0,0,0,0, PR_NONE,1, 0,0, SH_RGB},
 {"YUV422 YUYV full range","Raw sensor pipe. Are the colours right? (checks the YUV byte order/range settings)",            0,1,1,0, PR_NONE,1, 0,0, SH_RGB},
 {"YUV422 UYVY full range","Raw sensor pipe, other byte order. Better or worse than the previous test?",                    0,1,1,0, PR_NONE,1, 1,0, SH_RGB},
 {"YUV422 YUYV limited","Raw sensor pipe, limited range.",                                                                   0,1,1,0, PR_NONE,1, 0,1, SH_RGB},
 {"YUV422 UYVY limited","Raw sensor pipe, other order, limited range.",                                                      0,1,1,0, PR_NONE,1, 1,1, SH_RGB},
 /* ---- B. software stages, one at a time, on the bare QVGA feed ---- */
 {"RGB888 convert + fit","Converts to RGB888 and scales to fit, like the app does when overlays are on, but with none enabled.",0,1,0,0, PR_NONE,1, 0,0, SH_RGB},
 {"Look: neutral","Runs the look engine with everything off. Should look identical to the previous test.",                      0,1,0,0, PR_NONE,1, 0,0, SH_LOOK0},
 {"Look: your settings","Runs the look engine with the STY page settings (grain, crush, vignette...). Compare speed.",         0,1,0,0, PR_NONE,1, 0,0, SH_LOOKAPP},
 {"Zebras","Zebra stripes over bright areas only.",                                                                          0,1,0,0, PR_NONE,1, 0,0, SH_ZEB},
 {"Focus peaking","Red edge highlight only. Is it covering the whole picture?",                                              0,1,0,0, PR_NONE,1, 0,0, SH_PEAK},
 {"Histogram","Histogram widget only.",                                                                                      0,1,0,0, PR_NONE,1, 0,0, SH_HIST},
 {"Clip warning","Blinking highlight clip warning only.",                                                                    0,1,0,0, PR_NONE,1, 0,0, SH_CLIP},
 {"Stabiliser","Image stabiliser only. Wave the console around gently.",                                                     0,1,0,0, PR_NONE,1, 0,0, SH_STAB},
 {"Half-size look (fast preview)","Look engine on a half-size picture, as Fast preview does. Compare speed with the look tests.",0,1,0,0, PR_NONE,1, 0,0, SH_HALF},
 /* ---- C. everything that is not the camera ---- */
 {"Screen present speed","No camera. A bar sweeps across the top screen. Is it smooth?",                                     -1,0,0,0, PR_NONE,1, 0,0, SH_PRESENT},
 {"JPG encode + SD write","No camera. Encodes a 320x240 test image and writes it to the SD card. Check the times.",           -1,0,0,0, PR_NONE,1, 0,0, SH_JPG},
 {"Motion sensors","No camera. Tilt and shake the console. Do the accelerometer and gyro numbers move?",                       -1,0,0,0, PR_NONE,1, 0,0, SH_MOTION},

 /* ---- D. follow-up tests, added after the first hardware report ---- */
 {"Fixed 20 fps","Frame rate forced to 20. Does the fps readout reach 20?",                                                   0,1,0,1, PR_NONE,1, 0,0, SH_DIRECT},
 {"Fixed 30 fps","Frame rate forced to 30. Does it reach 30, and is the picture too dark?",                                   0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT},
 {"Inner camera, fixed 15 fps","Selfie camera forced to 15. Compare the fps with the earlier inner camera test.",               2,1,0,2, PR_NONE,1, 0,0, SH_DIRECT},
 {"Right outer camera alone","Only the right outer camera. If this is slow, that sensor is the stereo bottleneck.",             3,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Stereo pair, fixed 15 fps","Both outer cameras forced to 15 fps. Is stereo still near 1 fps?",                              1,1,0,2, PR_NONE,1, 0,0, SH_DIRECT},
 {"Stereo anaglyph, fixed 15","Red/cyan mix with a forced 15 fps frame rate.",                                                 1,1,0,2, PR_NONE,1, 0,0, SH_ANA},
 {"Look: yours, direct grab","Same as the look test with your settings, but grabbing from the main thread. Compare fps.",       0,1,0,0, PR_NONE,1, 0,0, SH_LOOKAPP, 1},
 {"Bare feed, direct grab","Bare feed grabbed from the main thread, no camera thread. Compare with test 1.",                  0,1,0,0, PR_NONE,1, 0,0, SH_DIRECT, 1},
 {"Exposure + white balance only","Explicit auto exposure, EV 0, auto white balance, normal scene mode on top of defaults.",     0,1,0,0, PR_AEWB, 1, 0,0, SH_DIRECT},
 {"Metering window only","Only the full-frame metering window on top of defaults. Is the picture too bright or too dark?",       0,1,0,0, PR_WINDOW,1,0,0, SH_DIRECT},
 {"Flip + sensor FX only","Only flip=none and sensor effect=none being sent. The picture should not change at all.",            0,1,0,0, PR_FX,   1, 0,0, SH_DIRECT},
 {"SD card write speed","No camera. Writes four 64 KB files and times each. Slow or uneven times point at the SD card.",         -1,0,0,0, PR_NONE,1, 0,0, SH_SDBENCH},

 /* ---- E. round 2: after the frame-rate table fix and the left/right camera fix ---- */
 {"Fixed 20 fps (checked)","Frame rate forced to 20 with the corrected table. Expect about 20 fps in good light.",            0,1,0,1, PR_NONE,1, 0,0, SH_DIRECT},
 {"Fixed 30 fps","Frame rate forced to 30. Expect close to 30 fps in good light.",            0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT},
 {"Auto rate","Automatic 30-5 rate. Watch the BOUNCE and FLICK counters.",                    0,1,0,0, PR_NONE,1, 0,0, SH_DIRECT},
 {"Auto rate, direct grab","Automatic rate grabbed from the main thread, no camera thread. Does it bounce too?",                0,1,0,0, PR_NONE,1, 0,0, SH_DIRECT, 1},
 {"Left camera, fixed 15","Only the LEFT outer camera, at a fixed 15 fps. It should be the one on the left when you face the screen.",                0,1,0,2, PR_NONE,1, 0,0, SH_DIRECT},
 {"Right camera, fixed 15","Only the RIGHT outer camera, at a fixed 15 fps (same rate as the left test on purpose).",              3,1,0,2, PR_NONE,1, 0,0, SH_DIRECT},
 {"Exposure + WB, fixed 15","The test that bounced before, now at a fixed 15 fps.",                                            0,1,0,2, PR_AEWB, 1, 0,0, SH_DIRECT},
 {"Exposure + WB, auto rate","Same settings with the automatic rate. Compare BOUNCE with the previous test.",                  0,1,0,0, PR_AEWB, 1, 0,0, SH_DIRECT},
 /* ---- F. round 3: which exact camera setting costs frame rate or makes the picture hunt? All at a fixed 30 fps ---- */
 {"Left camera, fixed 30","Left outer camera alone at 30 fps, to compare with the right one at the same rate.",                0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT},
 {"Right camera, fixed 30","Right outer camera alone at 30 fps.",                                                               3,1,0,5, PR_NONE,1, 0,0, SH_DIRECT},
 {"Auto exposure on only","Only 'auto exposure on' is sent to the sensor. Does the frame rate fall below 30 or does the brightness pulse?",0,1,0,5, PR_AE,    1, 0,0, SH_DIRECT},
 {"EV 0 only","Only 'exposure compensation 0' is sent to the sensor.",                                                          0,1,0,5, PR_EV,    1, 0,0, SH_DIRECT},
 {"White balance AUTO only","Only the white balance mode AUTO is sent to the sensor.",                                           0,1,0,5, PR_WBENUM,1, 0,0, SH_DIRECT},
 {"Auto WB flag only","Only 'auto white balance on' is sent to the sensor.",                                                    0,1,0,5, PR_AWB,   1, 0,0, SH_DIRECT},
 {"Scene mode normal only","Only the normal scene mode is sent to the sensor.",                                                  0,1,0,5, PR_PHOTO, 1, 0,0, SH_DIRECT},
 {"Metering window, fixed 30","Only the full-frame metering window is sent to the sensor.",                                      0,1,0,5, PR_WINDOW,1, 0,0, SH_DIRECT},
 {"Flip + FX, fixed 30","Only flip=none and effect=none are sent to the sensor.",                                                0,1,0,5, PR_FX,    1, 0,0, SH_DIRECT},
 {"Your settings before start, 30","All CAM page settings sent BEFORE the camera is activated, as the app does. Fixed 30 fps.",   0,1,0,5, PR_APP,   1, 0,0, SH_DIRECT},
 {"Your settings after start, 30","The same settings sent AFTER the camera is running. Compare with the previous test.",         0,1,0,5, PR_APPLATE,1,0,0, SH_DIRECT},
 {"Stereo anaglyph, fixed 30","Red/cyan mix of both outer cameras at 30 fps.",                                                   1,1,0,5, PR_NONE,1, 0,0, SH_ANA},
 /* ---- G. round 4: your CAM settings sent BEFORE the camera starts (the way the app now does it), one group at a time ---- */
 {"Pre-start: exposure only","Exposure mode and EV bias, sent before the camera starts. Expect a smooth 30 fps.",              0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_AE},
 {"Pre-start: white balance","White balance, sent before the camera starts.",                                                    0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_WB},
 {"Pre-start: scene mode","Scene mode, sent before the camera starts.",                                                           0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_PHOTO},
 {"Pre-start: sharp + contrast","Sharpness and contrast pattern. Does the picture turn pixelated or change colour?",              0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_SHARP|CAM_M_CONTR},
 {"Pre-start: noise + lens","Noise filter and lens correction.",                                                                  0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_NOISE|CAM_M_LENS},
 {"Pre-start: sensor FX","Sensor effect (sepia, mono, negative...). A red to purple look would come from here.",                   0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_FX},
 {"Pre-start: flip + metering","Image flip and metering window.",                                                                 0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_FLIP|CAM_M_METER},
 {"Pre-start: everything","All your CAM settings together, the same as 'Your settings before start' last time.",                  0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_ALL},
 {"Pre-start: all but FX","Everything except the sensor effect. If the odd colours vanish, the effect was the cause.",             0,1,0,5, PR_APP,1, 0,0, SH_DIRECT, 0, CAM_M_ALL&~CAM_M_FX},
 /* ---- H. round 5: is the sensor effect command what breaks the picture, and does sending it first fix it? ---- */
 {"FX none, old order","Effect 'none' sent AFTER size and format, as before. Expect the red to purple noise.",                 0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT, 0, 0, 1, 1},
 {"FX none, sent first","Effect 'none' sent BEFORE size and format. The picture should be normal.",                               0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT, 0, 0, 1, 0},
 {"FX sepia, sent first","Sepia effect sent first. Expect a clean brown-tinted picture.",                                           0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT, 0, 0, 3, 0},
 {"FX sepia, old order","Sepia sent after the format, as before. Compare with the previous test.",                                  0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT, 0, 0, 3, 1},
 {"FX mono, sent first","Black and white effect sent first.",                                                                       0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT, 0, 0, 2, 0},
 {"FX negative, sent first","Negative effect sent first.",                                                                          0,1,0,5, PR_NONE,1, 0,0, SH_DIRECT, 0, 0, 4, 0},
 {"Your settings, app order","Everything from your CAM page exactly as the app now sends it. This is the real viewfinder setup.",     0,1,0,5, PR_APP, 1, 0,0, SH_DIRECT},
};
#define NT ((int)(sizeof T/sizeof T[0]))

/* Tests are grouped for the UI. These indexes must match the order of the table above. */
#define G_CAM_END 16      /* tests 1..16  : camera feed alone  */
#define G_SW_END  25      /* tests 17..25 : software stages    */
#define G_SYS_END 28      /* tests 26..28 : not the camera     */
#define G_ROUND2  40      /* tests 41..48 : round 2            */
#define G_ROUND3  48      /* tests 49..60 : round 3            */
#define G_ROUND4  60      /* tests 61..69 : round 4            */
#define G_ROUND5  69      /* tests 70..76 : round 5            */
static const char* group_name(int i){ return i<G_CAM_END?"CAMERA":(i<G_SW_END?"SOFTWARE":(i<G_SYS_END?"SYSTEM":(i<G_ROUND2?"FOLLOW-UP":(i<G_ROUND3?"ROUND 2":(i<G_ROUND4?"ROUND 3":(i<G_ROUND5?"ROUND 4":"ROUND 5")))))); }

enum { R_NONE, R_OK, R_ISSUE };
enum { A_OK, A_ISSUE, A_BACK, A_END, A_JUMP = 100 };      /* A_JUMP + n = go to test n */

static int  g_res[NT];             /* R_* per test */
static char g_det[NT][256];        /* numbers captured when the test was answered */
static char g_ts[NT][9];           /* HH:MM:SS when each test was answered */
static char g_sess[20], g_sess_title[24];   /* run id (file name) and readable start time */
static uint8_t *rgbA, *rgbB, *disp;

/* ---------- small helpers ---------- */
static u64 us_now(void){ return svcGetSystemTick()/268; }   /* ARM11 ticks at about 268.1 MHz */
static void fmt1(char* b,int n,u64 us){ snprintf(b,n,"%u.%u",(unsigned)(us/1000),(unsigned)((us%1000)/100)); }

static void look_from_settings(Look* l,uint32_t seed){
    l->style=S[S_STYLE]; l->amt=S[S_SAMT]; l->bright=S[S_BRIGHT]; l->con=S[S_CON]; l->sat=S[S_SAT]; l->temp=S[S_TEMP]; l->tint=S[S_TINT];
    l->vign=S[S_VIGN]; l->grain=S[S_GRAIN]; l->scan=S[S_SCAN]; l->crush=S[S_CRUSH]; l->dither=S[S_DITH]; l->soft=S[S_SOFT];
    l->pix=S[S_PIX]; l->funky=S[S_FUNKY]; l->famt=S[S_FAMT]; l->seed=seed;
}
/* Decode a raw sensor buffer (RGB565 or YUV422) into RGB888. */
static void to_rgb(const uint8_t* b,int w,int h,const Test* t,uint8_t* out){
    if(t->fmt) yuv_to_rgb(b,out,w,h,t->yord,t->yrng); else rgb565_to_rgb((const uint16_t*)b,out,w*h);
}
/* Cheap fingerprint of a frame (64 sampled pixels). Identical fingerprints on a live sensor mean stale data. */
static uint32_t fingerprint(const uint8_t* b,int w,int h){
    const uint16_t* p=(const uint16_t*)b; uint32_t n=(uint32_t)w*h, hsh=2166136261u;
    for(int k=0;k<64;k++){ hsh^=p[(k*7919u)%n]; hsh*=16777619u; }
    return hsh;
}
/* ---------- report ---------- */
static const char* res_name(int r){ return r==R_OK?"OK":(r==R_ISSUE?"ISSUE":"-"); }
/* Each diagnostic run gets its own timestamped report so earlier runs can be sent later. */
static void session_begin(void){
    mkdir("/3ds",0777); mkdir("/3ds/procam",0777); mkdir(DIAG_DIR,0777);
    time_t t=time(NULL); struct tm tmv; localtime_r(&t,&tmv);
    strftime(g_sess,sizeof g_sess,"%Y%m%d-%H%M%S",&tmv); strftime(g_sess_title,sizeof g_sess_title,"%Y-%m-%d %H:%M:%S",&tmv);
    memset(g_ts,0,sizeof g_ts);
}
static void stamp(int idx){ time_t t=time(NULL); struct tm tmv; localtime_r(&t,&tmv); strftime(g_ts[idx],sizeof g_ts[idx],"%H:%M:%S",&tmv); }
static void report_to(const char* path){
    FILE* f=fopen(path,"w"); if(!f) return;
    char fx[24]; setting_text(S_SFX,fx,sizeof fx);
    fprintf(f,"PROCAM diagnostic report\nsession: %s\nbuild: %s %s\nsettings: speed=%d fastpv=%d res=%d pipe=%d bal=%d fps=%d\n"
              "cam: expm=%d ev=%d wb=%d photo=%d sharp=%d contr=%d noise=%d lens=%d fx=%s flip=%d meter=%d\n\n",
            g_sess_title,__DATE__,__TIME__,S[S_SPEED],S[S_FASTPV],S[S_RES],S[S_PIPE],S[S_BAL],S[S_FPS],
            S[S_EXPM],S[S_EV],S[S_WB],S[S_PHOTO],S[S_SHARP],S[S_CONTR],S[S_NOISE],S[S_LENS],fx,S[S_FLIP],S[S_METER]);
    for(int i=0;i<NT;i++) if(g_res[i]!=R_NONE) fprintf(f,"%02d | %-5s | %s | %s | @%s\n",i+1,res_name(g_res[i]),T[i].name,g_det[i],g_ts[i]);
    fclose(f);
}
static void write_report(void){
    if(!g_sess[0]) session_begin();
    char p[96]; snprintf(p,sizeof p,DIAG_DIR"/%s.txt",g_sess);
    report_to(p); report_to(REPORT_PATH);          /* REPORT_PATH always holds the newest run */
}

/* ---------- live statistics for one test ---------- */
typedef struct {
    u32 frames, stale, bounce, flick, dtmin, dtmax, tmo0, f0; u64 t_first, last_t, ema_us, grab_us, proc_us, pres_us, prev_ft;
    uint32_t last_fp, fp2; int have_fp, last_stale, waiting, lu_min, lu_max, lu1, lu_d; char extra[80], note[40];
    uint8_t hist[5][192]; u64 lagsum[4]; u32 lagn[4];      /* last 5 sampled frames, and total difference to the frame 1..4 back */
} Stats;
#define LUMA_JUMP 8       /* brightness step (of 255) that counts as a visible jump */

static unsigned st_fps10(const Stats* s){ return s->ema_us?(unsigned)(10000000ULL/s->ema_us):0; }   /* smoothed, responds quickly */
/* Frames per second the camera itself delivered (not what the app managed to show). */
static unsigned st_sensor10(const Stats* s){
    u64 el=us_now()-s->t_first; return (el>500000)?(unsigned)((u64)(g_cam_frames-s->f0)*10000000ULL/el):0;
}
/* Difference at lag k+1 relative to lag 1, in percent (100 = no better match than the previous frame). */
static unsigned lag_pct(const Stats* s,int k){
    if(!s->lagn[0]||!s->lagn[k]||!s->lagsum[0]) return 100; u64 base=s->lagsum[0]/s->lagn[0]; if(!base) return 100;
    return (unsigned)((s->lagsum[k]/s->lagn[k])*100/base);
}
static void stats_line(const Stats* s,char* out,int n){
    char a[16],b[16],c[16]; u64 fr=s->frames?s->frames:1;
    u64 el=us_now()-s->t_first; unsigned fps10=(s->frames>1&&el>0)?(unsigned)((s->frames-1)*10000000ULL/el):0;
    fmt1(a,sizeof a,s->grab_us/fr); fmt1(b,sizeof b,s->proc_us/fr); fmt1(c,sizeof c,s->pres_us/fr);
    unsigned sn=st_sensor10(s);
    snprintf(out,n,"fps=%u.%u sensor=%u.%u grab=%sms proc=%sms pres=%sms frames=%u stale=%u bounce=%u flick=%u luma=%d-%d dt=%u-%ums lag=%u/%u/%u tmo=%u thr=%d",
             fps10/10,fps10%10,sn/10,sn%10,a,b,c,(unsigned)s->frames,(unsigned)s->stale,(unsigned)s->bounce,(unsigned)s->flick,s->lu_min,s->lu_max,
             s->dtmin==0xFFFFFFFFu?0u:(unsigned)s->dtmin,(unsigned)s->dtmax,lag_pct(s,1),lag_pct(s,2),lag_pct(s,3),(unsigned)(g_cam_timeouts-s->tmo0),g_cam_threaded);
}

/* Traffic-light colours for the numbers. */
static uint16_t col_fps(unsigned f10){ return f10>=240?col_ok():(f10>=120?col_amb():col_bad()); }
static uint16_t col_ms(u64 us,u64 good,u64 ok){ return us<good?col_ok():(us<ok?col_amb():col_bad()); }

/* ---------- test screen: bottom ---------- */
static int strip_pitch(void){ int p=296/NT; return p<3?3:p; }      /* one block per test, as wide as fits */
static int strip_x0(void){ return (320-strip_pitch()*NT)/2; }
static int hit_test_screen(int px,int py){
    if(py<=16&&px>=strip_x0()&&px<strip_x0()+NT*strip_pitch()) return A_JUMP+(px-strip_x0())/strip_pitch();
    if(py>=182&&py<236){
        if(px>=4  &&px<56 ) return A_BACK;
        if(px>=60 &&px<156) return A_ISSUE;
        if(px>=160&&px<256) return A_OK;
        if(px>=260&&px<316) return A_END;
    }
    return -1;
}
static void draw_bottom(int idx,const Stats* st,const GuiTouch* tc){
    const Test* t=&T[idx]; char b[48], v[24];
    cv_clear(&g_bot,C_BG);
    /* progress strip: one block per test, colour = result, outlined = current */
    int sp=strip_pitch(), sw=sp-2; if(sw<2) sw=2;
    for(int i=0;i<NT;i++){ int x=strip_x0()+i*sp;
        uint16_t c=g_res[i]==R_OK?col_ok():(g_res[i]==R_ISSUE?col_bad():col_edge());
        cv_rrect(&g_bot,x,4,sw,10,sw>3?2:1,c);
        if(i==idx){ cv_rect(&g_bot,x-1,2,sw+2,1,C_ACC); cv_rect(&g_bot,x-1,15,sw+2,1,C_ACC); } }
    /* title card */
    gui_card(&g_bot,4,19,312,22,col_card());
    gui_clip(b,sizeof b,t->name,28); cv_text(&g_bot,12,26,b,col_txt());
    int gw=gui_pill_w(group_name(idx));       /* position is already shown by the progress strip and the top-screen chip */
    gui_pill(&g_bot,312-gw-4,23,group_name(idx),C_DIM,C_FG);
    /* what-to-look-for card */
    gui_card(&g_bot,4,45,312,64,col_card());
    gui_wrap(&g_bot,12,51,t->look,37,4,col_txt());
    if(st->extra[0]){ gui_clip(b,sizeof b,st->extra,37); cv_text(&g_bot,12,97,b,C_ACC); }
    /* metric tiles */
    u64 fr=st->frames?st->frames:1; unsigned f10=st_fps10(st);
    snprintf(v,sizeof v,"%u.%u",f10/10,f10%10);
    gui_card(&g_bot,4,113,100,38,col_card());  cv_text(&g_bot,12,118,"FPS",col_dim());  cv_text_scale(&g_bot,12,130,v,col_fps(f10),2);
    { unsigned sn=st_sensor10(st); int cam=T[idx].src>=0;
      if(cam) snprintf(v,sizeof v,"%u.%u",sn/10,sn%10); else snprintf(v,sizeof v,"-");
      gui_card(&g_bot,110,113,100,38,col_card()); cv_text(&g_bot,118,118,"SENSOR fps",col_dim());
      cv_text_scale(&g_bot,118,130,v,cam?col_fps(sn):col_dim(),2); }
    fmt1(v,sizeof v,st->proc_us/fr);
    gui_card(&g_bot,216,113,100,38,col_card()); cv_text(&g_bot,224,118,"PROC ms",col_dim()); cv_text_scale(&g_bot,224,130,v,col_ms(st->proc_us/fr,25000,70000),2);
    /* status pills */
    int x=4; unsigned tmo=g_cam_timeouts-st->tmo0;
    snprintf(b,sizeof b,"STALE %u",(unsigned)st->stale);
    gui_pill(&g_bot,x,157,b,st->stale>st->frames/4+1?col_bad():(st->stale?col_amb():col_edge()),col_txt()); x+=gui_pill_w(b)+4;
    snprintf(b,sizeof b,"BOUNCE %u",(unsigned)st->bounce);
    gui_pill(&g_bot,x,157,b,st->bounce>st->frames/4+1?col_bad():(st->bounce?col_amb():col_edge()),col_txt()); x+=gui_pill_w(b)+4;
    snprintf(b,sizeof b,"FLICK %u",(unsigned)st->flick);
    gui_pill(&g_bot,x,157,b,st->flick>st->frames/6+1?col_bad():(st->flick?col_amb():col_edge()),col_txt()); x+=gui_pill_w(b)+4;
    { int cl=0; unsigned bp=100; for(int k=1;k<=3;k++){ unsigned p=lag_pct(st,k); if(p<bp){ bp=p; cl=k+1; } }   /* picture looping through a few frames? */
      if(st->frames<20||bp>=70) snprintf(b,sizeof b,"CYCLE -"); else snprintf(b,sizeof b,"CYCLE x%d",cl);
      gui_pill(&g_bot,x,157,b,(st->frames>=20&&bp<70)?col_bad():col_edge(),col_txt()); x+=gui_pill_w(b)+4; }
    if(tmo){ snprintf(b,sizeof b,"TMO %u",tmo); gui_pill(&g_bot,x,157,b,col_bad(),col_txt()); }
    /* buttons */
    gui_button(  4,182,52,54,BK_NEUTRAL,IC_BACK,"BACK", gui_down(tc,A_BACK));
    gui_button( 60,182,96,54,BK_RED,    IC_X,   "ISSUE",gui_down(tc,A_ISSUE));
    gui_button(160,182,96,54,BK_GREEN,  IC_CHECK,"OK",  gui_down(tc,A_OK));
    gui_button(260,182,56,54,BK_NEUTRAL,IC_END, "END",  gui_down(tc,A_END));
}

/* ---------- test screen: top (side rails + status chips over the picture) ---------- */
static void vbar(int x,int y,int w,int h,int pct,uint16_t col){          /* vertical gauge, fills from the bottom */
    cv_rrect(&g_top,x,y,w,h,4,col_edge()); cv_rrect(&g_top,x+1,y+1,w-2,h-2,3,col_card());
    if(pct<0) pct=0; if(pct>100) pct=100;
    int fh=(h-4)*pct/100; if(fh>0) cv_rect(&g_top,x+2,y+h-2-fh,w-4,fh,col);
}
static void draw_rails(const Stats* st){
    char v[16]; unsigned f10=st_fps10(st); u64 fr=st->frames?st->frames:1; u64 pu=st->proc_us/fr;
    cv_rect(&g_top,0,0,40,240,rgb16(13,15,20)); cv_rect(&g_top,360,0,40,240,rgb16(13,15,20));
    cv_text(&g_top,8,8,"FPS",col_dim()); snprintf(v,sizeof v,"%u.%u",f10/10,f10%10); cv_text(&g_top,4,20,v,col_fps(f10));
    vbar(13,36,14,196,(int)(f10*100/300),col_fps(f10));
    cv_text(&g_top,364,8,"PROC",col_dim()); fmt1(v,sizeof v,pu); cv_text(&g_top,364,20,v,col_ms(pu,25000,70000));
    int pct=(int)(pu*100/66000); vbar(373,36,14,196,pct,col_ms(pu,25000,70000));
}
static void draw_chips(int idx,const Stats* st,int camtest){
    char b[24]; snprintf(b,sizeof b,"TEST %02d/%02d",idx+1,NT);
    cv_rect_a(&g_top,44,4,cv_text_w(b)+10,13,0,170); cv_text(&g_top,49,7,b,col_txt());
    const char* s="LIVE"; uint16_t c=col_ok();
    if(camtest){ if(st->waiting||st->frames==0){ s="NO FRAME"; c=col_amb(); } else if(st->last_stale){ s="STALE"; c=col_bad(); } }
    else { s="RUNNING"; c=C_ACC; }
    int w=cv_text_w(s)+10; cv_rect_a(&g_top,356-w,4,w,13,0,170); cv_text(&g_top,361-w,7,s,c);
}

/* ---------- running a stage ---------- */
/* 64 sample points x R,G,B, to compare frames with each other cheaply. */
static void sample_rgb(const uint8_t* b,int w,int h,int yuv,uint8_t* out){
    int k=0;
    for(int j=0;j<8;j++) for(int i=0;i<8;i++){ int x=(2*i+1)*w/16, y=(2*j+1)*h/16;
        if(yuv){ const uint8_t* p=b+((size_t)y*w+(x&~1))*2; out[k++]=p[0]; out[k++]=p[1]; out[k++]=p[3]; }
        else { uint16_t p=((const uint16_t*)b)[(size_t)y*w+x]; out[k++]=(uint8_t)(((p>>11)&31)<<3); out[k++]=(uint8_t)(((p>>5)&63)<<2); out[k++]=(uint8_t)((p&31)<<3); } }
}
/* Average brightness (0..255) over an 8x8 grid of points. Exposure hunting shows up as this value jumping up and down. */
static int sample_luma(const uint8_t* b,int w,int h,int yuv){
    int sum=0;
    for(int j=0;j<8;j++) for(int i=0;i<8;i++){ int x=(2*i+1)*w/16, y=(2*j+1)*h/16;
        if(yuv) sum+=b[((size_t)y*w+(x&~1))*2];                                           /* YUYV: even bytes are luma */
        else { uint16_t p=((const uint16_t*)b)[(size_t)y*w+x]; sum+=((p>>5)&63)<<2; } }   /* RGB565: green channel */
    return sum/64;
}
static void run_stage(const Test* t,Stats* st,int frame){
    int w=g_cam.w,h=g_cam.h; Look lk; memset(&lk,0,sizeof lk); lk.pix=1;
    static Stab stab; static Hist hist;
    switch(t->show){
    case SH_DIRECT:
        if(t->fmt==0&&w==320&&h==240) cv_blit565(&g_top,40,0,(const uint16_t*)g_cam.buf[0],w,h);
        else { to_rgb(g_cam.buf[0],w,h,t,rgbA); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); }
        break;
    case SH_RGB:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_LOOK0:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); look_apply(rgbA,w,h,&lk); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_LOOKAPP:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); look_from_settings(&lk,(uint32_t)frame); look_apply(rgbA,w,h,&lk); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_ZEB:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); ov_zebra(rgbA,w,h,230,(frame/3)*4); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_PEAK:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); ov_peaking(rgbA,w,h,1); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_HIST:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); hist_calc(rgbA,w,h,&hist); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h);
        ui_draw_hist(&g_top,44,196,72,40,&hist,1); break;
    case SH_CLIP:
        to_rgb(g_cam.buf[0],w,h,t,rgbA); hist_calc(rgbA,w,h,&hist); ov_clip(rgbA,w,h,frame/3); cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); break;
    case SH_STAB: { int ox=0,oy=0; if(frame==0) stab.have=0;
        to_rgb(g_cam.buf[0],w,h,t,rgbA); stab_update(&stab,rgbA,w,h,2,&ox,&oy); translate_clamp(rgbA,w,h,ox,oy);
        cv_blit_fit(&g_top,40,0,320,240,rgbA,w,h); } break;
    case SH_HALF:
        rgb565_to_rgb_half((const uint16_t*)g_cam.buf[0],w,h,rgbA); look_from_settings(&lk,(uint32_t)frame);
        look_apply(rgbA,w/2,h/2,&lk); cv_blit_fit(&g_top,40,0,320,240,rgbA,w/2,h/2); break;
    case SH_ANA:
        rgb565_to_rgb((const uint16_t*)g_cam.buf[0],rgbA,w*h); rgb565_to_rgb((const uint16_t*)g_cam.buf[1],rgbB,w*h);
        anaglyph(rgbA,rgbB,disp,w,h,0,0); cv_blit_fit(&g_top,40,0,320,240,disp,w,h); break;
    default: break;
    }
    (void)st;
}
/* Tests that do not use the camera. */
static void run_nocam(const Test* t,Stats* st,int frame){
    char b[64];
    if(t->show==SH_PRESENT){
        int x=40+(frame*6)%296; cv_rect(&g_top,x,0,24,240,C_ACC); cv_rect(&g_top,40+(x+120)%296,100,24,40,col_bad());
    } else if(t->show==SH_JPG){
        if(frame==0){ for(int y=0;y<240;y++) for(int x=0;x<320;x++){ uint8_t* p=rgbA+((size_t)y*320+x)*3; p[0]=(uint8_t)x; p[1]=(uint8_t)y; p[2]=(uint8_t)((x^y)&255); }
            u64 t0=us_now(); int ok=enc_jpg("/3ds/procam/diag_test.jpg",rgbA,320,240,75); u64 t1=us_now(); char m[16]; fmt1(m,sizeof m,t1-t0);
            snprintf(st->note,sizeof st->note,"file %s %sms",ok?"ok":"FAILED",m); }
        uint8_t* j=NULL; u64 t0=us_now(); size_t n=enc_jpg_mem(rgbA,320,240,75,&j); u64 t1=us_now(); free(j);
        char m[16]; fmt1(m,sizeof m,t1-t0);
        snprintf(st->extra,sizeof st->extra,"%s | enc %sms %uB",st->note,m,(unsigned)n);
        cv_blit_fit(&g_top,40,0,320,240,rgbA,320,240);
    } else if(t->show==SH_SDBENCH){
        static unsigned ms[4]; static int done;
        if(frame==0){ done=0; }
        if(!done){
            static uint8_t blk[65536]; for(size_t i=0;i<sizeof blk;i++) blk[i]=(uint8_t)(i*31);
            for(int k=0;k<4;k++){ char path[64]; snprintf(path,sizeof path,"/3ds/procam/diag_sd_%d.bin",k);
                u64 t0=us_now(); FILE* f=fopen(path,"wb"); if(f){ fwrite(blk,1,sizeof blk,f); fclose(f); } u64 t1=us_now();
                ms[k]=(unsigned)((t1-t0)/1000); remove(path); }
            done=1;
            snprintf(st->extra,sizeof st->extra,"64KB writes: %u %u %u %u ms",ms[0],ms[1],ms[2],ms[3]);
        }
        cv_rrect(&g_top,70,60,260,120,8,col_card()); cv_text_scale(&g_top,84,72,"SD WRITE (64 KB)",col_dim(),1);
        for(int k=0;k<4;k++){ snprintf(b,sizeof b,"%u ms",ms[k]); cv_text_scale(&g_top,84,92+k*20,b,ms[k]<100?col_ok():(ms[k]<500?col_amb():col_bad()),2); }
    } else if(t->show==SH_MOTION){
        accelVector ac; angularRate gy; hidAccelRead(&ac); hidGyroRead(&gy);
        cv_rrect(&g_top,70,70,260,100,8,col_card());
        cv_text_scale(&g_top,84,82,"ACCEL",col_dim(),1); snprintf(b,sizeof b,"%d %d %d",ac.x,ac.y,ac.z); cv_text_scale(&g_top,84,96,b,col_txt(),2);
        cv_text_scale(&g_top,84,126,"GYRO",col_dim(),1); snprintf(b,sizeof b,"%d %d %d",gy.x,gy.y,gy.z); cv_text_scale(&g_top,84,140,b,col_txt(),2);
        snprintf(st->extra,sizeof st->extra,"acc %d %d %d gyro %d %d %d",ac.x,ac.y,ac.z,gy.x,gy.y,gy.z);
    }
}

static void test_cleanup(void){ cam_stop(); g_cam_inval=1; g_cam_skip_params=0; g_cam_threaded=1; g_cam_param_mask=CAM_M_ALL; g_cam_fx_force=-1; g_cam_fx_late=0; }

/* Run test idx until the user answers. Returns A_OK / A_ISSUE / A_BACK / A_END or A_JUMP + n. */
static int run_test(int idx){
    const Test* t=&T[idx]; Stats st; memset(&st,0,sizeof st); st.tmo0=g_cam_timeouts;
    int frame=0, action=-1; GuiTouch tc={-1,-1,0,0};
    if(t->src>=0){
        cv_clear(&g_top,C_BG); cv_rrect(&g_top,110,100,180,40,8,col_card());
        cv_text(&g_top,200-cv_text_w("Starting camera...")/2,116,"Starting camera...",C_ACC); gfx_present();
        g_cam_inval=t->inval; g_cam_skip_params=(t->params!=PR_APP); g_cam_threaded=!t->nothr; g_cam_param_mask=t->pmask?t->pmask:CAM_M_ALL; g_cam_fx_force=t->fxf?t->fxf-1:-1; g_cam_fx_late=t->fxlate;
        if(!cam_start(t->src,t->size,t->fmt,t->fps)) snprintf(st.extra,sizeof st.extra,"cam_start FAILED");
        if(t->params==PR_APP){ char fxn[16]; setting_text(S_SFX,fxn,sizeof fxn);
            snprintf(st.extra,sizeof st.extra,"fx=%s ct=%d sh=%d nz=%d ln=%d ev=%d",fxn,S[S_CONTR],S[S_SHARP],S[S_NOISE],S[S_LENS],S[S_EV]); }
        u32 sel=cam_select();
        switch(t->params){
        case PR_SHARP:    CAMU_SetSharpness(sel,1); break;
        case PR_NOISE:    CAMU_SetNoiseFilter(sel,true); break;
        case PR_LENS:     CAMU_SetLensCorrection(sel,(CAMU_LensCorrection)1); break;
        case PR_CONTRAST: CAMU_SetContrast(sel,(CAMU_Contrast)(S[S_CONTR]-1)); break;
        case PR_AEWB:     CAMU_SetAutoExposure(sel,true); CAMU_SetExposure(sel,0); CAMU_SetWhiteBalance(sel,(CAMU_WhiteBalance)0);
                          CAMU_SetAutoWhiteBalance(sel,true); CAMU_SetPhotoMode(sel,(CAMU_PhotoMode)0); break;
        case PR_WINDOW:   CAMU_SetAutoExposureWindow(sel,0,0,640,480); CAMU_SetAutoWhiteBalanceWindow(sel,0,0,640,480); break;
        case PR_FX:       CAMU_SetEffect(sel,(CAMU_Effect)0,CONTEXT_A); CAMU_FlipImage(sel,(CAMU_Flip)0,CONTEXT_A); break;
        case PR_AE:       CAMU_SetAutoExposure(sel,true); break;
        case PR_EV:       CAMU_SetExposure(sel,0); break;
        case PR_WBENUM:   CAMU_SetWhiteBalance(sel,(CAMU_WhiteBalance)0); break;
        case PR_AWB:      CAMU_SetAutoWhiteBalance(sel,true); break;
        case PR_PHOTO:    CAMU_SetPhotoMode(sel,(CAMU_PhotoMode)0); break;
        case PR_APPLATE:  cam_apply_params(); break;             /* the app's own settings, but sent after the camera is running */
        default: break;
        }
    }
    st.t_first=us_now(); st.waiting=1; st.f0=g_cam_frames;
    while(aptMainLoop()&&action<0){
        hidScanInput(); u32 down=hidKeysDown(), up=hidKeysUp(), held=hidKeysHeld(); touchPosition tp; hidTouchRead(&tp);
        if(down&KEY_A) action=A_OK; else if(down&KEY_X) action=A_ISSUE; else if(down&KEY_B) action=A_BACK; else if(down&KEY_START) action=A_END;
        int rel=gui_touch(&tc,hit_test_screen,down,up,held,&tp); if(rel>=0) action=rel;
        if(action>=0) break;

        cv_clear(&g_top,C_BG);
        int got=0;
        if(t->src>=0){
            u64 g0=us_now(); int ok=cam_grab(500); u64 g1=us_now();
            if(ok){
                got=1; st.waiting=0; u64 now=g1;
                if(st.frames==0) st.t_first=now;
                if(st.last_t){ u64 dt=now-st.last_t; st.ema_us=st.ema_us?(st.ema_us*7+dt)/8:dt; } st.last_t=now;
                uint32_t fp=fingerprint(g_cam.buf[0],g_cam.w,g_cam.h);
                st.last_stale=(st.have_fp&&fp==st.last_fp); if(st.last_stale) st.stale++;
                if(st.frames>=2&&fp==st.fp2&&fp!=st.last_fp) st.bounce++;      /* A B A B pattern: the picture jumps between two frames */
                st.fp2=st.last_fp; st.last_fp=fp; st.have_fp=1;
                /* brightness oscillation (exposure hunting) and frame pacing, both measured from the camera's own timestamps */
                int lu=sample_luma(g_cam.buf[0],g_cam.w,g_cam.h,t->fmt);
                if(st.frames==0){ st.lu_min=st.lu_max=lu; st.dtmin=0xFFFFFFFFu; }
                if(lu<st.lu_min) st.lu_min=lu; if(lu>st.lu_max) st.lu_max=lu;
                { int dl=lu-st.lu1; if(st.frames>=2&&abs(dl)>=LUMA_JUMP&&abs(st.lu_d)>=LUMA_JUMP&&((dl>0)!=(st.lu_d>0))) st.flick++; st.lu_d=dl; st.lu1=lu; }
                if(st.prev_ft){ u32 dt=(u32)((g_cam_frame_us-st.prev_ft)/1000); if(dt<st.dtmin) st.dtmin=dt; if(dt>st.dtmax) st.dtmax=dt; }
                st.prev_ft=g_cam_frame_us;
                { uint8_t cur[192]; sample_rgb(g_cam.buf[0],g_cam.w,g_cam.h,t->fmt,cur);
                  for(int lag=1;lag<=4;lag++) if(st.frames>=(u32)lag){ const uint8_t* o=st.hist[(st.frames-lag)%5]; u32 sum=0; for(int i=0;i<192;i++) sum+=(u32)abs((int)cur[i]-(int)o[i]); st.lagsum[lag-1]+=sum; st.lagn[lag-1]++; }
                  memcpy(st.hist[st.frames%5],cur,192); }
                st.grab_us+=g1-g0; u64 p0=us_now(); run_stage(t,&st,frame); st.proc_us+=us_now()-p0; st.frames++;
            } else st.waiting=1;
        } else {
            u64 now=us_now(); got=1; if(st.frames==0) st.t_first=now;
            if(st.last_t){ u64 dt=now-st.last_t; st.ema_us=st.ema_us?(st.ema_us*7+dt)/8:dt; } st.last_t=now;
            u64 p0=us_now(); run_nocam(t,&st,frame); st.proc_us+=us_now()-p0; st.frames++;
        }
        if(!got){ cv_rrect(&g_top,110,100,180,40,8,col_card()); cv_text(&g_top,200-cv_text_w("Waiting for camera...")/2,116,"Waiting for camera...",col_txt()); }
        frame++;
        draw_rails(&st); draw_chips(idx,&st,t->src>=0);
        draw_bottom(idx,&st,&tc);
        u64 q0=us_now(); gfx_present(); st.pres_us+=us_now()-q0;
    }
    stats_line(&st,g_det[idx],sizeof g_det[idx]);
    if(st.extra[0]){ size_t n=strlen(g_det[idx]); snprintf(g_det[idx]+n,sizeof g_det[idx]-n," | %s",st.extra); }
    test_cleanup();
    return action;
}

/* ---------- welcome screen ---------- */
enum { W_START, W_FOLLOW, W_SKIP, W_LOGS };
static int hit_welcome(int px,int py){
    if(px>=20&&px<300&&py>=14&&py<68)   return W_START;
    if(px>=20&&px<300&&py>=74&&py<122)  return W_FOLLOW;
    if(px>=20&&px<300&&py>=128&&py<172) return W_LOGS;
    if(px>=20&&px<300&&py>=178&&py<218) return W_SKIP;
    return -1;
}
static int welcome(void){
    GuiTouch tc={-1,-1,0,0};
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(), up=hidKeysUp(), held=hidKeysHeld(); touchPosition tp; hidTouchRead(&tp);
        int act=-1; if(down&KEY_A) act=W_START; else if(down&KEY_X) act=W_FOLLOW; else if(down&KEY_Y) act=W_LOGS; else if(down&KEY_START) act=W_SKIP;
        int rel=gui_touch(&tc,hit_welcome,down,up,held,&tp); if(rel>=0) act=rel;
        if(act==W_LOGS){ logs_run(); act=-1; }
        if(act==W_START) return 1; if(act==W_FOLLOW) return 2; if(act==W_SKIP) return 0;

        char b[48]; cv_clear(&g_top,C_BG);
        for(int i=0;i<8;i++) cv_rect(&g_top,0,i*2,400,1,C_DIM);
        cv_text_scale(&g_top,200-cv_text_scale_w("PROCAM",4)/2,58,"PROCAM",col_txt(),4);
        cv_text_scale(&g_top,200-cv_text_scale_w("DIAGNOSTICS",2)/2,100,"DIAGNOSTICS",C_ACC,2);
        snprintf(b,sizeof b,"%d tests, one at a time (%d in round 5)",NT,NT-G_ROUND5); cv_text(&g_top,200-cv_text_w(b)/2,140,b,col_dim());
        cv_text(&g_top,200-cv_text_w("Mark each one OK or ISSUE")/2,154,"Mark each one OK or ISSUE",col_dim());
        cv_text(&g_top,200-cv_text_w("Hold L or R at launch to open this again")/2,214,"Hold L or R at launch to open this again",col_dim());
        cv_clear(&g_bot,C_BG);
        gui_button(20,14,280,54,BK_ACCENT,IC_NONE,"ALL TESTS",gui_down(&tc,W_START));
        gui_button(20,74,280,48,BK_GREEN,IC_NONE,"ROUND 5 TESTS ONLY",gui_down(&tc,W_FOLLOW));
        gui_button(20,128,280,44,BK_NEUTRAL,IC_NONE,"SEND LOGS TO PHONE",gui_down(&tc,W_LOGS));
        gui_button(20,178,280,40,BK_NEUTRAL,IC_NONE,"SKIP TO APP",gui_down(&tc,W_SKIP));
        cv_text(&g_bot,160-cv_text_w("A all  X round 5  Y logs  START skip")/2,226,"A all  X round 5  Y logs  START skip",col_dim());
        gfx_present();
    }
    return 0;
}

/* ---------- summary screen ---------- */
enum { END_RUN, END_RUN_NODIAG, END_RESTART, END_SEND };            /* returned values; >= A_JUMP means retest test n */
#define LIST_Y0 24
#define LIST_ROW 20
#define LIST_ROWS 8
static int g_flagged[NT], g_nflag, g_scroll;
static int hit_summary(int px,int py){
    if(py>=196&&py<236){ if(px<80) return 200+END_RUN; if(px<160) return 200+END_RUN_NODIAG; if(px<240) return 200+END_SEND; return 200+END_RESTART; }
    if(px>=290&&px<318&&py>=LIST_Y0&&py<LIST_Y0+34) return 300;        /* scroll up */
    if(px>=290&&px<318&&py>=LIST_Y0+38&&py<LIST_Y0+72) return 301;     /* scroll down */
    if(px>=4&&px<286&&py>=LIST_Y0&&py<LIST_Y0+LIST_ROWS*LIST_ROW){ int r=(py-LIST_Y0)/LIST_ROW+g_scroll; if(r<g_nflag) return 400+g_flagged[r]; }
    return -1;
}
static int summary(void){
    int ok=0, issues=0; g_nflag=0; g_scroll=0;
    for(int i=0;i<NT;i++){ if(g_res[i]==R_OK) ok++; if(g_res[i]==R_ISSUE){ issues++; g_flagged[g_nflag++]=i; } }
    int untested=NT-ok-issues; write_report();
    GuiTouch tc={-1,-1,0,0};
    while(aptMainLoop()){
        hidScanInput(); u32 down=hidKeysDown(), up=hidKeysUp(), held=hidKeysHeld(); touchPosition tp; hidTouchRead(&tp);
        int act=-1;
        if(down&(KEY_A|KEY_START)) return END_RUN; if(down&KEY_B) return END_RESTART;
        if(down&KEY_DDOWN&&g_scroll<g_nflag-LIST_ROWS) g_scroll++; if(down&KEY_DUP&&g_scroll>0) g_scroll--;
        int rel=gui_touch(&tc,hit_summary,down,up,held,&tp);
        if(rel==300&&g_scroll>0) g_scroll--; else if(rel==301&&g_scroll<g_nflag-LIST_ROWS) g_scroll++;
        else if(rel>=400) act=A_JUMP+(rel-400); else if(rel>=200&&rel<300) act=rel-200;
        if(act==END_SEND){ write_report(); logs_run(); act=-1; }
        if(act>=0) return act;

        char b[48]; cv_clear(&g_top,C_BG);
        static const char* lab[3]={"OK","ISSUE","NOT RUN"}; int val[3]={ok,issues,untested};
        for(int k=0;k<3;k++){ int cx=70+k*130; uint16_t c=k==0?col_ok():(k==1?col_bad():col_dim());
            cv_rrect(&g_top,cx-52,60,104,100,10,col_edge()); cv_rrect(&g_top,cx-51,61,102,98,9,col_card());
            snprintf(b,sizeof b,"%d",val[k]); cv_text_scale(&g_top,cx-cv_text_scale_w(b,4)/2,84,b,c,4);
            cv_text(&g_top,cx-cv_text_w(lab[k])/2,134,lab[k],col_dim()); }
        cv_text(&g_top,200-cv_text_w("Saved as run")/2,184,"Saved as run",col_dim());
        cv_text(&g_top,200-cv_text_w(g_sess_title)/2,198,g_sess_title,C_ACC);
        cv_text_scale(&g_top,200-cv_text_scale_w("SUMMARY",2)/2,24,"SUMMARY",col_txt(),2);

        cv_clear(&g_bot,C_BG);
        cv_text(&g_bot,6,8,issues?"FLAGGED (tap to retest)":"NOTHING FLAGGED",issues?col_bad():col_ok());
        if(!issues){ gui_card(&g_bot,4,LIST_Y0,282,LIST_ROWS*LIST_ROW,col_card()); gui_icon(IC_CHECK,145,LIST_Y0+60,col_ok());
            cv_text(&g_bot,145-cv_text_w("All answered tests passed")/2,LIST_Y0+84,"All answered tests passed",col_dim()); }
        for(int r=0;r<LIST_ROWS&&r+g_scroll<g_nflag;r++){ int i=g_flagged[r+g_scroll]; int y=LIST_Y0+r*LIST_ROW; char nm[40];
            gui_card(&g_bot,4,y,282,LIST_ROW-2,col_card()); cv_rrect(&g_bot,10,y+5,6,8,2,col_bad());
            snprintf(b,sizeof b,"%02d",i+1); cv_text(&g_bot,22,y+5,b,col_dim());
            gui_clip(nm,sizeof nm,T[i].name,28); cv_text(&g_bot,44,y+5,nm,col_txt()); }
        if(g_nflag>LIST_ROWS){ gui_button(290,LIST_Y0,28,34,BK_NEUTRAL,IC_UP,"",gui_down(&tc,300)); gui_button(290,LIST_Y0+38,28,34,BK_NEUTRAL,IC_DOWN,"",gui_down(&tc,301)); }
        cv_text(&g_bot,160-cv_text_w("Hold L or R at launch to reopen diag")/2,184,"Hold L or R at launch to reopen diag",col_dim());
        gui_button(  4,196,76,40,BK_GREEN,  IC_NONE,"RUN APP",   gui_down(&tc,200+END_RUN));
        gui_button( 84,196,76,40,BK_NEUTRAL,IC_NONE,"DIAG OFF",  gui_down(&tc,200+END_RUN_NODIAG));
        gui_button(164,196,76,40,BK_ACCENT, IC_NONE,"SEND",      gui_down(&tc,200+END_SEND));
        gui_button(244,196,72,40,BK_NEUTRAL,IC_NONE,"RESTART",   gui_down(&tc,200+END_RESTART));
        gfx_present();
    }
    return END_RUN;
}

void diag_run(uint8_t* bufA,uint8_t* bufB,uint8_t* bufC){
    rgbA=bufA; rgbB=bufB; disp=bufC;
    int mode=welcome();
    if(mode){
        int idx=(mode==2)?G_ROUND5:0, single=0;        /* single = retesting one test from the summary, return there afterwards */
        memset(g_res,0,sizeof g_res); memset(g_det,0,sizeof g_det); session_begin();
        for(;;){
            while(idx<NT&&aptMainLoop()){
                int a=run_test(idx);
                if(a==A_OK||a==A_ISSUE){ g_res[idx]=(a==A_OK)?R_OK:R_ISSUE; stamp(idx); write_report(); if(single) break; idx++; }
                else if(a==A_BACK){ if(single) break; if(idx>0) idx--; }
                else if(a>=A_JUMP){ idx=a-A_JUMP; single=0; }
                else break;                  /* A_END */
            }
            single=0;
            int e=summary();
            if(e>=A_JUMP){ idx=e-A_JUMP; single=1; continue; }
            if(e==END_RESTART){ memset(g_res,0,sizeof g_res); memset(g_det,0,sizeof g_det); session_begin(); idx=(mode==2)?G_ROUND5:0; continue; }
            if(e==END_RUN_NODIAG){ S[S_DIAG]=0; settings_save(); }
            break;
        }
    }
    rgbA=rgbB=disp=NULL;
}
