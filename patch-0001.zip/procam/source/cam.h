#pragma once
#include <3ds.h>
#include <stdint.h>
typedef struct { int src, size, fmt, fps, w, h, stereo, active; uint8_t* buf[2]; u32 maxbytes; } Cam;
extern Cam g_cam;
extern const int g_size_w[3], g_size_h[3];     // 0=VGA 1=QVGA 2=QQVGA
int  cam_init(void);
void cam_exit(void);
int  cam_start(int src, int size, int fmt, int fps_enum);   // fps_enum indexes S_FPS labels
void cam_stop(void);
int  cam_grab(int timeout_ms);                              // blocking; fills g_cam.buf[0/1]
void cam_apply_params(void);                                // push exposure/WB/etc. from settings
void cam_set_ev(int ev);                                    // force AE on + EV (for bracketing)
void cam_shutter_sound(int type);

/* Diagnostic hooks (used by diag.c). Defaults keep normal behaviour. */
extern u64 g_cam_frame_us;       // arrival time of the frame cam_grab last returned, microseconds
extern int g_cam_threaded;       // 1 = camera thread keeps the sensor fed (normal), 0 = grab from the main thread
extern int g_cam_inval;          // 1 = invalidate CPU cache after each frame (normal), 0 = skip (test only)
extern int g_cam_skip_params;    // 1 = cam_start leaves every sensor setting at the hardware default
extern u32 g_cam_frames, g_cam_timeouts;   // frames delivered / grabs that timed out since boot
u32  cam_select(void);           // CAMU select mask for the current source

/* Which groups of sensor settings cam_apply_params sends (diagnostics use subsets; the app uses CAM_M_ALL). */
enum { CAM_M_AE=1, CAM_M_WB=2, CAM_M_PHOTO=4, CAM_M_SHARP=8, CAM_M_CONTR=16, CAM_M_NOISE=32, CAM_M_LENS=64,
       CAM_M_FX=128, CAM_M_FLIP=256, CAM_M_METER=512, CAM_M_ALL=1023 };
extern int g_cam_param_mask;
void cam_apply_live(void);       // only sharpness, contrast, noise filter, lens correction: safe on a running sensor
